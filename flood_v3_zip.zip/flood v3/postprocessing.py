"""
╔══════════════════════════════════════════════════════════════════════╗
║         UAE FloodMap – Flood Mask Post-Processing Engine            ║
║  Morphological ops · Permanent water removal · Size filtering      ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, numpy as np
from scipy.ndimage import (binary_closing, binary_fill_holes,
                           label, binary_erosion, binary_dilation)
from config import MIN_FLOOD_PIXELS

L = logging.getLogger("flood.postproc")

def clean_mask(flood_mask, water_mask=None, min_pixels=MIN_FLOOD_PIXELS,
               dem=None, max_slope=None):
    """
    Clean raw flood detection mask:
      1. Remove permanent water bodies (NDWI mask)
      2. Remove high-slope pixels if DEM provided
      3. Morphological closing (fill gaps)
      4. Fill internal holes
      5. Remove small connected components < min_pixels
    Returns (cleaned_mask, info_dict).
    """
    mask = flood_mask.copy().astype(np.uint8)
    info = {"original_pixels": int(mask.sum())}

    # 1. Remove permanent water
    if water_mask is not None:
        wm = water_mask
        if wm.shape != mask.shape:
            from scipy.ndimage import zoom
            zy = mask.shape[0] / wm.shape[0]
            zx = mask.shape[1] / wm.shape[1]
            wm = zoom(wm.astype(float), (zy, zx), order=0).astype(np.uint8)
        removed = int((mask & wm).sum())
        mask[wm > 0] = 0
        info["permanent_water_removed"] = removed

    # 2. Remove steep slopes (water doesn't pool on slopes)
    if dem is not None and max_slope is not None:
        gy, gx = np.gradient(dem)
        slope = np.sqrt(gx**2 + gy**2) * 100  # approx percent
        steep = slope > max_slope
        removed_slope = int((mask & steep.astype(np.uint8)).sum())
        mask[steep] = 0
        info["steep_slope_removed"] = removed_slope

    # 3. Morphological closing
    struct = np.ones((3, 3), dtype=np.uint8)
    mask = binary_closing(mask, structure=struct, iterations=2).astype(np.uint8)

    # 4. Fill holes
    mask = binary_fill_holes(mask).astype(np.uint8)

    # 5. Remove small blobs
    labeled, n_features = label(mask)
    removed_small = 0
    for i in range(1, n_features + 1):
        component = labeled == i
        if component.sum() < min_pixels:
            mask[component] = 0
            removed_small += 1
    info["small_blobs_removed"] = removed_small
    info["final_pixels"] = int(mask.sum())
    info["n_components"] = n_features - removed_small

    L.info(f"Post-process: {info['original_pixels']} -> {info['final_pixels']} px, "
           f"{info.get('permanent_water_removed',0)} perm-water removed, "
           f"{removed_small} small blobs removed")
    return mask, info
