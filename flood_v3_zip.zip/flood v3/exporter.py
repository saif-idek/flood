"""
╔══════════════════════════════════════════════════════════════════════╗
║           UAE FloodMap – GeoTIFF / Shapefile / CSV Export           ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, os, numpy as np
import rasterio
from rasterio.transform import from_bounds
from rasterio.crs import CRS
import geopandas as gpd
import pandas as pd
from shapely.geometry import shape
from config import OUTPUT_DIR

L = logging.getLogger("flood.export")

def _transform(bbox, h, w):
    return from_bounds(bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y, w, h)

def save_mask(array, bbox, path):
    """Save binary mask as uint8 GeoTIFF."""
    h, w = array.shape
    with rasterio.open(path, "w", driver="GTiff", height=h, width=w,
                       count=1, dtype="uint8", crs=CRS.from_epsg(4326),
                       transform=_transform(bbox, h, w),
                       compress="lzw") as dst:
        dst.write(array.astype(np.uint8), 1)
    L.info(f"Saved mask: {path}")

def save_float(array, bbox, path):
    """Save float32 raster (depth, change, etc.)."""
    h, w = array.shape
    with rasterio.open(path, "w", driver="GTiff", height=h, width=w,
                       count=1, dtype="float32", crs=CRS.from_epsg(4326),
                       transform=_transform(bbox, h, w),
                       compress="deflate", nodata=np.nan) as dst:
        dst.write(array.astype(np.float32), 1)
    L.info(f"Saved float raster: {path}")

def save_sar(vv, vh, bbox, path):
    """Save 2-band SAR GeoTIFF in dB."""
    from detection import to_db
    h, w = vv.shape
    with rasterio.open(path, "w", driver="GTiff", height=h, width=w,
                       count=2, dtype="float32", crs=CRS.from_epsg(4326),
                       transform=_transform(bbox, h, w),
                       compress="deflate") as dst:
        dst.write(to_db(vv), 1)
        dst.write(to_db(vh), 2)
    L.info(f"Saved SAR: {path}")

def save_flood_shapefile(mask, bbox, out_path, method_name="threshold",
                         min_area_m2=2000.0, simplify_px=1.0,
                         post_db=None, depth=None,
                         write_utm_copy=True):
    """Vectorize a binary flood mask to a clean shapefile.

    Steps
    -----
    1. Polygonise the raster with rasterio.features.shapes.
    2. Reproject to local UTM (true metres) for area/length geometry ops.
    3. Drop polygons below `min_area_m2` (slivers from morphological edges).
    4. Simplify with a tolerance of `simplify_px` × pixel size in metres
       (Douglas–Peucker — preserves shape at sub-pixel level).
    5. Attach attributes:  area_m2, area_ha, perimeter_m, lon, lat,
                           mean_post_db, mean_depth_m  (when supplied).
    6. Write WGS84 (.shp) and an optional UTM sibling (_utm.shp).

    `min_area_m2` here is a *vector*-level cleanup floor, intentionally
    smaller than the raster-level MIN_FLOOD_AREA_M2 so we don't double-erode.
    """
    from rasterio.features import shapes as rio_shapes
    mask = (mask > 0).astype(np.uint8)
    if mask.sum() == 0:
        L.warning(f"No flood pixels — skipping {out_path}")
        return None

    h, w = mask.shape
    t = _transform(bbox, h, w)
    polys = [shape(g) for g, v in rio_shapes(mask, transform=t) if v == 1]
    if not polys:
        L.warning(f"No flood polygons for {method_name}")
        return None

    gdf = gpd.GeoDataFrame({"geometry": polys}, crs="EPSG:4326")
    gdf["method"] = method_name

    # Move to local UTM for honest metres-based ops.
    utm_crs = gdf.estimate_utm_crs()
    gdf_utm = gdf.to_crs(utm_crs)

    # Pixel size in metres (UTM) — derived from bbox extent and raster shape.
    extent_utm = gdf_utm.total_bounds
    px_size_m = max((extent_utm[2] - extent_utm[0]) / w,
                    (extent_utm[3] - extent_utm[1]) / h)
    tol_m = float(simplify_px) * px_size_m

    # Drop slivers, simplify, recompute area on the cleaned geometry.
    gdf_utm["area_m2"]     = gdf_utm.geometry.area
    gdf_utm = gdf_utm[gdf_utm["area_m2"] >= float(min_area_m2)].copy()
    if gdf_utm.empty:
        L.warning(f"All polygons below {min_area_m2} m² — nothing to write")
        return None

    gdf_utm["geometry"]    = gdf_utm.geometry.simplify(tol_m,
                                                       preserve_topology=True)
    gdf_utm = gdf_utm[~gdf_utm.geometry.is_empty].copy()
    gdf_utm["area_m2"]     = gdf_utm.geometry.area
    gdf_utm["area_ha"]     = gdf_utm["area_m2"] / 1e4
    gdf_utm["area_km2"]    = gdf_utm["area_m2"] / 1e6
    gdf_utm["perim_m"]     = gdf_utm.geometry.length
    centroids              = gdf_utm.geometry.centroid.to_crs("EPSG:4326")
    gdf_utm["lon"]         = centroids.x
    gdf_utm["lat"]         = centroids.y

    # Optional per-polygon raster sampling (mean post-VV in dB; mean depth).
    if post_db is not None or depth is not None:
        from rasterio.features import geometry_mask
        gdf_for_sample = gdf_utm.to_crs("EPSG:4326")
        for idx, geom in zip(gdf_for_sample.index, gdf_for_sample.geometry):
            poly_mask = ~geometry_mask([geom], transform=t,
                                       out_shape=(h, w), invert=False)
            if poly_mask.sum() == 0:
                continue
            if post_db is not None:
                vals = post_db[poly_mask]
                vals = vals[np.isfinite(vals)]
                gdf_utm.loc[idx, "mean_db"] = float(vals.mean()) if vals.size else np.nan
            if depth is not None:
                d = depth[poly_mask]
                d = d[np.isfinite(d) & (d > 0)]
                gdf_utm.loc[idx, "mean_dep_m"] = float(d.mean()) if d.size else 0.0
                gdf_utm.loc[idx, "max_dep_m"]  = float(d.max())  if d.size else 0.0

    gdf_wgs = gdf_utm.to_crs("EPSG:4326")
    gdf_wgs.to_file(out_path)
    if write_utm_copy:
        utm_path = out_path.replace(".shp", "_utm.shp")
        gdf_utm.to_file(utm_path)

    L.info(f"Shapefile: {out_path} — {len(gdf_wgs):,} polygons, "
           f"{gdf_wgs['area_km2'].sum():.4f} km² "
           f"(simplify={tol_m:.1f} m, sliver-cut={min_area_m2:.0f} m²)")
    return gdf_wgs

def build_stats(detections, roi_km2, precip_analysis=None,
                depth_stats=None, street_summary=None):
    """Build comprehensive statistics dict."""
    stats = {"roi_km2": roi_km2, "methods": {}}
    for name, det in detections.items():
        mask = det["mask"]
        px = int(mask.sum())
        pct = 100 * mask.mean()
        stats["methods"][name] = {
            "flood_pixels": px,
            "pct_flooded": round(pct, 3),
            "flooded_km2": round(roi_km2 * pct / 100, 4),
        }
    if precip_analysis:
        stats["precipitation"] = {
            k: precip_analysis[k] for k in
            ["total_mm", "peak_day_mm", "peak_day_date", "max_3day_mm",
             "heavy_days", "extreme_days", "return_period_est"]
            if k in precip_analysis
        }
    if depth_stats:
        stats["water_depth"] = depth_stats
    if street_summary:
        stats["streets"] = street_summary
    return stats

def save_csv(stats, path):
    """Save stats to CSV."""
    rows = []
    for method, ms in stats.get("methods", {}).items():
        rows.append({"method": method, **ms})
    pd.DataFrame(rows).to_csv(path, index=False)
    L.info(f"CSV: {path}")
