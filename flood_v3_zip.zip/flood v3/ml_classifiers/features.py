"""
============================================================================
 UAE FloodMap - Shared multi-sensor FEATURE STACK for ML flood classifiers
============================================================================

All three machine-learning methodologies in this package
(``flood_rf`` Random-Forest, ``flood_unet`` U-Net, ``flood_mlp`` pixel-MLP)
consume the SAME feature stack so they can be compared fairly on identical
inputs. This module turns whatever co-registered rasters are available
(Sentinel-1 SAR, Sentinel-2 optical, Copernicus DEM) into:

    X      : (H, W, F) float32 feature cube
    names  : list[str] of length F  (one human-readable label per channel)

Every input layer is OPTIONAL. The builder uses whichever sensors the caller
supplies and records, in ``names``, exactly which physical features went in -
so a model trained on {S1+S2+DEM} is never silently fed an {S1-only} stack.

Physical features
-----------------
S1 (C-band, dB)      : vv_after, vh_after, dvv (= after-before), dvh,
                       ratio (vv-vh), local texture (3x3 std of VV)
S2 (reflectance)     : NDWI (McFeeters 1996), MNDWI (Xu 2006),
                       AWEIsh (Feyisa 2014), NDVI, the raw bands
Terrain (m / deg)    : elevation (z-scored), slope, a cheap HAND-proxy
                       (height above local minimum) - low/flat = floodable

Weak-label helper
-----------------
``weak_labels_from_detectors`` builds pseudo-labels from the project's own
physics detectors (detection.py / detection_s2.py) so the ML models can be
self-trained when no hand-labelled ground truth is available. These are
WEAK labels - use them for bootstrapping / demos, not for headline accuracy
claims (the honesty rule of this codebase).
"""
from __future__ import annotations
import logging
import numpy as np
from scipy.ndimage import uniform_filter, minimum_filter, generic_filter

L = logging.getLogger("flood.ml.features")

# Bright NIR/SWIR reflectance above which a pixel cannot be open water
# (water absorbs strongly in NIR/SWIR - McFeeters 1996, Xu 2006).
_BRIGHT_NIR_SWIR = 0.15


def _safe(a):
    return np.nan_to_num(np.asarray(a, dtype=np.float32), nan=0.0,
                         posinf=0.0, neginf=0.0)


def _ratio(num, den):
    return _safe(num) / (np.abs(_safe(den)) + 1e-6)


def _slope_deg(dem, pixel_m=10.0):
    gy, gx = np.gradient(_safe(dem), pixel_m)
    return np.degrees(np.arctan(np.hypot(gx, gy))).astype(np.float32)


def _hand_proxy(dem, size=51):
    """Cheap Height-Above-Nearest-Drainage proxy: elevation minus the local
    minimum in a wide window. Genuinely low spots (near 0) pond first."""
    dem = _safe(dem)
    local_min = minimum_filter(dem, size=size, mode="nearest")
    return (dem - local_min).astype(np.float32)


def _zscore(a):
    a = _safe(a)
    m, s = float(a.mean()), float(a.std())
    return ((a - m) / (s + 1e-6)).astype(np.float32)


# --------------------------------------------------------------------------
#  Feature-stack builder
# --------------------------------------------------------------------------
def build_feature_stack(inputs: dict, pixel_m: float = 10.0,
                        with_texture: bool = True) -> tuple[np.ndarray, list]:
    """Assemble the (H, W, F) feature cube from available co-registered layers.

    Parameters
    ----------
    inputs : dict of 2-D float arrays, all on the SAME grid. Recognised keys:
        S1   : 'vv_after','vh_after','vv_before','vh_before'   (linear or dB)
        S2   : 'ndwi','mndwi','awei'  and/or raw reflectance bands
               'blue','green','red','nir','swir1','swir2'
        DEM  : 'dem'
    pixel_m : grid spacing in metres (for slope / texture scaling).
    with_texture : add a 3x3 local-std texture channel for SAR speckle context.

    Returns
    -------
    X     : (H, W, F) float32
    names : list[str]
    """
    layers, names = [], []

    def add(arr, name):
        layers.append(_safe(arr))
        names.append(name)

    # shape discovery -----------------------------------------------------
    ref = None
    for v in inputs.values():
        if v is not None:
            ref = np.asarray(v); break
    if ref is None:
        raise ValueError("build_feature_stack: no input layers supplied")
    H, W = ref.shape[:2]

    def ok(k):
        return inputs.get(k) is not None and np.asarray(inputs[k]).shape[:2] == (H, W)

    # ---- Sentinel-1 SAR -------------------------------------------------
    if ok("vv_after"):
        vv_a = _safe(inputs["vv_after"])
        add(vv_a, "s1_vv_after")
        if ok("vh_after"):
            vh_a = _safe(inputs["vh_after"])
            add(vh_a, "s1_vh_after")
            add(vv_a - vh_a, "s1_vv_minus_vh")
        if ok("vv_before"):
            add(vv_a - _safe(inputs["vv_before"]), "s1_dvv")
        if ok("vh_before") and ok("vh_after"):
            add(_safe(inputs["vh_after"]) - _safe(inputs["vh_before"]), "s1_dvh")
        if with_texture:
            m = uniform_filter(vv_a, 3)
            std = np.sqrt(np.clip(uniform_filter(vv_a * vv_a, 3) - m * m, 0, None))
            add(std, "s1_vv_texture3")

    # ---- Sentinel-2 optical --------------------------------------------
    have_bands = all(ok(b) for b in ("green", "nir"))
    if ok("ndwi"):
        add(inputs["ndwi"], "s2_ndwi")
    elif have_bands:
        add(_ratio(inputs["green"] - inputs["nir"], inputs["green"] + inputs["nir"]),
            "s2_ndwi")

    if ok("mndwi"):
        add(inputs["mndwi"], "s2_mndwi")
    elif ok("green") and ok("swir1"):
        add(_ratio(inputs["green"] - inputs["swir1"], inputs["green"] + inputs["swir1"]),
            "s2_mndwi")

    if ok("awei"):
        add(inputs["awei"], "s2_awei")
    elif have_bands and ok("blue") and ok("swir1"):
        awei = (_safe(inputs["blue"]) + 2.5 * _safe(inputs["green"])
                - 1.5 * (_safe(inputs["nir"]) + _safe(inputs["swir1"]))
                - 0.25 * _safe(inputs.get("swir2", np.zeros((H, W)))))
        add(awei, "s2_aweish")

    if have_bands and ok("red"):
        add(_ratio(inputs["nir"] - inputs["red"], inputs["nir"] + inputs["red"]),
            "s2_ndvi")
    for b in ("blue", "green", "red", "nir", "swir1", "swir2"):
        if ok(b):
            add(inputs[b], f"s2_{b}")

    # ---- Terrain --------------------------------------------------------
    if ok("dem"):
        dem = _safe(inputs["dem"])
        add(_zscore(dem), "dem_z")
        add(_slope_deg(dem, pixel_m), "dem_slope_deg")
        add(_hand_proxy(dem), "dem_hand_proxy")

    X = np.stack(layers, axis=-1).astype(np.float32)
    L.info("feature stack: %d channels %s -> %s", X.shape[-1], X.shape, names)
    return X, names


def stack_to_table(X: np.ndarray) -> np.ndarray:
    """(H, W, F) -> (H*W, F) for pixel-wise (tabular) models."""
    H, W, F = X.shape
    return X.reshape(H * W, F)


def table_to_map(y: np.ndarray, shape) -> np.ndarray:
    """(H*W,) -> (H, W)."""
    return np.asarray(y).reshape(shape[0], shape[1])


# --------------------------------------------------------------------------
#  Weak-label generation (self-supervision from the physics detectors)
# --------------------------------------------------------------------------
def weak_labels_from_detectors(inputs: dict,
                               permanent_water: np.ndarray | None = None
                               ) -> np.ndarray:
    """Bootstrap a (H, W) {0,1} pseudo-label from the project's own physics
    detectors, so ML models can be trained without hand labels.

    Logic (conservative AND of independent evidence):
      * S2 present -> NDWI>0 AND MNDWI>0 (two-index agreement)
      * S1 present -> strong backscatter drop (dvv below the 15th percentile)
      * permanent water removed if supplied.
    Pixels with NO sensor evidence stay 0. These are WEAK labels.
    """
    X_keys = inputs
    H = W = None
    for v in X_keys.values():
        if v is not None:
            H, W = np.asarray(v).shape[:2]; break
    if H is None:
        raise ValueError("weak_labels: no inputs")

    votes = np.zeros((H, W), np.float32)
    n_streams = 0

    g, n = inputs.get("green"), inputs.get("nir")
    sw = inputs.get("swir1")
    if g is not None and n is not None:
        ndwi = _ratio(_safe(g) - _safe(n), _safe(g) + _safe(n))
        water = ndwi > 0.0
        if sw is not None:
            mndwi = _ratio(_safe(g) - _safe(sw), _safe(g) + _safe(sw))
            water &= mndwi > 0.0
            # reject sun-glint / bright surfaces
            water &= (_safe(n) < _BRIGHT_NIR_SWIR)
        votes += water.astype(np.float32); n_streams += 1
    elif inputs.get("ndwi") is not None:
        water = _safe(inputs["ndwi"]) > 0.0
        if inputs.get("mndwi") is not None:
            water &= _safe(inputs["mndwi"]) > 0.0
        votes += water.astype(np.float32); n_streams += 1

    if inputs.get("vv_after") is not None and inputs.get("vv_before") is not None:
        dvv = _safe(inputs["vv_after"]) - _safe(inputs["vv_before"])
        thr = np.percentile(dvv, 15)
        votes += (dvv < thr).astype(np.float32); n_streams += 1

    if n_streams == 0:
        raise ValueError("weak_labels: need S2 (green+nir) or S1 (vv before+after)")

    label = (votes >= 1).astype(np.uint8)
    if permanent_water is not None:
        label[np.asarray(permanent_water).astype(bool)] = 0
    L.info("weak labels: %d streams, %.2f%% positive", n_streams,
           100.0 * label.mean())
    return label


def balanced_sample(X_table: np.ndarray, y: np.ndarray, n_per_class: int = 20000,
                    seed: int = 42):
    """Draw a class-balanced pixel sample for tabular training (RF / MLP)."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y).ravel()
    out_idx = []
    for cls in (0, 1):
        idx = np.where(y == cls)[0]
        if len(idx) == 0:
            continue
        take = min(n_per_class, len(idx))
        out_idx.append(rng.choice(idx, size=take, replace=False))
    sel = np.concatenate(out_idx)
    rng.shuffle(sel)
    return X_table[sel], y[sel]


if __name__ == "__main__":
    # synthetic smoke test - no network, no real data
    logging.basicConfig(level=logging.INFO)
    H, W = 64, 80
    rng = np.random.default_rng(0)
    green = rng.uniform(0.05, 0.15, (H, W)).astype(np.float32)
    nir = rng.uniform(0.20, 0.35, (H, W)).astype(np.float32)
    swir1 = rng.uniform(0.15, 0.30, (H, W)).astype(np.float32)
    # carve a water patch: high green, low NIR/SWIR
    green[20:40, 25:55] = 0.18; nir[20:40, 25:55] = 0.03; swir1[20:40, 25:55] = 0.02
    dem = (rng.uniform(0, 5, (H, W)) + np.linspace(0, 30, W)[None, :]).astype(np.float32)
    inputs = dict(green=green, nir=nir, swir1=swir1, blue=green * 0.9,
                  red=nir * 0.9, dem=dem)
    X, names = build_feature_stack(inputs, pixel_m=10.0)
    y = weak_labels_from_detectors(inputs)
    print("stack:", X.shape, "| features:", names)
    print("weak-label positive frac: %.3f (expect ~0.28 over the patch)" % y.mean())
    Xt = stack_to_table(X)
    Xs, ys = balanced_sample(Xt, y, n_per_class=500)
    print("balanced sample:", Xs.shape, "pos frac %.2f" % ys.mean())
