"""
UAE FloodMap - Machine-Learning flood-classification methodologies.

Three additive, self-contained flood classifiers that share one feature
contract (``features.build_feature_stack`` over Sentinel-1 + Sentinel-2 + DEM):

    METHODOLOGY 1  flood_rf.FloodRandomForest   - Random Forest (sklearn)
    METHODOLOGY 2  flood_unet.FloodUNet         - U-Net CNN segmenter (PyTorch)
    METHODOLOGY 3  flood_mlp.FloodMLP           - pixel-MLP (PyTorch, MC-Dropout)

Each exposes the same interface as the project's physics detectors:
    .fit_scene(inputs, labels=None, ...)      -> self
    .predict_scene(inputs, threshold=0.5)     -> {"mask", "confidence", "info"}
    .save(path) / .load(path)

so their outputs can flow straight into the existing vectorise / advanced-stats
/ water-height steps. Labels may be hand ground-truth or the weak labels from
``features.weak_labels_from_detectors`` (self-supervision from the physics chain).
"""
from .features import (build_feature_stack, stack_to_table, table_to_map,
                       weak_labels_from_detectors, balanced_sample)
from .flood_rf import FloodRandomForest

__all__ = [
    "build_feature_stack", "stack_to_table", "table_to_map",
    "weak_labels_from_detectors", "balanced_sample",
    "FloodRandomForest", "FloodUNet", "FloodMLP",
]


def __getattr__(name):
    # lazy torch-backed imports so `import ml_classifiers` works without torch
    if name == "FloodUNet":
        from .flood_unet import FloodUNet
        return FloodUNet
    if name == "FloodMLP":
        from .flood_mlp import FloodMLP
        return FloodMLP
    raise AttributeError(name)
