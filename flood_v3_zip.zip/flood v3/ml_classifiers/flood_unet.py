"""
============================================================================
 UAE FloodMap - METHODOLOGY 2:  U-Net deep-learning flood segmenter
============================================================================

A compact U-Net (Ronneberger et al. 2015) convolutional segmentation network
that maps the multi-channel feature stack (S1 + S2 + DEM) to a per-pixel
flood-probability map. Unlike the per-pixel Random Forest / MLP, the U-Net
uses SPATIAL CONTEXT (the encoder-decoder receptive field), so it learns the
shape / connectivity of inundation, suppressing isolated speckle and filling
thin channels - the deep-learning analogue of the physics chain's
region-growing step.

Architecture
------------
* Input  : (B, C, h, w)  - C = number of feature channels (data-driven)
* Encoder: 3 down blocks (Conv-BN-ReLU x2 + MaxPool), channels 32->64->128
* Bottleneck: 256
* Decoder: 3 up blocks (transpose-conv + skip concat + Conv-BN-ReLU x2)
* Head   : 1x1 conv -> 1 logit per pixel  (sigmoid at inference)
* Loss   : BCE + soft-Dice (handles the heavy class imbalance of flood scenes)

Training data
-------------
Patches are sampled from one or more labelled scenes (hand GT or the weak
labels from ``features.weak_labels_*``). Full-scene inference is tiled with
overlap-averaging so there are no seams.

References
----------
Ronneberger, Fischer, Brox (2015) "U-Net", MICCAI.
Bonafilia et al. (2020) "Sen1Floods11" benchmark.
Katiyar et al. (2021) CNN flood mapping from Sentinel-1.

Requires PyTorch (torch). Imports lazily so the rest of the package works
without it. Runs on GPU if available, else CPU.
"""
from __future__ import annotations
import logging
import numpy as np

from .features import build_feature_stack

L = logging.getLogger("flood.ml.unet")


def _torch():
    import torch
    return torch


# --------------------------------------------------------------------------
#  Network
# --------------------------------------------------------------------------
def _build_module(in_channels: int):
    import torch
    import torch.nn as nn

    def conv_block(cin, cout):
        return nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))

    class UNet(nn.Module):
        def __init__(self, cin, base=32):
            super().__init__()
            self.e1 = conv_block(cin, base)
            self.e2 = conv_block(base, base * 2)
            self.e3 = conv_block(base * 2, base * 4)
            self.pool = nn.MaxPool2d(2)
            self.b = conv_block(base * 4, base * 8)
            self.u3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
            self.d3 = conv_block(base * 8, base * 4)
            self.u2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
            self.d2 = conv_block(base * 4, base * 2)
            self.u1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
            self.d1 = conv_block(base * 2, base)
            self.head = nn.Conv2d(base, 1, 1)

        def forward(self, x):
            c1 = self.e1(x)
            c2 = self.e2(self.pool(c1))
            c3 = self.e3(self.pool(c2))
            b = self.b(self.pool(c3))
            x = self.d3(torch.cat([self.u3(b), c3], 1))
            x = self.d2(torch.cat([self.u2(x), c2], 1))
            x = self.d1(torch.cat([self.u1(x), c1], 1))
            return self.head(x)  # logits

    return UNet(in_channels)


def _dice_bce_loss(logits, target):
    import torch
    import torch.nn.functional as F
    bce = F.binary_cross_entropy_with_logits(logits, target)
    p = torch.sigmoid(logits)
    num = 2 * (p * target).sum() + 1.0
    den = p.sum() + target.sum() + 1.0
    dice = 1 - num / den
    return bce + dice


# --------------------------------------------------------------------------
#  Classifier wrapper
# --------------------------------------------------------------------------
class FloodUNet:
    """U-Net flood segmenter with the project feature contract."""

    def __init__(self, in_channels: int | None = None, base: int = 32,
                 device: str | None = None, patch: int = 64):
        torch = _torch()
        self.in_channels = in_channels
        self.base = base
        self.patch = patch
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.net = None
        self.feature_names: list[str] | None = None
        self._mean = None
        self._std = None

    # ---- normalisation --------------------------------------------------
    def _fit_norm(self, X):
        self._mean = X.reshape(-1, X.shape[-1]).mean(0).astype(np.float32)
        self._std = (X.reshape(-1, X.shape[-1]).std(0) + 1e-6).astype(np.float32)

    def _norm(self, X):
        return ((X - self._mean) / self._std).astype(np.float32)

    def _ensure_net(self, C):
        if self.net is None:
            self.in_channels = C
            self.net = _build_module(C).to(self.device)

    # ---- patch sampling -------------------------------------------------
    def _sample_patches(self, Xn, y, n_patches, seed=0):
        rng = np.random.default_rng(seed)
        H, W, C = Xn.shape
        p = self.patch
        xs, ys = [], []
        pos = np.argwhere(y > 0)
        for i in range(n_patches):
            # bias half the patches to centre on a flood pixel
            if len(pos) and i % 2 == 0:
                cy, cx = pos[rng.integers(len(pos))]
                r0 = int(np.clip(cy - p // 2, 0, max(0, H - p)))
                c0 = int(np.clip(cx - p // 2, 0, max(0, W - p)))
            else:
                r0 = int(rng.integers(0, max(1, H - p + 1)))
                c0 = int(rng.integers(0, max(1, W - p + 1)))
            xs.append(Xn[r0:r0 + p, c0:c0 + p].transpose(2, 0, 1))
            ys.append(y[r0:r0 + p, c0:c0 + p][None])
        return np.asarray(xs, np.float32), np.asarray(ys, np.float32)

    # ---- training -------------------------------------------------------
    def fit_scene(self, inputs: dict, labels: np.ndarray,
                  epochs: int = 30, n_patches: int = 64, batch: int = 8,
                  lr: float = 1e-3, pixel_m=10.0, seed: int = 0):
        torch = _torch()
        X, names = build_feature_stack(inputs, pixel_m=pixel_m)
        self.feature_names = names
        self._fit_norm(X)
        Xn = self._norm(X)
        self._ensure_net(Xn.shape[-1])

        xb, yb = self._sample_patches(Xn, np.asarray(labels, np.float32),
                                      n_patches, seed)
        xb = torch.from_numpy(xb).to(self.device)
        yb = torch.from_numpy(yb).to(self.device)
        opt = torch.optim.Adam(self.net.parameters(), lr=lr)
        self.net.train()
        n = xb.shape[0]
        for ep in range(epochs):
            perm = torch.randperm(n, device=self.device)
            tot = 0.0
            for i in range(0, n, batch):
                idx = perm[i:i + batch]
                opt.zero_grad()
                logits = self.net(xb[idx])
                loss = _dice_bce_loss(logits, yb[idx])
                loss.backward(); opt.step()
                tot += float(loss) * len(idx)
            if ep % max(1, epochs // 6) == 0 or ep == epochs - 1:
                L.info("U-Net epoch %d/%d  loss=%.4f", ep + 1, epochs, tot / n)
        return self

    # ---- inference (tiled, overlap-averaged) ----------------------------
    def predict_proba_scene(self, inputs: dict, pixel_m=10.0,
                            overlap: int = 16) -> np.ndarray:
        torch = _torch()
        X, names = build_feature_stack(inputs, pixel_m=pixel_m)
        if self.feature_names and names != self.feature_names:
            L.warning("U-Net feature mismatch trained=%s given=%s",
                      self.feature_names, names)
        Xn = self._norm(X)
        H, W, C = Xn.shape
        p, step = self.patch, max(1, self.patch - overlap)
        acc = np.zeros((H, W), np.float32)
        cnt = np.zeros((H, W), np.float32)
        self.net.eval()
        with torch.no_grad():
            for r0 in list(range(0, max(1, H - p + 1), step)) + [max(0, H - p)]:
                for c0 in list(range(0, max(1, W - p + 1), step)) + [max(0, W - p)]:
                    tile = Xn[r0:r0 + p, c0:c0 + p]
                    th, tw = tile.shape[:2]
                    t = torch.from_numpy(tile.transpose(2, 0, 1)[None]).to(self.device)
                    prob = torch.sigmoid(self.net(t))[0, 0].cpu().numpy()
                    acc[r0:r0 + th, c0:c0 + tw] += prob[:th, :tw]
                    cnt[r0:r0 + th, c0:c0 + tw] += 1.0
        return (acc / np.maximum(cnt, 1)).astype(np.float32)

    def predict_scene(self, inputs: dict, threshold: float = 0.5, pixel_m=10.0) -> dict:
        proba = self.predict_proba_scene(inputs, pixel_m=pixel_m)
        mask = (proba >= threshold).astype(np.uint8)
        info = {"method": "U-Net (PyTorch)", "in_channels": self.in_channels,
                "device": self.device, "threshold": threshold,
                "flood_pixels": int(mask.sum()), "flood_fraction": float(mask.mean())}
        return {"mask": mask, "confidence": proba, "info": info}

    # ---- IO -------------------------------------------------------------
    def save(self, path: str):
        torch = _torch()
        torch.save({"state": self.net.state_dict(), "in_channels": self.in_channels,
                    "base": self.base, "patch": self.patch,
                    "feature_names": self.feature_names,
                    "mean": self._mean, "std": self._std}, path)
        L.info("saved U-Net -> %s", path)

    @classmethod
    def load(cls, path: str, device: str | None = None) -> "FloodUNet":
        torch = _torch()
        d = torch.load(path, map_location="cpu", weights_only=False)
        obj = cls(in_channels=d["in_channels"], base=d["base"],
                  device=device, patch=d["patch"])
        obj._ensure_net(d["in_channels"])
        obj.net.load_state_dict(d["state"])
        obj.net.to(obj.device)
        obj.feature_names = d["feature_names"]
        obj._mean, obj._std = d["mean"], d["std"]
        return obj


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    rng = np.random.default_rng(2)
    H, W = 96, 128
    green = rng.uniform(0.05, 0.15, (H, W)).astype(np.float32)
    nir = rng.uniform(0.20, 0.35, (H, W)).astype(np.float32)
    swir1 = rng.uniform(0.15, 0.30, (H, W)).astype(np.float32)
    truth = np.zeros((H, W), np.uint8); truth[30:75, 40:110] = 1
    green[truth == 1] = 0.18; nir[truth == 1] = 0.03; swir1[truth == 1] = 0.02
    dem = (rng.uniform(0, 4, (H, W)) + np.linspace(0, 25, W)[None, :]).astype(np.float32)
    inputs = dict(green=green, nir=nir, swir1=swir1, blue=green * 0.9,
                  red=nir * 0.9, dem=dem)
    net = FloodUNet(patch=48).fit_scene(inputs, truth, epochs=25, n_patches=48, batch=8)
    out = net.predict_scene(inputs, threshold=0.5)
    pred = out["mask"]
    iou = (np.logical_and(pred, truth).sum() /
           max(1, np.logical_or(pred, truth).sum()))
    print("U-Net device:", out["info"]["device"], "| flood px %d (truth %d) | IoU=%.3f"
          % (pred.sum(), truth.sum(), iou))
    print("OK - U-Net methodology self-test ran (IoU=%.3f)" % iou)
