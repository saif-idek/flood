"""
============================================================================
 UAE FloodMap - METHODOLOGY 1:  Random-Forest flood classifier
============================================================================

A per-pixel Random Forest (Breiman 2001) that classifies each pixel as
flood / non-flood from the shared multi-sensor feature stack (S1 + S2 + DEM)
built by ``features.build_feature_stack``.

Why Random Forest for flood mapping
-----------------------------------
* Handles the heterogeneous, non-linearly-separable feature space of mixed
  SAR + optical + terrain inputs without manual thresholding.
* Robust to feature scaling and to a few noisy/irrelevant channels - it picks
  the informative ones (see ``feature_importances``).
* Gives a calibrated-ish probability (vote fraction) -> a confidence raster,
  mirroring the physics detectors' confidence output.
* Cheap to train on a class-balanced pixel sample; fast inference on a tile.

References
----------
Breiman (2001) "Random Forests", Machine Learning 45(1):5-32.
Tehrany et al. (2019) RS of flood susceptibility with RF.
Feng et al. (2015) Urban flood mapping with RF on multi-source RS.

This module never edits the production pipeline; it is an additive,
self-contained classifier with train / predict / save / load. Labels can be
hand ground-truth OR the weak labels from ``features.weak_labels_*``.
"""
from __future__ import annotations
import logging
import numpy as np

from .features import (build_feature_stack, stack_to_table, table_to_map,
                       weak_labels_from_detectors, balanced_sample)

L = logging.getLogger("flood.ml.rf")


class FloodRandomForest:
    """Random-Forest pixel classifier with the project's feature contract."""

    def __init__(self, n_estimators: int = 300, max_depth: int | None = None,
                 min_samples_leaf: int = 2, class_weight="balanced",
                 n_jobs: int = -1, random_state: int = 42):
        from sklearn.ensemble import RandomForestClassifier
        self.model = RandomForestClassifier(
            n_estimators=n_estimators, max_depth=max_depth,
            min_samples_leaf=min_samples_leaf, class_weight=class_weight,
            n_jobs=n_jobs, random_state=random_state, oob_score=True)
        self.feature_names: list[str] | None = None

    # ---- training -------------------------------------------------------
    def fit_table(self, X_table: np.ndarray, y: np.ndarray,
                  feature_names: list | None = None):
        """Fit on an (N, F) table and (N,) {0,1} labels."""
        self.feature_names = feature_names
        self.model.fit(X_table, np.asarray(y).ravel())
        try:
            L.info("RF trained: OOB accuracy = %.4f", self.model.oob_score_)
        except Exception:
            pass
        return self

    def fit_scene(self, inputs: dict, labels: np.ndarray | None = None,
                  permanent_water=None, n_per_class: int = 20000, pixel_m=10.0):
        """Convenience: build features from a scene, (optionally) derive weak
        labels, class-balance, and fit."""
        X, names = build_feature_stack(inputs, pixel_m=pixel_m)
        if labels is None:
            labels = weak_labels_from_detectors(inputs, permanent_water)
        Xt = stack_to_table(X)
        yt = np.asarray(labels).ravel()
        Xs, ys = balanced_sample(Xt, yt, n_per_class=n_per_class)
        return self.fit_table(Xs, ys, feature_names=names)

    # ---- inference ------------------------------------------------------
    def predict_proba_scene(self, inputs: dict, pixel_m=10.0) -> np.ndarray:
        """Return a (H, W) flood-probability raster in [0, 1]."""
        X, names = build_feature_stack(inputs, pixel_m=pixel_m)
        self._check_features(names)
        H, W, _ = X.shape
        proba = self.model.predict_proba(stack_to_table(X))[:, 1]
        return table_to_map(proba, (H, W)).astype(np.float32)

    def predict_scene(self, inputs: dict, threshold: float = 0.5,
                      pixel_m=10.0) -> dict:
        """Return {'mask', 'confidence', 'info'} mirroring the physics
        detectors' contract so downstream code (vectorise, stats) can reuse it."""
        proba = self.predict_proba_scene(inputs, pixel_m=pixel_m)
        mask = (proba >= threshold).astype(np.uint8)
        info = {"method": "RandomForest (sklearn)",
                "n_estimators": self.model.n_estimators,
                "threshold": threshold,
                "flood_pixels": int(mask.sum()),
                "flood_fraction": float(mask.mean())}
        return {"mask": mask, "confidence": proba, "info": info}

    # ---- introspection / IO --------------------------------------------
    def feature_importances(self) -> list[tuple[str, float]]:
        imp = self.model.feature_importances_
        names = self.feature_names or [f"f{i}" for i in range(len(imp))]
        return sorted(zip(names, imp.tolist()), key=lambda t: -t[1])

    def _check_features(self, names):
        if self.feature_names and names != self.feature_names:
            L.warning("feature mismatch at inference!\n trained: %s\n given:   %s",
                      self.feature_names, names)

    def save(self, path: str):
        import joblib
        joblib.dump({"model": self.model, "feature_names": self.feature_names}, path)
        L.info("saved RF -> %s", path)

    @classmethod
    def load(cls, path: str) -> "FloodRandomForest":
        import joblib
        d = joblib.load(path)
        obj = cls.__new__(cls)
        obj.model = d["model"]; obj.feature_names = d["feature_names"]
        return obj


if __name__ == "__main__":
    # synthetic self-test: train on a scene with a known water patch, predict
    logging.basicConfig(level=logging.INFO)
    rng = np.random.default_rng(1)
    H, W = 96, 120
    green = rng.uniform(0.05, 0.15, (H, W)).astype(np.float32)
    nir = rng.uniform(0.20, 0.35, (H, W)).astype(np.float32)
    swir1 = rng.uniform(0.15, 0.30, (H, W)).astype(np.float32)
    truth = np.zeros((H, W), np.uint8); truth[30:70, 35:95] = 1
    green[truth == 1] = 0.18; nir[truth == 1] = 0.03; swir1[truth == 1] = 0.02
    dem = (rng.uniform(0, 4, (H, W)) + np.linspace(0, 25, W)[None, :]).astype(np.float32)
    inputs = dict(green=green, nir=nir, swir1=swir1, blue=green * 0.9,
                  red=nir * 0.9, dem=dem)

    rf = FloodRandomForest(n_estimators=120).fit_scene(inputs, labels=truth,
                                                       n_per_class=1500)
    out = rf.predict_scene(inputs, threshold=0.5)
    pred = out["mask"]
    iou = (np.logical_and(pred, truth).sum() /
           max(1, np.logical_or(pred, truth).sum()))
    print("RF flood pixels: %d (truth %d) | IoU=%.3f" %
          (pred.sum(), truth.sum(), iou))
    print("top features:", rf.feature_importances()[:5])
    assert iou > 0.7, "RF should recover the synthetic water patch"
    print("OK - Random Forest methodology self-test passed")
