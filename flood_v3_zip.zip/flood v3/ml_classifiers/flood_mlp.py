"""
============================================================================
 UAE FloodMap - METHODOLOGY 3:  Pixel-MLP deep-learning flood classifier
============================================================================

A fully-connected deep neural network (multi-layer perceptron) that classifies
each pixel independently from its feature vector (S1 + S2 + DEM). This is the
"tabular deep-learning" counterpart to the Random Forest (METHODOLOGY 1): both
see the SAME per-pixel features, so comparing them isolates the value of a
learned non-linear embedding vs. an ensemble of decision trees - while the
U-Net (METHODOLOGY 2) adds spatial context the other two deliberately lack.

Architecture
------------
* Input  : F features  (data-driven, from build_feature_stack)
* Hidden : [128, 64, 32] with BatchNorm + ReLU + Dropout(0.2)
* Head   : 1 logit -> sigmoid
* Loss   : BCE with positive-class weighting (flood pixels are the minority)
* MC-Dropout at inference -> an uncertainty estimate alongside the probability

References
----------
Goodfellow, Bengio, Courville (2016) "Deep Learning", MLP fundamentals.
Gal & Ghahramani (2016) "Dropout as a Bayesian Approximation" (MC-Dropout).

Requires PyTorch (imported lazily). GPU if available, else CPU.
"""
from __future__ import annotations
import logging
import numpy as np

from .features import (build_feature_stack, stack_to_table, table_to_map,
                       weak_labels_from_detectors, balanced_sample)

L = logging.getLogger("flood.ml.mlp")


def _torch():
    import torch
    return torch


def _build_module(in_features: int, hidden=(128, 64, 32), p_drop=0.2):
    import torch.nn as nn
    layers, c = [], in_features
    for h in hidden:
        layers += [nn.Linear(c, h), nn.BatchNorm1d(h), nn.ReLU(inplace=True),
                   nn.Dropout(p_drop)]
        c = h
    layers += [nn.Linear(c, 1)]
    return nn.Sequential(*layers)


class FloodMLP:
    """Pixel-wise deep MLP flood classifier with MC-Dropout uncertainty."""

    def __init__(self, hidden=(128, 64, 32), p_drop=0.2, device=None):
        torch = _torch()
        self.hidden = tuple(hidden)
        self.p_drop = p_drop
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.net = None
        self.feature_names = None
        self._mean = None
        self._std = None

    def _fit_norm(self, Xt):
        self._mean = Xt.mean(0).astype(np.float32)
        self._std = (Xt.std(0) + 1e-6).astype(np.float32)

    def _norm(self, Xt):
        return ((Xt - self._mean) / self._std).astype(np.float32)

    # ---- training -------------------------------------------------------
    def fit_scene(self, inputs: dict, labels: np.ndarray | None = None,
                  permanent_water=None, epochs: int = 60, batch: int = 4096,
                  lr: float = 1e-3, n_per_class: int = 20000, pixel_m=10.0,
                  seed: int = 0):
        torch = _torch()
        import torch.nn.functional as F
        X, names = build_feature_stack(inputs, pixel_m=pixel_m)
        self.feature_names = names
        Xt = stack_to_table(X)
        if labels is None:
            labels = weak_labels_from_detectors(inputs, permanent_water)
        yt = np.asarray(labels).ravel()
        Xs, ys = balanced_sample(Xt, yt, n_per_class=n_per_class, seed=seed)
        self._fit_norm(Xs)
        Xs = self._norm(Xs)

        self.net = _build_module(Xs.shape[1], self.hidden, self.p_drop).to(self.device)
        xb = torch.from_numpy(Xs).to(self.device)
        yb = torch.from_numpy(ys.astype(np.float32))[:, None].to(self.device)
        pos_w = torch.tensor([(ys == 0).sum() / max(1, (ys == 1).sum())],
                             dtype=torch.float32, device=self.device)
        opt = torch.optim.Adam(self.net.parameters(), lr=lr, weight_decay=1e-5)
        n = xb.shape[0]
        self.net.train()
        for ep in range(epochs):
            perm = torch.randperm(n, device=self.device)
            tot = 0.0
            for i in range(0, n, batch):
                idx = perm[i:i + batch]
                opt.zero_grad()
                logits = self.net(xb[idx])
                loss = F.binary_cross_entropy_with_logits(logits, yb[idx],
                                                          pos_weight=pos_w)
                loss.backward(); opt.step()
                tot += float(loss) * len(idx)
            if ep % max(1, epochs // 6) == 0 or ep == epochs - 1:
                L.info("MLP epoch %d/%d loss=%.4f", ep + 1, epochs, tot / n)
        return self

    # ---- inference ------------------------------------------------------
    def predict_proba_scene(self, inputs: dict, pixel_m=10.0,
                            mc_passes: int = 1):
        """Return flood-probability (H, W). If mc_passes>1, also return a
        (H, W) MC-Dropout std-dev uncertainty map as the 2nd element."""
        torch = _torch()
        X, names = build_feature_stack(inputs, pixel_m=pixel_m)
        if self.feature_names and names != self.feature_names:
            L.warning("MLP feature mismatch trained=%s given=%s",
                      self.feature_names, names)
        H, W, _ = X.shape
        Xt = torch.from_numpy(self._norm(stack_to_table(X))).to(self.device)
        if mc_passes <= 1:
            self.net.eval()
            with torch.no_grad():
                p = torch.sigmoid(self._forward_batched(Xt)).cpu().numpy().ravel()
            return table_to_map(p, (H, W)).astype(np.float32)
        # MC-Dropout: keep dropout active across passes
        self.net.train()
        ps = []
        with torch.no_grad():
            for _ in range(mc_passes):
                ps.append(torch.sigmoid(self._forward_batched(Xt)).cpu().numpy().ravel())
        ps = np.stack(ps, 0)
        mean = table_to_map(ps.mean(0), (H, W)).astype(np.float32)
        std = table_to_map(ps.std(0), (H, W)).astype(np.float32)
        return mean, std

    def _forward_batched(self, Xt, batch=200000):
        torch = _torch()
        outs = []
        for i in range(0, Xt.shape[0], batch):
            outs.append(self.net(Xt[i:i + batch]))
        return torch.cat(outs, 0)

    def predict_scene(self, inputs: dict, threshold: float = 0.5, pixel_m=10.0,
                      mc_passes: int = 1) -> dict:
        res = self.predict_proba_scene(inputs, pixel_m=pixel_m, mc_passes=mc_passes)
        if isinstance(res, tuple):
            proba, unc = res
        else:
            proba, unc = res, None
        mask = (proba >= threshold).astype(np.uint8)
        info = {"method": "Pixel-MLP (PyTorch)", "hidden": list(self.hidden),
                "device": self.device, "threshold": threshold,
                "mc_passes": mc_passes,
                "flood_pixels": int(mask.sum()), "flood_fraction": float(mask.mean())}
        out = {"mask": mask, "confidence": proba, "info": info}
        if unc is not None:
            out["uncertainty"] = unc
        return out

    # ---- IO -------------------------------------------------------------
    def save(self, path: str):
        torch = _torch()
        torch.save({"state": self.net.state_dict(), "hidden": self.hidden,
                    "p_drop": self.p_drop, "feature_names": self.feature_names,
                    "mean": self._mean, "std": self._std,
                    "in_features": len(self.feature_names)}, path)
        L.info("saved MLP -> %s", path)

    @classmethod
    def load(cls, path: str, device=None) -> "FloodMLP":
        torch = _torch()
        d = torch.load(path, map_location="cpu", weights_only=False)
        obj = cls(hidden=d["hidden"], p_drop=d["p_drop"], device=device)
        obj.net = _build_module(d["in_features"], d["hidden"], d["p_drop"])
        obj.net.load_state_dict(d["state"]); obj.net.to(obj.device)
        obj.feature_names = d["feature_names"]
        obj._mean, obj._std = d["mean"], d["std"]
        return obj


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    rng = np.random.default_rng(3)
    H, W = 96, 120
    green = rng.uniform(0.05, 0.15, (H, W)).astype(np.float32)
    nir = rng.uniform(0.20, 0.35, (H, W)).astype(np.float32)
    swir1 = rng.uniform(0.15, 0.30, (H, W)).astype(np.float32)
    truth = np.zeros((H, W), np.uint8); truth[25:70, 30:95] = 1
    green[truth == 1] = 0.18; nir[truth == 1] = 0.03; swir1[truth == 1] = 0.02
    dem = (rng.uniform(0, 4, (H, W)) + np.linspace(0, 25, W)[None, :]).astype(np.float32)
    inputs = dict(green=green, nir=nir, swir1=swir1, blue=green * 0.9,
                  red=nir * 0.9, dem=dem)
    mlp = FloodMLP().fit_scene(inputs, labels=truth, epochs=40, n_per_class=1500)
    out = mlp.predict_scene(inputs, threshold=0.5, mc_passes=10)
    pred = out["mask"]
    iou = (np.logical_and(pred, truth).sum() /
           max(1, np.logical_or(pred, truth).sum()))
    print("MLP device:", out["info"]["device"], "| flood px %d (truth %d) | IoU=%.3f"
          % (pred.sum(), truth.sum(), iou))
    print("MC-Dropout mean uncertainty:", float(out.get("uncertainty").mean()))
    assert iou > 0.7
    print("OK - Pixel-MLP methodology self-test passed")
