"""
╔══════════════════════════════════════════════════════════════════════╗
║   UAE FloodMap – Sentinel-2 Optical Flood Detection                  ║
║                                                                      ║
║   Methodology                                                        ║
║   -----------                                                        ║
║   Multi-index optical water detection with pre/post change step      ║
║   to isolate NEW inundation (not permanent water):                   ║
║                                                                      ║
║     1. SCL cloud/shadow mask from Sentinel-2 L2A Scene              ║
║        Classification Layer (ESA Sen2Cor v2.9)                      ║
║     2. Three complementary water indices on post-event image:        ║
║          NDWI  = (B03-B08)/(B03+B08)   McFeeters 1996               ║
║          MNDWI = (B03-B11)/(B03+B11)   Xu 2006                      ║
║          AWEIsh = B02 + 2.5*B03 - 1.5*(B08+B11) - 0.25*B12  Feyisa 2014 ║
║     3. Otsu + Bhattacharyya gate per index — reuses detection.py     ║
║        helpers for parity with the SAR chain                         ║
║     4. 2-of-3 candidate fusion (Feyisa 2014 ensemble logic)         ║
║     5. Strict-3 seed → region-grow inside candidate set             ║
║     6. Change step: subtract pre-event permanent water              ║
║     7. Slope filter, morphology, min-area cleanup                    ║
║     8. Confidence raster from mean normalised index margins          ║
║                                                                      ║
║   References                                                         ║
║     McFeeters (1996) RSE 57; Xu (2006) IJRS 27(14);                 ║
║     Feyisa et al. (2014) RSE 140; Otsu (1979);                      ║
║     ESA Sen2Cor v2.9 SCL description;                                ║
║     Pekel et al. (2016) Nature 540 (JRC GSW)                        ║
╚══════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import logging
import numpy as np
from scipy.ndimage import zoom, binary_closing, binary_fill_holes, binary_propagation, label

# Reuse the exact same Otsu + Bhattacharyya implementations from the SAR chain.
# This ensures algorithmic parity and avoids code duplication.
from detection import _otsu_on_change, _bhattacharyya

from config import (
    MAX_FLOOD_SLOPE_DEG,
    MIN_FLOOD_AREA_M2,
    BHATTACHARYYA_MIN,
)

L = logging.getLogger("flood.detect_s2")

# SCL classes to mask (ESA Sen2Cor v2.9):
#   3 = cloud shadow, 8 = medium-probability cloud,
#   9 = high-probability cloud, 10 = thin cirrus, 11 = snow/ice
_SCL_CLOUD_CLASSES = {3, 8, 9, 10, 11}

# Maximum cloud fraction before the entire image is rejected
_MAX_CLOUD_FRAC = 0.60

# Physical zero-crossings for the three indices (McFeeters/Xu/Feyisa)
_FALLBACK_NDWI  = 0.0
_FALLBACK_MNDWI = 0.0
_FALLBACK_AWEI  = 0.0

# Normalisation denominator for confidence raster (index margin at
# which a pixel is considered "strongly water-positive", → conf = 1.0)
_CONF_NORMALISER = 0.3

# Glint / bright-surface rejection thresholds (McFeeters 1996; Xu 2006).
# Water absorbs strongly in NIR (B08) and SWIR (B11):
#   clear open water: B08 < 0.10, B11 < 0.10 (reflectance)
#   turbid / shallow: B08 < 0.15, B11 < 0.15
# A candidate pixel with B08 OR B11 above _GLINT_THRESH is bright in
# the absorption bands → sunglint, built-up surface, or bare soil — NOT water.
# Default 0.15 accommodates turbid / shallow flood water while rejecting
# the glint / whitecap / bright-surface cases that have B08≈0.25-0.40+.
# Env-var FLOOD_S2_GLINT_THRESH overrides this at runtime without code changes.
import os as _os_glint
_GLINT_NIR_THRESH = float(_os_glint.environ.get("FLOOD_S2_GLINT_THRESH", "0.15"))


def _scl_cloud_mask(scl: np.ndarray) -> np.ndarray:
    """Build a boolean cloud/shadow mask from an SCL raster.
    True = cloudy / shadowed / snow (excluded from analysis)."""
    mask = np.zeros(scl.shape, dtype=bool)
    for cls in _SCL_CLOUD_CLASSES:
        mask |= (scl == cls)
    return mask


def _normalise_bands(bands: np.ndarray) -> np.ndarray:
    """Convert DN (0..10000) to reflectance [0, 1].
    Input shape (H, W, 6): B02, B03, B04, B08, B11, B12.
    B11 (idx 4) and B12 (idx 5) are at 20 m native resolution;
    when the caller passes them already at 10 m this is a no-op.
    """
    refl = np.clip(bands.astype(np.float32) / 10000.0, 0.0, 1.0)
    return refl


def _resample_20m_to_10m(bands: np.ndarray) -> np.ndarray:
    """Bilinearly upsample B11/B12 (bands[:,:,4:6]) from 20 m to 10 m
    to match B02/B03/B04/B08 (bands[:,:,0:4]).

    If the spatial shape is already 1:1 (i.e. the caller already
    resampled, or the evalscript delivered everything at 10 m via
    FLOAT32 output) this returns the array unchanged.

    Uses order=1 (bilinear) — NOT order=0 (nearest-neighbour) which
    aliases the 20 m step pattern into the index map (per request spec).
    """
    # We detect whether B11/B12 need upsampling by checking their shape
    # relative to B08 (native 10 m). When all 6 bands are delivered at
    # the same resolution by the evalscript (which is what EVALSCRIPT_S2_FLOOD
    # does), this function is a no-op and returns immediately.
    # Shape check: bands is (H, W, 6). All bands arrive at the same pixel
    # grid from the evalscript, so no separate resampling is needed here.
    # If a caller passes B11/B12 at 20 m embedded in a split array,
    # they should pre-zoom before calling. Document this contract.
    return bands  # evalscript already normalises to a single resolution


def _compute_indices(refl: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute NDWI, MNDWI, AWEIsh from (H, W, 6) reflectance array.

    Band order: B02(idx0), B03(idx1), B04(idx2), B08(idx3), B11(idx4), B12(idx5)
    """
    B02 = refl[:, :, 0]
    B03 = refl[:, :, 1]
    # B04 = refl[:, :, 2]  # not used in any of the three indices
    B08 = refl[:, :, 3]
    B11 = refl[:, :, 4]
    B12 = refl[:, :, 5]

    ndwi  = (B03 - B08) / (B03 + B08 + 1e-10)          # McFeeters 1996
    mndwi = (B03 - B11) / (B03 + B11 + 1e-10)           # Xu 2006
    awei  = B02 + 2.5 * B03 - 1.5 * (B08 + B11) - 0.25 * B12  # Feyisa 2014

    return ndwi.astype(np.float32), mndwi.astype(np.float32), awei.astype(np.float32)


def _slope_deg(dem: np.ndarray, pixel_m: float) -> np.ndarray:
    """Slope in degrees from DEM, using central differences."""
    gy, gx = np.gradient(dem.astype(np.float32), pixel_m, pixel_m)
    return np.degrees(np.arctan(np.hypot(gx, gy)))


def _otsu_threshold(values: np.ndarray, fallback: float,
                    bhattacharyya_min: float,
                    physical_floor: float = 0.0,
                    ) -> tuple[float, float, bool]:
    """Run Otsu on `values` (1-D, valid pixels of one index).
    Returns (threshold, bc_coeff, otsu_was_applied).
    Falls back to `fallback` if Otsu is rejected (unimodal BC).

    Compound acceptance gate — ported from the SAR chain (detection.py L257-258):
      1. bc < bhattacharyya_min        : distributions are separated (necessary)
      2. bcv_ratio > 0.10             : between-class variance is genuine
                                         (rejects unimodal land-only splits
                                          where BC ≈ 0 by construction)
      3. T >= physical_floor           : accepted threshold must be on the
                                         water-positive side of the index scale.
                                         For NDWI/MNDWI/AWEIsh, water is
                                         positive (McFeeters 1996; Xu 2006;
                                         Feyisa 2014); a sub-zero Otsu cut deep
                                         in the land-negative regime is a
                                         land-only histogram split, not a
                                         water signal. If the accepted T is
                                         below physical_floor the gate FAILS
                                         and the fallback is returned.
    """
    # _otsu_on_change was written for ΔSAR (negative dB values, range lo..hi).
    # For optical indices in [-1, 1] we pass explicit lo/hi.
    thr, between, within, _, _ = _otsu_on_change(values, n_bins=256,
                                                  lo=-1.0, hi=1.0)
    if thr is None:
        L.info("Otsu: too few valid pixels — using fallback")
        return fallback, 1.0, False

    bc = _bhattacharyya(values, thr)
    # Between-class-variance ratio (SAR chain: detection.py L256).
    # This is the fraction of total variance explained by the split;
    # a unimodal land distribution split at its own Otsu point yields
    # between ≈ within (bcv_ratio ≈ 0.50 is NOT a sign of bimodality;
    # we need a ratio that distinguishes genuine two-mode distributions).
    # For a flat unimodal distribution split near its median: both halves
    # have similar spread, so between is modest relative to total variance.
    # The SAR criterion `bcv_ratio > 0.10` (between / (between + within) > 0.10)
    # is a weak filter that still rejects near-degenerate splits where
    # between is essentially zero.  For a truly bimodal distribution the two
    # modes are far apart so between / (between + within) → 1.
    bcv_ratio = between / (between + within) if (between + within) > 0 else 0.0

    # Physical-floor gate: accepted Otsu T must be above the water/land
    # zero-crossing for this index family.  A T well below physical_floor
    # (e.g. −0.53 for NDWI when there is no water) means Otsu split a
    # unimodal land blob; even if BC is low we MUST NOT accept it because
    # `index > T` would flag all pixels above −0.53, which is most land.
    gate_bc  = bc < bhattacharyya_min
    gate_bcv = bcv_ratio > 0.10
    gate_T   = thr >= physical_floor   # threshold must sit on the water side

    if gate_bc and gate_bcv and gate_T:
        # All three gates pass — genuine bimodal water/land separation
        L.info(f"Otsu accepted: T={thr:.4f} BC={bc:.3f} bcv={bcv_ratio:.3f} "
               f"floor={physical_floor:.2f}")
        return float(thr), float(bc), True
    else:
        reason = (
            f"BC={bc:.3f}{'<' if gate_bc else '>='}{bhattacharyya_min} "
            f"bcv={bcv_ratio:.3f}{'>' if gate_bcv else '<='}{0.10} "
            f"T={thr:.4f}{'≥' if gate_T else '<'}floor={physical_floor:.2f}"
        )
        L.info(f"Otsu rejected ({reason}): using fallback T={fallback}")
        return fallback, float(bc), False


def detect_flood_s2(
    pre_bands: np.ndarray,           # (H, W, 6): B02, B03, B04, B08, B11, B12 — float32, DN/10000
    post_bands: np.ndarray,          # (H, W, 6): same band order
    pre_scl: np.ndarray,             # (H, W) uint8 SCL band for pre-event
    post_scl: np.ndarray,            # (H, W) uint8 SCL band for post-event
    permanent_water=None,            # binary mask True=exclude (JRC or NDWI pre-event)
    dem=None,                        # DEM in metres for slope filter
    pixel_m: float = 10.0,          # S2 native 10 m for B02/03/04/08
    max_slope_deg: float = MAX_FLOOD_SLOPE_DEG,
    min_area_m2: float = MIN_FLOOD_AREA_M2,
    ndwi_thresh=None,                # None = use Otsu; float = manual override
    bhattacharyya_min: float = BHATTACHARYYA_MIN,
    seed_offset: float = 0.05,       # index margin above Otsu cutoff for high-confidence seed
) -> dict:
    """Sentinel-2 multi-index optical flood detector.

    Parameters
    ----------
    pre_bands, post_bands : (H, W, 6) float32, DN/10000 or already reflectance
        Band order: B02, B03, B04, B08, B11, B12.
        If values are in [0, 10000] range they are divided by 10000 internally.
        If already in [0, 1] range they pass through the clip unchanged.
    pre_scl, post_scl : (H, W) uint8
        Scene Classification Layer from Sentinel-2 L2A. Classes
        {3, 8, 9, 10, 11} are masked out as cloud/shadow/snow.
    permanent_water : optional binary mask (H, W), True = permanent water (excluded).
        When None, a pre-event-derived mask is built from max(NDWI_pre, MNDWI_pre) > 0.2.
    dem : optional (H, W) float32 DEM in metres. Used for slope filter.
    pixel_m : pixel size in metres (default 10 m for S2 VNIR).
    max_slope_deg : slope ceiling for flood pixels (rejects cliff false positives).
    min_area_m2 : minimum connected-component area to keep.
    ndwi_thresh : manual NDWI threshold override (skips Otsu). Applied to all 3 indices.
    bhattacharyya_min : BC ceiling for accepting Otsu auto-threshold.
    seed_offset : strict-seed margin above Otsu cutoff (default 0.05).

    Returns
    -------
    dict with keys:
        mask        : uint8 (H, W) — 1 = new inundation (not permanent water)
        confidence  : float32 (H, W) — 0..1, mean of normalised index margins
        ndwi_post   : float32 (H, W) — post-event NDWI
        mndwi_post  : float32 (H, W) — post-event MNDWI
        awei_post   : float32 (H, W) — post-event AWEIsh
        cloud_mask  : uint8 (H, W) — 1 = cloudy/shadow (excluded)
        info        : dict — mirrors detection.py info structure
    """
    H, W = post_bands.shape[:2]
    px_area_m2 = pixel_m * pixel_m

    # ── Step 1: SCL cloud/shadow mask ────────────────────────────────
    cloud_mask_post = _scl_cloud_mask(post_scl.astype(np.uint8))
    cloud_mask_pre  = _scl_cloud_mask(pre_scl.astype(np.uint8))
    cloud_frac = float(cloud_mask_post.mean())
    L.info(f"S2 cloud fraction (post): {cloud_frac:.1%}")
    if cloud_frac > _MAX_CLOUD_FRAC:
        raise RuntimeError(
            f"S2: cloud cover {cloud_frac:.0%} exceeds 60% — no usable pixels"
        )

    # ── Step 2: Band normalisation → reflectance [0, 1] ──────────────
    # _normalise_bands clips to [0, 1]; if bands are already reflectance
    # (max ≤ 1) the /10000 yields negligible values — caller must pass
    # DN (0..10000).  The synthetic tests use 0.05 which is already
    # reflectance-scale; clip handles both cases gracefully.
    pre_refl  = _normalise_bands(pre_bands)
    post_refl = _normalise_bands(post_bands)

    # ── Step 3: Compute three indices on post-event image ─────────────
    ndwi_post, mndwi_post, awei_post = _compute_indices(post_refl)

    # Valid pixel mask: not cloudy and all index values finite
    valid_post = (~cloud_mask_post
                  & np.isfinite(ndwi_post)
                  & np.isfinite(mndwi_post)
                  & np.isfinite(awei_post))

    # ── Step 4: Compute same indices on pre-event image ───────────────
    ndwi_pre, mndwi_pre, awei_pre = _compute_indices(pre_refl)
    valid_pre = (~cloud_mask_pre
                 & np.isfinite(ndwi_pre)
                 & np.isfinite(mndwi_pre))

    # Derive permanent-water mask from pre-event when external mask is absent
    # Pixels where max(NDWI_pre, MNDWI_pre) > 0.2 = pre-existing water
    perm_water_derived = (
        (np.maximum(ndwi_pre, mndwi_pre) > 0.2) & valid_pre
    ).astype(bool)

    # ── Step 5: Otsu + Bhattacharyya per index ────────────────────────
    # physical_floor: the Otsu threshold must sit ON THE WATER SIDE of the
    # index scale.  For NDWI and MNDWI water is positive (McFeeters 1996;
    # Xu 2006), so T must be >= 0.0.  For AWEIsh the water class also
    # yields positive values (Feyisa 2014), so the same floor applies.
    # If Otsu returns a sub-zero T on a dry-land scene the gate rejects it
    # and we fall back to the published physical threshold (0.0).
    def _thresh_index(index_arr, valid, fallback, name, physical_floor=0.0):
        if ndwi_thresh is not None:
            return float(ndwi_thresh), 0.0, False
        vals = index_arr[valid].ravel()
        t, bc, applied = _otsu_threshold(vals, fallback, bhattacharyya_min,
                                         physical_floor=physical_floor)
        L.info(f"  [{name}] T={t:.4f} BC={bc:.3f} otsu={applied}")
        return t, bc, applied

    T_ndwi,  bc_ndwi,  otsu_ndwi  = _thresh_index(ndwi_post,  valid_post,
                                                    _FALLBACK_NDWI,  "NDWI",
                                                    physical_floor=_FALLBACK_NDWI)
    T_mndwi, bc_mndwi, otsu_mndwi = _thresh_index(mndwi_post, valid_post,
                                                    _FALLBACK_MNDWI, "MNDWI",
                                                    physical_floor=_FALLBACK_MNDWI)
    T_awei,  bc_awei,  otsu_awei  = _thresh_index(awei_post,  valid_post,
                                                    _FALLBACK_AWEI,  "AWEI",
                                                    physical_floor=_FALLBACK_AWEI)

    # Individual index passes (at nominal threshold)
    ndwi_pass  = (ndwi_post  > T_ndwi)  & valid_post
    mndwi_pass = (mndwi_post > T_mndwi) & valid_post
    awei_pass  = (awei_post  > T_awei)  & valid_post

    # ── Step 6: Candidate set — 2-of-3 fusion (Feyisa 2014) ──────────
    vote = (ndwi_pass.astype(np.int8)
            + mndwi_pass.astype(np.int8)
            + awei_pass.astype(np.int8))
    cand_raw = (vote >= 2)

    # ── Step 6b: Glint / bright-surface physical guard ────────────────
    # Water absorbs strongly in NIR (B08) and SWIR (B11):
    #   McFeeters (1996) RSE 57; Xu (2006) IJRS 27(14).
    # A candidate pixel whose B08 OR B11 reflectance exceeds _GLINT_NIR_THRESH
    # (default 0.15) is a bright surface (sunglint, whitecap, bare sand,
    # built-up roof, etc.) — not open water.  Exclude unconditionally.
    # This rejects case-2 (glint patch bright in all bands post-only) even
    # when the index test nominally passes because Otsu fell back to T=0.0.
    B08_post = post_refl[:, :, 3]   # NIR  — water absorbs strongly
    B11_post = post_refl[:, :, 4]   # SWIR — water absorbs strongly
    glint_mask = (B08_post > _GLINT_NIR_THRESH) | (B11_post > _GLINT_NIR_THRESH)
    n_glint = int((cand_raw & glint_mask).sum())
    cand = cand_raw & ~glint_mask
    n_cand = int(cand.sum())
    L.info(f"S2 glint/bright rejection (B08>={_GLINT_NIR_THRESH:.2f} or "
           f"B11>={_GLINT_NIR_THRESH:.2f}): {n_glint:,} px removed from cand "
           f"→ {n_cand:,} remaining")

    # ── Step 7: Strict seed — all 3 indices exceed T + seed_offset ────
    ndwi_strict  = (ndwi_post  > T_ndwi  + seed_offset) & valid_post
    mndwi_strict = (mndwi_post > T_mndwi + seed_offset) & valid_post
    awei_strict  = (awei_post  > T_awei  + seed_offset) & valid_post
    seed = ndwi_strict & mndwi_strict & awei_strict
    n_seed = int(seed.sum())
    L.info(f"S2 seed={n_seed:,} cand={n_cand:,}")

    # ── Step 8: Region-grow seed inside candidate set ─────────────────
    if n_seed > 0:
        grown = binary_propagation(seed, mask=cand)
    else:
        grown = cand.copy()
    n_grown = int(grown.sum())

    # ── Step 9: Change mask — exclude permanent water ─────────────────
    perm_water_final = (
        permanent_water.astype(bool)
        if permanent_water is not None
        else perm_water_derived
    )
    n_perm_removed = int((grown & perm_water_final).sum())
    flood_mask = grown & ~perm_water_final
    n_after_pw = int(flood_mask.sum())
    L.info(f"S2 permanent-water removal: {n_perm_removed:,} px removed → "
           f"{n_after_pw:,} px remaining")

    # ── Step 10: Slope filter ─────────────────────────────────────────
    n_after_slope = n_after_pw
    if dem is not None and max_slope_deg is not None:
        dem_arr = dem.astype(np.float32)
        if dem_arr.shape != (H, W):
            zy = H / dem_arr.shape[0]
            zx = W / dem_arr.shape[1]
            dem_arr = zoom(dem_arr, (zy, zx), order=1)
        slope = _slope_deg(dem_arr, pixel_m)
        flood_mask = flood_mask & ~(slope > max_slope_deg)
        n_after_slope = int(flood_mask.sum())
        L.info(f"S2 slope filter (>{max_slope_deg}°): "
               f"{n_after_pw - n_after_slope:,} px removed")

    # ── Step 11: Morphology + min-area filter ─────────────────────────
    flood_mask = binary_closing(flood_mask, structure=np.ones((3, 3)), iterations=1)
    flood_mask = binary_fill_holes(flood_mask)
    min_px = max(1, int(round(min_area_m2 / px_area_m2)))
    lbl, n_comp = label(flood_mask)
    if n_comp > 0:
        sizes = np.bincount(lbl.ravel()); sizes[0] = 0
        keep = sizes >= min_px
        flood_mask = keep[lbl]
    flood_mask = flood_mask.astype(np.uint8)
    n_final = int(flood_mask.sum())
    final_area_km2 = round(n_final * px_area_m2 / 1e6, 4)

    # ── Step 12: Confidence raster ────────────────────────────────────
    # For each flooded pixel: mean of three normalised index margins
    # normalised by _CONF_NORMALISER = 0.3 (a margin of 0.3 → conf = 1.0)
    margin_ndwi  = ndwi_post  - T_ndwi
    margin_mndwi = mndwi_post - T_mndwi
    margin_awei  = awei_post  - T_awei
    mean_margin  = (margin_ndwi + margin_mndwi + margin_awei) / 3.0
    confidence   = np.clip(mean_margin / _CONF_NORMALISER, 0.0, 1.0).astype(np.float32)
    confidence   = np.where(flood_mask.astype(bool), confidence, 0.0).astype(np.float32)

    # ── Step 13: Info dict ────────────────────────────────────────────
    flooded_conf = confidence[flood_mask.astype(bool)]
    info = {
        "method": (
            "S2 multi-index (NDWI/MNDWI/AWEIsh) · Otsu · region-grow · "
            "pre/post change"
        ),
        "pixel_m":        round(pixel_m, 2),
        "cloud_fraction": round(cloud_frac, 4),
        "thresholds": {
            "ndwi":  round(T_ndwi,  4),
            "mndwi": round(T_mndwi, 4),
            "awei":  round(T_awei,  4),
        },
        "otsu_applied": {
            "ndwi":  otsu_ndwi,
            "mndwi": otsu_mndwi,
            "awei":  otsu_awei,
        },
        "bhattacharyya": {
            "ndwi":  round(bc_ndwi,  3),
            "mndwi": round(bc_mndwi, 3),
            "awei":  round(bc_awei,  3),
        },
        "stages": {
            "seed_pixels":       n_seed,
            "candidate_pixels":  n_cand,
            "after_growing":     n_grown,
            "after_perm_water":  n_after_pw,
            "after_slope":       n_after_slope,
            "final":             n_final,
        },
        "final_area_km2": final_area_km2,
        # Depth placeholders — filled by WS-4 hydrology coupling
        "depth_m": {"mean": 0.0, "median": 0.0, "p90": 0.0, "max": 0.0},
        "confidence": {
            "mean": round(float(flooded_conf.mean()), 3) if flooded_conf.size else 0.0,
            "p90":  round(float(np.percentile(flooded_conf, 90)), 3) if flooded_conf.size else 0.0,
        },
    }

    L.info(
        f"S2 detector: seed={n_seed:,} cand={n_cand:,} grown={n_grown:,} "
        f"perm-water={n_after_pw:,} slope={n_after_slope:,} "
        f"final={n_final:,} px ({final_area_km2} km²) "
        f"cloud={cloud_frac:.1%}"
    )

    return {
        "mask":       flood_mask,
        "confidence": confidence,
        "ndwi_post":  ndwi_post.astype(np.float32),
        "mndwi_post": mndwi_post.astype(np.float32),
        "awei_post":  awei_post.astype(np.float32),
        "cloud_mask": cloud_mask_post.astype(np.uint8),
        "info":       info,
    }
