"""
Round 5 — LIVE water-height test
=================================
Exercises the new GEE DEM fallback (download_dem_gee) and the full
depth pipeline (depth_from_precip_dem) over the Al Ain April-2024
flood event.

Steps
------
1. Fetch DEM via GEE (GLO30 → SRTM fallback) for the Al Ain ROI.
2. Re-use cached S2 flood mask from the Round-4 live test OR re-run
   detect_flood_s2 with a GEE S2 fetch.
3. Fetch ERA5 precipitation (open-meteo archive API) for Apr 1-30 2024.
   If the network call fails, fall back to the documented event total
   of 200 mm (published in UAE-NMS press release for the April 2024
   storm) and flag it explicitly.
4. Run depth_from_precip_dem with amc="II" and detected_mask=flood_mask.
5. Run build_advanced_stats.
6. Write a JSON summary to outputs/live_depth_r5_<timestamp>/.
"""
import os, sys, json, time, logging, datetime, pathlib
import numpy as np

# ── activate venv-resident packages if needed ─────────────────────────
_VENV = "/home/wassi/UAE_FloodMap/flood_v2/.venv"
_site = os.path.join(_VENV, "lib")
if os.path.isdir(_site):
    import glob as _glob
    for _sp in _glob.glob(os.path.join(_site, "python3*/site-packages")):
        if _sp not in sys.path:
            sys.path.insert(0, _sp)

# ── project root on path ──────────────────────────────────────────────
_ROOT = "/home/wassi/UAE_FloodMap/flood_v2"
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# ── env setup ─────────────────────────────────────────────────────────
os.environ.setdefault("S2_GEE_FALLBACK", "1")
os.environ.setdefault("EE_PROJECT", "ee-wassimehtp")

# Load .env (Bathymetry_VMarch) if it exists so GEE + other creds are present
_dotenv = "/home/wassi/Bathymetry_VMarch/.env"
if os.path.exists(_dotenv):
    with open(_dotenv) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip().strip('"').strip("'"))

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)-7s %(name)s  %(message)s",
                    datefmt="%H:%M:%S")
L = logging.getLogger("r5.live_depth")

# ── ROI: Al Ain, UAE — April 2024 flood event ─────────────────────────
BBOX_LIST = [55.73, 24.18, 55.82, 24.25]   # [W, S, E, N]
PRE_START, PRE_END   = "2024-04-01", "2024-04-14"
POST_START, POST_END = "2024-04-16", "2024-04-30"
PRECIP_DATE_END      = "2024-04-30"
PRECIP_LOOKBACK      = 30   # cover the full April event + API (5-day)

# The documented event total (UAE-NMS; WMO flash report).
# ERA5 may under-estimate the convective peak → we report both.
EVENT_PRECIP_DOCUMENTED_MM = 200.0

# Output directory
_TS = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
OUT_DIR = pathlib.Path(_ROOT) / "outputs" / f"live_depth_r5_{_TS}"
OUT_DIR.mkdir(parents=True, exist_ok=True)
L.info(f"Output directory: {OUT_DIR}")

results = {
    "timestamp": _TS,
    "fixture": "al_ain_apr2024",
    "bbox": BBOX_LIST,
    "steps": {}
}

# ─────────────────────────────────────────────────────────────────────
# STEP 1: Fetch GEE DEM
# ─────────────────────────────────────────────────────────────────────
L.info("=" * 60)
L.info("STEP 1 — Fetching DEM via GEE (GLO30 → SRTM fallback)")
L.info("=" * 60)

import downloader

try:
    t0 = time.time()
    dem = downloader.download_dem_gee(BBOX_LIST, target_shape=None, resolution=30.0)
    elapsed = time.time() - t0
    dem_ok = (
        dem.ndim == 2
        and dem.dtype == np.float32
        and float(dem.min()) > 0          # Al Ain is inland desert, >200 m
        and 200 <= float(dem.mean()) <= 400
    )
    step1 = {
        "status": "PASS" if dem_ok else "FAIL",
        "source": "GLO30_or_SRTM",
        "shape": list(dem.shape),
        "elev_min_m": round(float(dem.min()), 1),
        "elev_max_m": round(float(dem.max()), 1),
        "elev_mean_m": round(float(dem.mean()), 1),
        "elapsed_s": round(elapsed, 1),
        "sanity": "Al Ain ~250-350 m MSL — SANE" if dem_ok else "OUT OF EXPECTED RANGE",
    }
    L.info(f"DEM: {dem.shape}  elev [{dem.min():.1f}, {dem.max():.1f}] m  "
           f"mean={dem.mean():.1f} m  ({elapsed:.1f} s)")
except Exception as ex:
    L.error(f"DEM fetch FAILED: {ex}")
    step1 = {"status": "FAIL", "error": str(ex)}
    dem    = None

results["steps"]["step1_dem"] = step1

# ─────────────────────────────────────────────────────────────────────
# STEP 2: S2 flood mask (GEE)
# ─────────────────────────────────────────────────────────────────────
L.info("=" * 60)
L.info("STEP 2 — S2 flood detection via GEE (post Apr 16-30)")
L.info("=" * 60)

try:
    from sentinelhub import BBox, CRS
    bbox_sh = BBox(bbox=BBOX_LIST, crs=CRS.WGS84)
except Exception:
    # sentinelhub not importable; create a thin namedtuple stand-in
    from collections import namedtuple
    _BBox = namedtuple("BBox", ["min_x","min_y","max_x","max_y"])
    bbox_sh = _BBox(*BBOX_LIST)

# Try to reuse a previously cached mask from Round 4
_r4_cache_dir = pathlib.Path(_ROOT) / "outputs" / "cache"
_r4_mask_path = _r4_cache_dir / "al_ain_flood_mask_r4.npy"

flood_mask = None
s2_source  = None

if _r4_mask_path.exists():
    try:
        flood_mask = np.load(str(_r4_mask_path))
        s2_source  = "cached_r4"
        L.info(f"Loaded cached R4 flood mask: {flood_mask.shape} "
               f"({flood_mask.sum()} px flooded)")
    except Exception as ex:
        L.warning(f"Could not load R4 cache: {ex}")

if flood_mask is None:
    # Download S2 post-event scene from GEE and run detector
    t0 = time.time()
    try:
        pre_arr  = downloader.download_s2_flood_gee(
            BBOX_LIST, PRE_START, PRE_END, cloud=40, resolution=10.0)
        post_arr = downloader.download_s2_flood_gee(
            BBOX_LIST, POST_START, POST_END, cloud=40, resolution=10.0)

        pre_bands  = (pre_arr[:, :, :6]  / 10000.0).astype(np.float32)
        post_bands = (post_arr[:, :, :6] / 10000.0).astype(np.float32)
        pre_scl    = pre_arr[:, :, 6].astype(np.uint8)
        post_scl   = post_arr[:, :, 6].astype(np.uint8)

        from detection_s2 import detect_flood_s2
        import config
        det = detect_flood_s2(
            pre_bands, post_bands,
            pre_scl, post_scl,
            permanent_water=None,
            dem=dem,
            pixel_m=10.0,
            max_slope_deg=config.MAX_FLOOD_SLOPE_DEG,
            min_area_m2=config.MIN_FLOOD_AREA_M2,
        )
        flood_mask = det["mask"]
        s2_source  = "gee_live"
        elapsed_s2 = time.time() - t0

        # Cache for future runs
        _r4_cache_dir.mkdir(parents=True, exist_ok=True)
        np.save(str(_r4_mask_path), flood_mask)
        L.info(f"S2 detect: {flood_mask.sum()} flooded px  ({elapsed_s2:.1f} s)")
    except Exception as ex:
        L.error(f"S2 detection FAILED: {ex}")
        flood_mask = None
        s2_source  = f"FAILED: {ex}"

if flood_mask is None:
    L.error("No flood mask available — cannot run depth model")
    step2 = {"status": "FAIL", "error": s2_source}
else:
    pixel_m  = 10.0   # S2 10 m pixels
    px_area  = pixel_m ** 2
    flood_km2 = float(flood_mask.sum()) * px_area / 1e6
    step2 = {
        "status": "PASS",
        "source": s2_source,
        "shape": list(flood_mask.shape),
        "flooded_px": int(flood_mask.sum()),
        "flooded_km2": round(flood_km2, 4),
    }
    L.info(f"Flood mask: {flood_mask.shape}  {flood_mask.sum()} px "
           f"= {flood_km2:.4f} km²  source={s2_source}")

results["steps"]["step2_s2_mask"] = step2

# ─────────────────────────────────────────────────────────────────────
# STEP 3: ERA5 precipitation
# ─────────────────────────────────────────────────────────────────────
L.info("=" * 60)
L.info("STEP 3 — ERA5 precipitation fetch (open-meteo)")
L.info("=" * 60)

precip_total_mm   = None
precip_source     = None
era5_fetch_worked = False

try:
    t0 = time.time()
    raw_precip = downloader.download_precipitation_era5(
        bbox_sh, date_end=PRECIP_DATE_END, lookback_days=PRECIP_LOOKBACK)
    elapsed_p = time.time() - t0
    total_mm = float(raw_precip.get("total_mm", 0))
    if total_mm > 0:
        precip_total_mm   = total_mm
        precip_source     = f"ERA5 ({raw_precip.get('source','?')})"
        era5_fetch_worked = True
        L.info(f"ERA5: total={total_mm:.1f} mm  peak_day={raw_precip.get('peak_mm',0):.1f} mm  "
               f"({elapsed_p:.1f} s)")
    else:
        L.warning(f"ERA5 returned 0 mm — falling back to documented 200 mm")
except Exception as ex:
    L.warning(f"ERA5 fetch failed: {ex}")
    raw_precip = {}

if precip_total_mm is None or precip_total_mm == 0:
    precip_total_mm = EVENT_PRECIP_DOCUMENTED_MM
    precip_source   = "documented_200mm_UAE_NMS"
    era5_fetch_worked = False
    raw_precip = {
        "total_mm": precip_total_mm,
        "peak_mm":  precip_total_mm,
        "heavy_days": 2,
        "extreme_days": 1,
        "source": precip_source,
        "dates": ["2024-04-16", "2024-04-17"],
        "precip_mm": [150.0, 50.0],
    }

step3 = {
    "status": "PASS",
    "era5_network_ok": era5_fetch_worked,
    "precip_total_mm": round(precip_total_mm, 1),
    "precip_source": precip_source,
    "peak_day_mm": round(float(raw_precip.get("peak_mm", precip_total_mm)), 1),
}
if not era5_fetch_worked:
    step3["note"] = (
        "ERA5 network fetch returned 0 mm or failed. "
        "Using documented event total 200 mm (UAE-NMS / WMO flash report). "
        "This is EXPLICIT — not a silent substitution."
    )
L.info(f"Precip: {precip_total_mm:.1f} mm  source={precip_source}")
results["steps"]["step3_precip"] = step3

# ─────────────────────────────────────────────────────────────────────
# STEP 4: depth_from_precip_dem
# ─────────────────────────────────────────────────────────────────────
L.info("=" * 60)
L.info("STEP 4 — depth_from_precip_dem (SCS-CN + Manning)")
L.info("=" * 60)

step4 = {"status": "SKIP", "reason": "precondition not met"}

if flood_mask is not None and dem is not None:
    # Resample DEM to match flood_mask if shapes differ
    if dem.shape != flood_mask.shape:
        from scipy.ndimage import zoom as _zoom
        zy = flood_mask.shape[0] / dem.shape[0]
        zx = flood_mask.shape[1] / dem.shape[1]
        L.info(f"Resampling DEM {dem.shape} → {flood_mask.shape} "
               f"(zoom factors {zy:.3f}, {zx:.3f})")
        dem_r = _zoom(dem, (zy, zx), order=1).astype(np.float32)
    else:
        dem_r = dem

    import config
    from hydrology import depth_from_precip_dem

    try:
        t0 = time.time()
        depth, depth_stats = depth_from_precip_dem(
            flood_mask,
            dem_r,
            precip_total_mm=precip_total_mm,
            curve_number=config.CURVE_NUMBER,
            amc="II",
            antecedent_api=0.0,
            detected_mask=flood_mask,   # WS-4: zero depth outside mask
            manning_n=config.MANNING_N,
            storm_duration_h=config.STORM_DURATION_H,
            pixel_m=10.0,
            max_depth=config.MAX_WATER_DEPTH_M,
        )
        elapsed_d = time.time() - t0

        # Sanity checks
        depth_outside = float(depth[flood_mask == 0].max()) if (flood_mask == 0).any() else 0.0
        flooded_depth = depth[flood_mask.astype(bool)]
        pos_depth     = flooded_depth[flooded_depth > 0]
        mean_d  = float(pos_depth.mean())   if pos_depth.size > 0 else 0.0
        p90_d   = float(np.percentile(pos_depth, 90)) if pos_depth.size > 0 else 0.0
        max_d   = float(pos_depth.max())    if pos_depth.size > 0 else 0.0
        # hydrology.py returns volume under key "volume_m3" (depth * pixel_area sum);
        # build_advanced_stats recomputes it as "flood_volume_m3".  Use both:
        vol_m3  = float(depth_stats.get("volume_m3",
                         depth_stats.get("flood_volume_m3",
                          depth_stats.get("depth_volume_m3", 0.0))))
        # Check WS-4 invariant: depth outside mask must be 0
        ws4_ok  = depth_outside < 1e-6
        # Check physically sane range: mean 0.01..5 m; volume > 0
        phys_ok = (0.01 <= mean_d <= 10.0) and (vol_m3 > 0)

        step4 = {
            "status": "PASS" if (ws4_ok and phys_ok) else "FAIL",
            "elapsed_s": round(elapsed_d, 1),
            "depth_outside_mask_max_m": round(depth_outside, 6),
            "ws4_zero_outside_mask": ws4_ok,
            "mean_depth_m":  round(mean_d, 3),
            "p90_depth_m":   round(p90_d, 3),
            "max_depth_m":   round(max_d, 3),
            "flood_volume_m3": round(vol_m3, 0),
            "amc_used":       depth_stats.get("amc_used", "?"),
            "CN_adjusted":    round(float(depth_stats.get("CN_adjusted", 0)), 1),
            "runoff_Q_mm":    round(float(depth_stats.get("runoff_Q_mm", 0)), 2),
            "precip_total_mm": round(precip_total_mm, 1),
            "physically_sane": phys_ok,
        }
        L.info(f"Depth: mean={mean_d:.3f}m  p90={p90_d:.3f}m  max={max_d:.3f}m  "
               f"vol={vol_m3:.0f}m³  WS4={ws4_ok}  ({elapsed_d:.1f}s)")
    except Exception as ex:
        import traceback
        L.error(f"depth_from_precip_dem FAILED: {ex}")
        step4 = {"status": "FAIL", "error": str(ex),
                 "traceback": traceback.format_exc()}
        depth = None; depth_stats = {}
else:
    L.warning("Skipping depth model — flood_mask or DEM not available")
    depth = None; depth_stats = {}

results["steps"]["step4_depth"] = step4

# ─────────────────────────────────────────────────────────────────────
# STEP 5: build_advanced_stats
# ─────────────────────────────────────────────────────────────────────
L.info("=" * 60)
L.info("STEP 5 — build_advanced_stats")
L.info("=" * 60)

step5 = {"status": "SKIP", "reason": "precondition not met"}

if flood_mask is not None and depth is not None:
    from flood_stats import build_advanced_stats
    from precipitation import analyse_precipitation

    try:
        analysis = analyse_precipitation(raw_precip)
    except Exception as ex:
        L.warning(f"analyse_precipitation failed: {ex}; using stub")
        analysis = {
            "total_mm": precip_total_mm,
            "risk_score": 5,
            "return_period_est": "n/a",
            "regime": "uncalibrated",
        }

    try:
        conf_arr = np.ones(flood_mask.shape, dtype=np.float32) * 0.75

        roi_km2 = (flood_mask.shape[0] * flood_mask.shape[1] * 100.0) / 1e6
        adv = build_advanced_stats(
            flood_mask,
            depth.astype(np.float32),
            conf_arr,
            precip_analysis=analysis,
            streets_summary={},
            roi_km2=roi_km2,
            pixel_m=10.0,
            sensor="s2",
            regime=analysis.get("regime", "uncalibrated"),
        )
        # Check required keys
        required_keys = [
            "flooded_km2", "flood_volume_m3",
            "depth_m", "depth_band_km2",
            "severity", "quality_grade",
        ]
        missing = [k for k in required_keys if k not in adv]
        band_sum = sum(adv.get("depth_band_km2", {}).values())
        adv_flooded = adv.get("flooded_km2", 0.0)
        band_ok = (abs(band_sum - adv_flooded) < 0.001) or adv_flooded == 0.0

        step5 = {
            "status": "PASS" if (not missing and band_ok) else "FAIL",
            "flooded_km2":     round(float(adv.get("flooded_km2", 0)), 4),
            "flood_volume_m3": round(float(adv.get("flood_volume_m3", 0)), 0),
            "mean_depth_m":    round(float(adv.get("depth_m", {}).get("mean", 0)), 3),
            "p90_depth_m":     round(float(adv.get("depth_m", {}).get("p90", 0)), 3),
            "max_depth_m":     round(float(adv.get("depth_m", {}).get("max", 0)), 3),
            "depth_band_km2":  {k: round(v, 6) for k, v in adv.get("depth_band_km2", {}).items()},
            "depth_band_sum_km2": round(band_sum, 6),
            "band_sums_to_flooded": band_ok,
            "severity":        adv.get("severity", "?"),
            "quality_grade":   adv.get("quality_grade", "?"),
            "missing_keys":    missing,
        }
        L.info(f"advanced_stats: flooded={adv.get('flooded_km2',0):.4f}km²  "
               f"vol={adv.get('flood_volume_m3',0):.0f}m³  "
               f"severity={adv.get('severity')}  grade={adv.get('quality_grade')}")
    except Exception as ex:
        import traceback
        L.error(f"build_advanced_stats FAILED: {ex}")
        step5 = {"status": "FAIL", "error": str(ex),
                 "traceback": traceback.format_exc()}

results["steps"]["step5_advanced_stats"] = step5

# ─────────────────────────────────────────────────────────────────────
# Overall verdict
# ─────────────────────────────────────────────────────────────────────
all_pass = all(
    results["steps"][k].get("status") in ("PASS", "SKIP")
    for k in results["steps"]
)
# Must have PASS on the critical steps
critical_pass = all(
    results["steps"].get(k, {}).get("status") == "PASS"
    for k in ["step1_dem", "step2_s2_mask", "step4_depth", "step5_advanced_stats"]
)

results["overall"] = "PASS" if critical_pass else "FAIL"
results["era5_used"] = era5_fetch_worked
results["precip_source_final"] = precip_source

# 5-line headline summary
headline = [
    f"DEM: GLO30/SRTM via GEE  shape={step4.get('mean_depth_m','?')} — "
    f"elev [{results['steps']['step1_dem'].get('elev_min_m','?')}, "
    f"{results['steps']['step1_dem'].get('elev_max_m','?')}] m  "
    f"(sane={results['steps']['step1_dem'].get('sanity','?')})",
    f"Flood mask: {results['steps']['step2_s2_mask'].get('flooded_km2','?')} km²  "
    f"source={results['steps']['step2_s2_mask'].get('source','?')}",
    f"Precip: {precip_total_mm:.0f} mm  source={precip_source}  "
    f"(ERA5 network: {era5_fetch_worked})",
    f"Depth: mean={step4.get('mean_depth_m','?')} m  "
    f"p90={step4.get('p90_depth_m','?')} m  "
    f"max={step4.get('max_depth_m','?')} m  "
    f"vol={step4.get('flood_volume_m3','?')} m³  "
    f"WS4_zero_outside={step4.get('ws4_zero_outside_mask','?')}",
    f"advanced_stats: flooded={step5.get('flooded_km2','?')} km²  "
    f"severity={step5.get('severity','?')}  "
    f"grade={step5.get('quality_grade','?')}  "
    f"OVERALL={results['overall']}",
]
results["headline_5_lines"] = headline

# ─────────────────────────────────────────────────────────────────────
# Write JSON summary
# ─────────────────────────────────────────────────────────────────────
summary_path = OUT_DIR / "live_depth_r5_results.json"
with open(summary_path, "w") as f:
    json.dump(results, f, indent=2, default=str)

L.info("=" * 60)
L.info("SUMMARY")
L.info("=" * 60)
for line in headline:
    L.info(line)
L.info(f"OVERALL: {results['overall']}")
L.info(f"Results: {summary_path}")
print(f"\nResults written to: {summary_path}")
print(f"OVERALL: {results['overall']}")
for line in headline:
    print(" ", line)
