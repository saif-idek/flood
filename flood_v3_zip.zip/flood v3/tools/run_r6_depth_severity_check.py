#!/usr/bin/env python3
"""
Round-6 offline diagnostic: BUG 1 (S2 depth wiring) + BUG 2 (severity).

Drives hydrology.depth_from_precip_dem and flood_stats.build_advanced_stats
on a synthetic Al Ain fixture that reproduces the live evidence numbers:
  flooded_km2 ≈ 0.07, roi_km2 ≈ 70.64, total_mm ≈ 115.5, max_depth ≈ 1.5 m

Then verifies:
  1. The back-fill logic (BUG 1) produces s2_detection.depth_m.mean ≈
     advanced_stats.depth_m.mean (both non-zero).
  2. severity (BUG 2) is "moderate" for this case, NOT "severe".
  3. A large/deep flood still returns "severe" or "extreme".
  4. No-flood → severity "none".

Exit 0 = all assertions pass.
"""
from __future__ import annotations
import sys, os, json, logging, datetime
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

logging.basicConfig(
    level=logging.WARNING,  # silence hydrology verbose logs in the test
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
L = logging.getLogger("r6_check")
logging.getLogger("flood").setLevel(logging.WARNING)

# ── Al Ain synthetic fixture ──────────────────────────────────────────
# Reproduces the live run: 9.1×7.8 km ROI at 10 m → (780, 910) pixels,
# ~71 km² ROI, 0.07 km² flooded (71 flooded pixels at 10 m = 7100 m²).
PIXEL_M   = 10.0
ROI_KM2   = 70.64
SHAPE     = (780, 910)    # approximately right for the ROI

# Flooded pixels: 71 px ≈ 0.071 km²
MASK = np.zeros(SHAPE, dtype=np.uint8)
MASK[100:108, 200:209] = 1   # 72 flooded pixels (8×9)

# DEM: Al Ain plateau ~300 m, small depression over flood area
DEM = np.full(SHAPE, 300.0, dtype=np.float32)
DEM[100:108, 200:209] = 297.0   # 3 m lower → ~2–3 m water depth after routing

PRECIP_MM = 115.5   # ERA5/IFS025 estimate from live run

print("=" * 64)
print("Round-6 Offline Diagnostic: BUG 1 + BUG 2")
print("=" * 64)
print(f"  Fixture:   Al Ain synthetic  shape={SHAPE}")
print(f"  Flooded:   {MASK.sum()} px = {MASK.sum()*PIXEL_M**2/1e6:.4f} km²")
print(f"  ROI:       {ROI_KM2} km²  →  pct = {MASK.sum()*PIXEL_M**2/1e6/ROI_KM2*100:.3f}%")
print(f"  Precip:    {PRECIP_MM} mm")
print()

# ── Step 1: depth_from_precip_dem ────────────────────────────────────
from hydrology import depth_from_precip_dem

depth, depth_stats = depth_from_precip_dem(
    MASK, DEM,
    precip_total_mm=PRECIP_MM,
    curve_number=82.0,
    amc="II",
    antecedent_api=0.0,
    detected_mask=MASK,        # WS-4: zero outside mask
    manning_n=0.06,
    storm_duration_h=3.0,
    pixel_m=PIXEL_M,
    max_depth=5.0,
)
print("Step 1 — depth_from_precip_dem:")
print(f"  mean_depth_m  = {depth_stats['mean_depth_m']:.4f}")
print(f"  max_depth_m   = {depth_stats['max_depth_m']:.4f}")
print(f"  runoff_Q_mm   = {depth_stats['runoff_Q_mm']:.2f}")
print()

# ── Step 2: BUG 1 back-fill logic ─────────────────────────────────────
_flood_bool = MASK.astype(bool)
_pos = depth[_flood_bool]
_pos = _pos[_pos > 0]

if _pos.size > 0:
    s2_det_depth_m = {
        "mean":   round(float(_pos.mean()), 4),
        "median": round(float(np.median(_pos)), 4),
        "p90":    round(float(np.percentile(_pos, 90)), 4),
        "max":    round(float(_pos.max()), 4),
    }
else:
    s2_det_depth_m = {"mean": 0.0, "median": 0.0, "p90": 0.0, "max": 0.0}

print("Step 2 — s2_detection.depth_m (back-fill):")
for k, v in s2_det_depth_m.items():
    print(f"  {k}: {v}")
print()

# ── Step 3: build_advanced_stats ──────────────────────────────────────
from flood_stats import build_advanced_stats

precip_analysis = {
    "total_mm":         PRECIP_MM,
    "return_period_est":"10-25 year",
    "regime":           "BWh_uae",
    "risk_score":       3,
}
conf = np.zeros(SHAPE, dtype=np.float32)
conf[MASK > 0] = 0.85

adv = build_advanced_stats(
    MASK, depth.astype(np.float32), conf,
    precip_analysis=precip_analysis,
    streets_summary={},
    roi_km2=ROI_KM2, pixel_m=PIXEL_M,
    sensor="s2",
    regime="BWh_uae",
)

print("Step 3 — advanced_stats:")
print(f"  flooded_km2          = {adv['flooded_km2']:.4f}")
print(f"  flooded_pct_roi      = {adv['flooded_pct_roi']:.3f}%")
print(f"  depth_m.mean         = {adv['depth_m']['mean']:.4f}")
print(f"  depth_m.max          = {adv['depth_m']['max']:.4f}")
print(f"  severity             = {adv['severity']!r}")
print(f"  quality_grade        = {adv['quality_grade']!r}")
print()

# ── Assertions ────────────────────────────────────────────────────────
failures = []

# BUG 1: s2_detection.depth_m.mean must equal advanced_stats.depth_m.mean
delta_mean = abs(s2_det_depth_m["mean"] - adv["depth_m"]["mean"])
if delta_mean > 1e-3:
    failures.append(f"BUG 1 FAIL: s2_det.mean={s2_det_depth_m['mean']:.4f} "
                    f"!= adv.mean={adv['depth_m']['mean']:.4f}  delta={delta_mean:.6f}")
else:
    print(f"BUG 1 PASS: depth_m.mean match  (delta={delta_mean:.6f})")

if s2_det_depth_m["mean"] == 0.0:
    failures.append("BUG 1 FAIL: s2_detection.depth_m.mean is still 0.0")
else:
    print(f"BUG 1 PASS: depth_m.mean > 0  ({s2_det_depth_m['mean']:.4f} m)")

# BUG 2: Al Ain-like case (tiny extent + deep wadi) must be moderate, not severe
from flood_stats import _severity
sev_live = _severity(False, PRECIP_MM, adv["flooded_pct_roi"], adv["depth_m"]["max"])
if sev_live in ("severe", "extreme"):
    failures.append(f"BUG 2 FAIL: severity={sev_live!r} for tiny-extent case "
                    f"(extent={adv['flooded_pct_roi']:.3f}%, max={adv['depth_m']['max']:.2f}m)")
else:
    print(f"BUG 2 PASS: severity={sev_live!r}  (not 'severe' for tiny-extent/1.5m-max)")

# Empty flood → none
sev_none = _severity(True, 0.0, 0.0, 0.0)
if sev_none != "none":
    failures.append(f"BUG 2 FAIL: empty flood → {sev_none!r} (expected 'none')")
else:
    print(f"BUG 2 PASS: empty flood → 'none'")

# Large deep flood → severe or extreme
sev_big = _severity(False, 300.0, 30.0, 3.5)
if sev_big not in ("severe", "extreme"):
    failures.append(f"BUG 2 FAIL: large deep flood → {sev_big!r} (expected severe/extreme)")
else:
    print(f"BUG 2 PASS: large deep flood → {sev_big!r}")

# Import check (app.py + flood_stats clean import)
try:
    import importlib, flood_stats
    importlib.reload(flood_stats)
    print("Import PASS: flood_stats clean reload")
except Exception as ex:
    failures.append(f"Import FAIL: flood_stats: {ex}")

print()
print("=" * 64)
if failures:
    for f in failures:
        print(f"  FAIL: {f}")
    print(f"\nR6 check: {len(failures)} failure(s)")
    sys.exit(1)
else:
    print("  All R6 assertions PASS")
    print()
    print("SUMMARY:")
    print(f"  s2_detection.depth_m.mean (before fix) = 0.0000  [placeholder]")
    print(f"  s2_detection.depth_m.mean (after fix)  = {s2_det_depth_m['mean']:.4f}  [HEC-HMS]")
    print(f"  advanced_stats.depth_m.mean            = {adv['depth_m']['mean']:.4f}  [same]")
    print(f"  severity (before fix) = 'severe'  [0.09% ROI, 1.5m max → wrong]")
    print(f"  severity (after fix)  = {adv['severity']!r}  [{adv['flooded_pct_roi']:.3f}% ROI, {adv['depth_m']['max']:.2f}m max]")
    sys.exit(0)
