"""
Round-3 adversarial regression test for detection_s2.py and flood_stats.py.

Reproduces the verifier's 7 adversarial cases:
  Case 1 — DRY identical pre==post land scene  → 0 flood px
  Case 2 — Sunglint bright patch (high B08/B11 post-only) → 0 flood px
  Case 3 — Cloud patch in post (SCL=9) → cloud region excluded
  Case 4 — Turbid urban water (pos MNDWI, marginal NDWI) → finite, no crash
  Case 5 — Permanent lake in both pre+post → excluded
  Case 6 — >60% cloud → RuntimeError
  Case 7 — NaN injection in depth → finite volume (not nan)

Additional case added for Round-3:
  Case NaN-vol — NaN/inf depth pixel inside flood mask → volume stays finite
                  (flood_stats.py guard).
"""
import sys
import os
import json
import numpy as np
import datetime

# Add the flood_v2 root to sys.path so we can import our modules
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path.insert(0, _ROOT)

from detection_s2 import detect_flood_s2
from flood_stats import build_advanced_stats


# ── Utility ──────────────────────────────────────────────────────────────────

def _make_scene(H=80, W=80,
                ndwi=-0.53, mndwi=-0.46, b08=0.30, b11=0.25,
                add_scl_cloud=False):
    """
    Build a simple synthetic S2 scene.

    Band order: B02, B03, B04, B08, B11, B12 (all already reflectance [0,1]).
    The detector divides by 10000 internally via _normalise_bands; since
    values <= 1 the clip(b/10000, 0,1) ≈ 0 — so we pass values already scaled
    to reflectance and note that _normalise_bands clips but DOES NOT multiply:
    """
    # Actually _normalise_bands does /10000, so we must pass DN-scale values.
    # reflectance r → DN = r * 10000 (so the /10000 recovers r).
    # Keep ndwi arithmetic in reflectance and compute B03/B08 from ndwi:
    # ndwi = (B03 - B08) / (B03 + B08) → B03 = B08 * (1+ndwi)/(1-ndwi)
    # For simplicity: fix B08, derive B03 from ndwi.
    b08_r = float(b08)
    if abs(ndwi - 1.0) > 1e-6:
        b03_r = b08_r * (1.0 + ndwi) / (1.0 - ndwi + 1e-10)
    else:
        b03_r = 1.0
    b03_r = max(0.01, min(0.99, b03_r))

    b11_r = float(b11)
    # mndwi = (B03 - B11)/(B03 + B11) → derive B11 to match
    # b11_r = b03_r * (1 - mndwi) / (1 + mndwi + 1e-10)
    # Use the supplied b11 directly (caller controls mndwi vs b11 independently)

    b02_r = 0.05
    b04_r = 0.08
    b12_r = b11_r * 0.8  # roughly proportional

    # Build (H, W, 6) in DN (× 10000)
    bands = np.zeros((H, W, 6), dtype=np.float32)
    bands[:, :, 0] = b02_r * 10000   # B02
    bands[:, :, 1] = b03_r * 10000   # B03
    bands[:, :, 2] = b04_r * 10000   # B04
    bands[:, :, 3] = b08_r * 10000   # B08 (NIR)
    bands[:, :, 4] = b11_r * 10000   # B11 (SWIR)
    bands[:, :, 5] = b12_r * 10000   # B12

    scl = np.full((H, W), 4, dtype=np.uint8)   # 4 = vegetation (clear)
    if add_scl_cloud:
        # Cloud a 10×10 patch in the top-left
        scl[:10, :10] = 9
    return bands, scl


def _run_detect(pre_bands, post_bands, pre_scl, post_scl,
                permanent_water=None, dem=None, pixel_m=10.0):
    return detect_flood_s2(
        pre_bands, post_bands, pre_scl, post_scl,
        permanent_water=permanent_water, dem=dem, pixel_m=pixel_m,
    )


# ── Individual test functions ─────────────────────────────────────────────────

def test_case1_dry_identical():
    """Dry land: identical pre==post. All NDWI/MNDWI deeply negative. → 0 px."""
    H, W = 80, 80
    bands, scl = _make_scene(H=H, W=W, ndwi=-0.53, mndwi=-0.46, b08=0.30, b11=0.25)
    pre_bands = bands.copy()
    post_bands = bands.copy()   # IDENTICAL — zero change
    pre_scl = scl.copy()
    post_scl = scl.copy()

    result = _run_detect(pre_bands, post_bands, pre_scl, post_scl)
    n_px = int(result["mask"].sum())
    km2  = result["info"]["final_area_km2"]
    status = "PASS" if n_px == 0 else "FAIL"
    return {
        "case": "1_dry_identical",
        "status": status,
        "flood_px": n_px,
        "flood_km2": km2,
        "before_fix": 6038,
        "note": "NDWI≈-0.53, identical pre/post → must be 0 px",
    }


def test_case2_glint():
    """
    Sunglint / bright surface: post has high B08 and B11 (NIR/SWIR bright).
    Even if NDWI nominally passes (because pre is dark), the NIR/SWIR guard
    must reject the glint patch.
    """
    H, W = 80, 80
    # Pre: dry land, dark (low reflectance)
    pre_bands, pre_scl = _make_scene(H=H, W=W, ndwi=-0.53, mndwi=-0.46,
                                      b08=0.05, b11=0.04)
    # Post: bright sunglint patch — all bands high, B08=0.35, B11=0.30
    # This makes NDWI positive (bright in B03 too), but B08/B11 are well above
    # the 0.15 glint threshold → physical guard must reject.
    glint_b08 = 0.35
    glint_b11 = 0.30
    # ndwi = (B03-B08)/(B03+B08). For glint: B03≈0.25, B08≈0.35 → ndwi≈-0.17
    # mndwi = (B03-B11)/(B03+B11) with B11=0.30, B03=0.25 → mndwi≈-0.09
    # Both are negative, but glint may push them near/above 0 in some configs.
    # Use a worst-case: B03=0.40, B08=0.35 → ndwi = (0.40-0.35)/(0.75)=+0.067
    post_bands, post_scl = _make_scene(H=H, W=W, ndwi=+0.067, mndwi=-0.09,
                                        b08=glint_b08, b11=glint_b11)

    # Permanent water = None so pre-derived perm water is used (pre is dark → 0)
    result = _run_detect(pre_bands, post_bands, pre_scl, post_scl)
    n_px = int(result["mask"].sum())
    km2  = result["info"]["final_area_km2"]
    status = "PASS" if n_px == 0 else "FAIL"
    return {
        "case": "2_glint",
        "status": status,
        "flood_px": n_px,
        "flood_km2": km2,
        "before_fix": 400,
        "note": f"Glint B08={glint_b08} B11={glint_b11} → must be 0 px after NIR/SWIR guard",
    }


def test_case3_cloud_excluded():
    """Cloud patch (SCL=9) in post image → cloud pixels excluded (0 flood there)."""
    H, W = 80, 80
    # Pre: dry land
    pre_bands, pre_scl = _make_scene(H=H, W=W, ndwi=-0.53, mndwi=-0.46,
                                      b08=0.30, b11=0.25)
    # Post: same dry land but with a cloud patch in top-left 20×20
    post_bands = pre_bands.copy()
    post_scl = pre_scl.copy()
    post_scl[:20, :20] = 9   # high-probability cloud

    result = _run_detect(pre_bands, post_bands, pre_scl, post_scl)
    # Cloud region flood count should be 0
    cloud_region_flood = int(result["mask"][:20, :20].sum())
    status = "PASS" if cloud_region_flood == 0 else "FAIL"
    total_px = int(result["mask"].sum())
    return {
        "case": "3_cloud_excluded",
        "status": status,
        "cloud_region_flood_px": cloud_region_flood,
        "total_flood_px": total_px,
        "note": "Cloud (SCL=9) region must have 0 flood px",
    }


def test_case4_turbid_water():
    """Turbid urban water: positive MNDWI, low NIR/SWIR — should not crash."""
    H, W = 80, 80
    # Pre: dry land
    pre_bands, pre_scl = _make_scene(H=H, W=W, ndwi=-0.40, mndwi=-0.30,
                                      b08=0.20, b11=0.15)
    # Post: turbid water — low NIR/SWIR (so passes glint guard), positive MNDWI
    # B03=0.20, B11=0.05 → mndwi=(0.20-0.05)/(0.25)=+0.60
    # B08=0.05 (low NIR = water)
    post_bands, post_scl = _make_scene(H=H, W=W, ndwi=+0.20, mndwi=+0.60,
                                        b08=0.05, b11=0.05)

    try:
        result = _run_detect(pre_bands, post_bands, pre_scl, post_scl)
        # Should not crash; result should be finite
        n_px = int(result["mask"].sum())
        km2  = result["info"]["final_area_km2"]
        ok   = np.isfinite(km2)
        status = "PASS" if ok else "FAIL"
        return {
            "case": "4_turbid_water",
            "status": status,
            "flood_px": n_px,
            "flood_km2": km2,
            "note": "Turbid water with low B08/B11 → should give finite result, no crash",
        }
    except Exception as e:
        return {
            "case": "4_turbid_water",
            "status": "FAIL",
            "error": str(e),
            "note": "Should not crash",
        }


def test_case5_permanent_lake():
    """Permanent lake in both pre and post → excluded by change step → 0 px."""
    H, W = 80, 80
    # Both pre and post are water (positive NDWI/MNDWI, low B08/B11)
    lake_bands, lake_scl = _make_scene(H=H, W=W, ndwi=+0.50, mndwi=+0.60,
                                        b08=0.04, b11=0.03)
    # Permanent lake: both pre and post have the same water signature
    result = _run_detect(lake_bands, lake_bands.copy(), lake_scl, lake_scl.copy())
    n_px = int(result["mask"].sum())
    status = "PASS" if n_px == 0 else "FAIL"
    return {
        "case": "5_permanent_lake",
        "status": status,
        "flood_px": n_px,
        "note": "Permanent lake in pre+post → should be 0 (change step removes it)",
    }


def test_case6_high_cloud():
    """>60% cloud fraction → RuntimeError."""
    H, W = 80, 80
    bands, scl = _make_scene(H=H, W=W)
    # Make >60% of post image cloudy
    post_scl = scl.copy()
    n_cloud_rows = int(0.65 * H)
    post_scl[:n_cloud_rows, :] = 9   # 65% cloud

    try:
        result = detect_flood_s2(bands, bands.copy(), scl, post_scl)
        return {
            "case": "6_high_cloud",
            "status": "FAIL",
            "note": "Expected RuntimeError but got a result",
        }
    except RuntimeError as e:
        return {
            "case": "6_high_cloud",
            "status": "PASS",
            "exception": str(e),
            "note": ">60% cloud → RuntimeError raised",
        }
    except Exception as e:
        return {
            "case": "6_high_cloud",
            "status": "FAIL",
            "error": type(e).__name__ + ": " + str(e),
            "note": "Unexpected exception type",
        }


def test_case7_nan_injection():
    """NaN injected into depth inside flood mask → flood_volume_m3 is finite."""
    flood_mask = np.zeros((10, 10), dtype=np.uint8)
    flood_mask[2:6, 2:6] = 1   # 4×4 = 16 px flooded

    depth = np.full((10, 10), 0.5, dtype=np.float32)
    depth[3, 3] = np.nan   # single NaN inside the flood mask
    depth[4, 4] = np.inf   # single inf inside the flood mask

    confidence = np.full((10, 10), 0.7, dtype=np.float32)
    precip_analysis = {"total_mm": 50.0, "return_period_est": "n/a", "regime": "arid"}
    streets_summary = {}
    roi_km2 = 1.0

    stats = build_advanced_stats(
        flood_mask, depth, confidence,
        precip_analysis=precip_analysis,
        streets_summary=streets_summary,
        roi_km2=roi_km2,
        pixel_m=10.0,
        sensor="s2",
    )
    vol = stats["flood_volume_m3"]
    finite = np.isfinite(vol)
    # Volume should be positive and finite; the two bad pixels contribute 0
    # Expected: (16 - 2 bad px) × 0.5 m × 100 m² = 14 × 50 = 700 m³
    expected_vol = 14 * 0.5 * 100.0
    status = "PASS" if (finite and vol >= 0) else "FAIL"
    return {
        "case": "7_nan_depth_volume",
        "status": status,
        "flood_volume_m3": vol,
        "expected_approx": expected_vol,
        "finite": bool(finite),
        "note": "NaN/inf in depth → volume must be finite and non-negative",
    }


# ── Main runner ───────────────────────────────────────────────────────────────

def main():
    ts = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(_ROOT, "outputs", f"adversarial_r3_{ts}")
    os.makedirs(out_dir, exist_ok=True)

    tests = [
        test_case1_dry_identical,
        test_case2_glint,
        test_case3_cloud_excluded,
        test_case4_turbid_water,
        test_case5_permanent_lake,
        test_case6_high_cloud,
        test_case7_nan_injection,
    ]

    results = {}
    all_pass = True
    for fn in tests:
        r = fn()
        key = r["case"]
        results[key] = r
        status = r["status"]
        if status != "PASS":
            all_pass = False
        note = r.get("note", "")
        print(f"  [{status}] {key}: {note}")
        if status == "FAIL":
            # Print extra diagnostic info
            for k, v in r.items():
                if k not in ("case", "status", "note"):
                    print(f"         {k}: {v}")

    summary = {
        "timestamp": ts,
        "all_pass": all_pass,
        "tests": results,
    }

    out_path = os.path.join(out_dir, "adversarial_r3_results.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, default=str)
    print(f"\nResults written to: {out_path}")

    if all_pass:
        print("\nALL ADVERSARIAL CASES: PASS")
        return 0
    else:
        failed = [k for k, v in results.items() if v["status"] != "PASS"]
        print(f"\nFAILED cases: {failed}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
