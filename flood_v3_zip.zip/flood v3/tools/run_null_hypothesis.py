#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║   UAE_FloodMap — Null-Hypothesis Regression Harness  (Tier 1, NF-*) ║
║                                                                      ║
║   Drives the platform's pipelines via direct Python imports — no    ║
║   Flask, no Sentinel Hub. Two fixtures are exercised:                ║
║                                                                      ║
║     1. CASABLANCA_DRY  — Mediterranean dry-window (no rain, no SAR  ║
║        Δ-σ⁰). Asserts NF-01..NF-05: dry precipitation ⇒ flooded_km² ║
║        = 0, mean_depth = 0, affected_streets_km = 0; pre/pre SAR    ║
║        pair must yield bimodal=False; ocean pixels excluded; risk-   ║
║        score = 0; no_flood_detected = True.                          ║
║                                                                      ║
║     2. ABU_DHABI_2026  — UAE flood-event control. Asserts the        ║
║        Mar-2026 baseline still returns final_area_km² > 0 and the    ║
║        25–50 yr return-period (no UAE regression).                   ║
║                                                                      ║
║   Output: outputs/null_hypothesis_results.json with the schema      ║
║     {fixture, tests:{NF-01..NF-05:{status,expected,got,...}},       ║
║      summary:{passed,failed}}. Exit code is non-zero on any FAIL.   ║
║                                                                      ║
║   Standards: Copernicus EMS Rapid Mapping Product Manual            ║
║              (false-positive rate < 5 %); Bauer-Marschallinger      ║
║              et al. 2022 (GFM Sentinel-1 operational validation);   ║
║              Twele et al. 2016 (Otsu + region-growing).             ║
╚══════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import datetime as dt
import json
import logging
import os
import sys
import time
from pathlib import Path

import numpy as np

# ── make the flood_v2 package importable ──────────────────────────────
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

LOG = logging.getLogger("flood.null")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)

# ── Fixtures ──────────────────────────────────────────────────────────
FIXTURE_DIR = Path(os.environ.get(
    "FLOOD_NULL_FIXTURE_DIR",
    str(HERE / "fixtures"),
)).resolve()
FIXTURE_DIR.mkdir(parents=True, exist_ok=True)

CASABLANCA_DRY = {
    "name":                "casablanca_dry",
    "bbox":                (-7.70, 33.50, -7.55, 33.62),
    "before_start":        "2024-08-15", "before_end": "2024-08-22",
    "after_start":         "2024-08-29", "after_end":  "2024-09-05",
    "simulation_date":     "2024-09-05",
    "lookback_days":       21,
}

# Same lon/lat band but extended ~5 km offshore for NF-03 ocean test.
CASABLANCA_COAST = {
    "name": "casablanca_coast",
    "bbox": (-7.75, 33.55, -7.55, 33.65),
}

ABU_DHABI_2026 = {
    "name":                "abu_dhabi_2026",
    "bbox":                (54.30, 24.30, 54.55, 24.50),
    "after_end":           "2026-03-12",
    "lookback_days":       21,
}


# ── Synthetic SAR fixture builder (constant pre/pre pair) ─────────────
def _make_synthetic_pre_pre(shape=(128, 128, 2), level=0.05, seed=7):
    """Build a NF-02 canonical pre/pre fixture.

    Linear-power VV/VH stack with a tiny multiplicative speckle around a
    fixed mean. Returning the SAME constant array twice (i.e. before ==
    after) produces a ΔSAR distribution centred on 0 dB — no flood
    candidate should survive Otsu's bimodal test on this. We persist
    one fixture file so the test is deterministic across runs.
    """
    rng = np.random.default_rng(seed)
    base = np.full(shape, float(level), dtype=np.float32)
    # tiny multiplicative speckle (±~3 %) on linear power so refined-Lee
    # does not divide by zero variance.
    base *= (1.0 + 0.03 * rng.standard_normal(shape).astype(np.float32))
    base = np.clip(base, 1e-6, None)
    return base


def _load_or_make_fixture(name="casablanca_pre_pre", shape=(128, 128, 2)):
    """Cache the synthetic fixture on disk so subsequent runs are fast."""
    fp = FIXTURE_DIR / f"{name}.npz"
    if fp.exists():
        try:
            d = np.load(fp)
            arr = d["arr"]
            if arr.shape == shape:
                LOG.info(f"[fixture] reusing {fp.name} shape={arr.shape}")
                return arr.astype(np.float32)
        except Exception as ex:
            LOG.warning(f"[fixture] reload failed ({ex}); regenerating")
    arr = _make_synthetic_pre_pre(shape=shape)
    np.savez(fp, arr=arr)
    LOG.info(f"[fixture] wrote {fp.name} shape={arr.shape}")
    return arr


# ── Synthetic ROI helpers ─────────────────────────────────────────────
def _flat_dem(shape, elev_m=20.0):
    return np.full(shape, float(elev_m), dtype=np.float32)


def _coastal_dem(shape):
    """Half-ocean (DEM = 0) + half-land (DEM ~ 5-15 m). Used for NF-03."""
    h, w = shape
    dem = np.zeros((h, w), dtype=np.float32)
    dem[:, : w // 2] = 0.0                          # ocean (≤ 0.5 m)
    dem[:, w // 2 :] = np.linspace(5.0, 15.0, w - w // 2)[None, :]
    return dem


def _zero_precip_data(start="2024-08-15", days=21, bbox=None):
    """ERA5-shaped dict with zero precipitation. NF-01 fixture."""
    d0 = dt.datetime.strptime(start, "%Y-%m-%d")
    dates = [(d0 + dt.timedelta(days=i)).strftime("%Y-%m-%d")
             for i in range(days)]
    return {
        "dates":           dates,
        "precip_mm":       [0.0] * days,
        "precip_mean_mm":  [0.0] * days,
        "rain_mm":         [0.0] * days,
        "snow_mm":         [0.0] * days,
        "et0_mm":          [4.0] * days,
        "total_mm":        0.0,
        "total_mean_mm":   0.0,
        "peak_mm":         0.0,
        "heavy_days":      0,
        "extreme_days":    0,
        "lookback_days":   days,
        "n_sample_points": 1,
        "source":          "synthetic-null",
        "bbox":            bbox,
    }


def _ad_2026_precip_data(bbox):
    """Synthetic Abu Dhabi Mar-2026 precipitation — peaks at ~110 mm/3-day
    so the BWh_uae return-period table reports 25-50 yr."""
    days = 14
    d0 = dt.datetime.strptime("2026-02-26", "%Y-%m-%d")
    dates = [(d0 + dt.timedelta(days=i)).strftime("%Y-%m-%d")
             for i in range(days)]
    # convective burst over 2 days + tail
    daily = [0.0] * days
    daily[8]  = 55.0
    daily[9]  = 60.0
    daily[10] = 8.0
    return {
        "dates":           dates,
        "precip_mm":       daily,
        "precip_mean_mm":  [v * 0.6 for v in daily],
        "rain_mm":         daily,
        "snow_mm":         [0.0] * days,
        "et0_mm":          [6.0] * days,
        "total_mm":        sum(daily),
        "total_mean_mm":   sum(v * 0.6 for v in daily),
        "peak_mm":         max(daily),
        "heavy_days":      sum(1 for v in daily if v >= 20),
        "extreme_days":    sum(1 for v in daily if v >= 50),
        "lookback_days":   days,
        "n_sample_points": 1,
        "source":          "synthetic-control",
        "bbox":            bbox,
    }


# ── Tiny BBox shim — replaces sentinelhub.BBox without the dependency ─
class _BBox:
    def __init__(self, bbox):
        self.min_x, self.min_y, self.max_x, self.max_y = (
            float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]))


# ── Test runners ──────────────────────────────────────────────────────
def _bbox_area_km2(bbox):
    """Approx ROI area (km²) at WGS84 with a cosine-latitude correction."""
    lon_min, lat_min, lon_max, lat_max = bbox
    lat_mid = 0.5 * (lat_min + lat_max)
    km_per_deg_lat = 111.32
    km_per_deg_lon = 111.32 * np.cos(np.radians(lat_mid))
    return abs((lon_max - lon_min) * km_per_deg_lon
               * (lat_max - lat_min) * km_per_deg_lat)


def run_NF01(report):
    """No-rain ROI ⇒ the *production* SAR detector and the *production*
    precipitation analyser BOTH collapse to zero on a dry pre/pre stack
    with zero rain.

    Round-2 hardening (request #4): we now drive ``detection.detect_flood``
    directly on the synthetic pre/pre fixture and assert on its
    ``info["stages"]["final"] == 0`` AND ``info["final_area_km2"] == 0.0``.
    Likewise we assert on ``analyse_precipitation`` returning
    ``total_mm < 1.0``. No hand-rolled equivalents.
    """
    from precipitation import analyse_precipitation, precipitation_risk_score
    from detection import detect_flood

    bbox = CASABLANCA_DRY["bbox"]

    # ── Production precipitation path ─────────────────────────────
    precip = _zero_precip_data(bbox=bbox)
    analysis = analyse_precipitation(precip)
    risk = precipitation_risk_score(analysis)
    total_mm = float(analysis.get("total_mm", -1))

    # ── Production SAR detector path on synthetic pre/pre stack ──
    fixture = _load_or_make_fixture(
        name="casablanca_pre_pre",
        shape=(128, 128, 2),
    )
    roi_km2 = _bbox_area_km2(bbox)
    px_m = max(1.0, np.sqrt(roi_km2 * 1e6 / (128 * 128)))
    res = detect_flood(fixture, fixture,
                       permanent_water=None, dem=None,
                       pixel_m=px_m, auto_threshold=True)
    final_px = int(res["info"]["stages"]["final"])
    final_area_km2 = float(res["info"]["final_area_km2"])
    detect_mask_sum = int(res["mask"].sum())

    expected = {
        "analyse_precipitation: total_mm < 1.0":  True,
        "detect_flood: info.stages.final == 0":   True,
        "detect_flood: info.final_area_km2 == 0.0": True,
        "detect_flood: mask.sum() == 0":          True,
        "precipitation_risk_score == 0":          True,
    }
    got = {
        "total_precip_mm":           total_mm,
        "detect_flood_final_px":     final_px,
        "detect_flood_final_area_km2": final_area_km2,
        "detect_flood_mask_sum":     detect_mask_sum,
        "risk_score":                risk,
        "called":                    "detection.detect_flood + precipitation.analyse_precipitation",
    }
    ok = (total_mm < 1.0
          and final_px == 0
          and final_area_km2 == 0.0
          and detect_mask_sum == 0
          and risk == 0)
    report["tests"]["NF-01"] = {
        "name":     "NF-01_zero_precip",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "exact",
    }


def run_NF02(report):
    """Pre/pre SAR pair ⇒ Otsu rejects (bimodal=False), final_area_km² ≤
    5 % · ROI_km²."""
    from detection import detect_flood
    fixture = _load_or_make_fixture(
        name="casablanca_pre_pre",
        shape=(128, 128, 2),
    )
    bbox = CASABLANCA_DRY["bbox"]
    roi_km2 = _bbox_area_km2(bbox)

    # Use an artificial pixel size that matches the fixture extent.
    px_m = max(1.0, np.sqrt(roi_km2 * 1e6 / (128 * 128)))
    res = detect_flood(fixture, fixture,
                       permanent_water=None, dem=None,
                       pixel_m=px_m,
                       auto_threshold=True)
    info = res["info"]
    auto = info.get("auto_threshold", {})
    bimodal = bool(auto.get("bimodal", False))
    final_area_km2 = float(info.get("final_area_km2", -1))

    cap_km2 = 0.05 * roi_km2
    expected = {
        "auto_threshold.bimodal == False":   True,
        f"final_area_km2 <= 0.05*{roi_km2:.3f}": True,
    }
    got = {
        "bimodal":         bimodal,
        "final_area_km2":  final_area_km2,
        "roi_km2":         round(roi_km2, 4),
        "cap_km2":         round(cap_km2, 4),
        "otsu_db":         auto.get("otsu_db"),
        "bhattacharyya":   auto.get("bhattacharyya"),
        "applied":         auto.get("applied"),
    }
    ok = (bimodal is False) and (final_area_km2 <= cap_km2)
    report["tests"]["NF-02"] = {
        "name":     "NF-02_no_flood_pixels",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "≤ 5 % ROI",
    }


def run_NF03(report):
    """Ocean-dominated ROI ⇒ no flood pixel survives the *production*
    ``app._apply_ocean_mask`` helper.

    Round-2 hardening (request #4): we no longer re-implement the ocean
    mask inline. We import ``app._apply_ocean_mask`` directly, feed it a
    coastal DEM fixture (half ≤ 0.5 m, half land) and a fake all-flooded
    mask, and assert the production helper wipes every pixel overlapping
    the ocean. Any future regression in ``_build_ocean_mask`` (different
    DEM cutoff, OSM dilation kernel, etc.) is now caught by this test.
    """
    # Sentinel-hub bbox shim for app._apply_ocean_mask (it accesses
    # bbox.min_x / max_x / min_y / max_y).
    coast_bbox = _BBox(CASABLANCA_COAST["bbox"])
    shape = (96, 96)
    dem = _coastal_dem(shape)
    fake_mask = np.ones(shape, dtype=np.uint8)

    # Production import — proves the import surface exists and the
    # helper has the expected signature.
    from app import _apply_ocean_mask
    cm, _, om = _apply_ocean_mask(fake_mask, None, coast_bbox, dem)

    overlap = int(((cm > 0) & (om > 0)).sum())
    ocean_px = int(om.sum())
    surviving_flood_px = int(cm.sum())
    # Sanity: the DEM-only gate alone produces 96*48 = 4608 ocean px.
    # _build_ocean_mask additionally dilates by 6 px so ocean_px can be
    # somewhat larger; the strict-zero overlap check is what we gate on.

    expected = {
        "ocean_overlap_px == 0":            True,
        "ocean_px > 0 (sanity check)":      True,
        "surviving_flood + ocean dilated == fake_mask total": True,
    }
    got = {
        "ocean_overlap_px":   overlap,
        "ocean_px":           ocean_px,
        "surviving_flood_px": surviving_flood_px,
        "applied_via":        "app._apply_ocean_mask",
    }
    ok = (overlap == 0) and (ocean_px > 0) and (surviving_flood_px > 0)
    report["tests"]["NF-03"] = {
        "name":     "NF-03_ocean_excluded",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "exact",
    }


def run_NF04(report):
    """Outside UAE bbox ⇒ no UAE return-period; risk_score = 0 when
    total_mm == 0; AND the regime is reported (Csa_med / uncalibrated /
    BWh_uae if AUTO is disabled)."""
    from precipitation import (analyse_precipitation,
                               precipitation_risk_score, kg_regime)
    bbox = CASABLANCA_DRY["bbox"]
    precip = _zero_precip_data(bbox=bbox)
    analysis = analyse_precipitation(precip)
    risk = precipitation_risk_score(analysis)
    rp_est = analysis.get("return_period_est", "")
    regime = analysis.get("regime", "")

    # acceptance: regime must NOT be BWh_uae for Casablanca.
    rp_ok = (rp_est == "n/a (uncalibrated region)"
             or regime in ("Csa_med", "uncalibrated"))
    risk_ok = (risk == 0)

    # spot-check kg_regime helper for offline correctness
    kg_uae   = kg_regime(54.4, 24.4)
    kg_casa  = kg_regime(-7.6, 33.55)
    kg_other = kg_regime(120.0, 0.0)

    expected = {
        "regime_for_casablanca != 'BWh_uae'":  True,
        "risk_score == 0 when total_mm == 0":  True,
        "kg_regime(uae) == 'BWh_uae'":         True,
        "kg_regime(casa) == 'Csa_med'":        True,
        "kg_regime(equator-pacific) == 'uncalibrated'": True,
    }
    got = {
        "regime":              regime,
        "return_period_est":   rp_est,
        "risk_score":          risk,
        "kg_uae":              kg_uae,
        "kg_casa":             kg_casa,
        "kg_other":            kg_other,
    }
    ok = (rp_ok
          and risk_ok
          and kg_uae == "BWh_uae"
          and kg_casa == "Csa_med"
          and kg_other == "uncalibrated")
    report["tests"]["NF-04"] = {
        "name":     "NF-04_regime_aware",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "exact",
    }


def run_NF05(report):
    """When flooded_km² == 0, the UI-results dict carries
    ``no_flood_detected == True`` AND no depth/streets blocks.

    Round-2 hardening (request #4): drives the production
    ``app._finalise_sar_results`` helper directly on a synthetic
    ``cm = np.zeros(...)`` mask. The harness now fails if a future
    refactor of ``_run_pipeline`` deletes or re-orders the finalisation
    step. Asserts:
      * ``R["no_flood_detected"] is True``,
      * ``"depth" not in R`` and ``"streets" not in R`` (the helper does
        not produce them; they are only added by later pipeline stages
        which the harness deliberately does not run).
    """
    from app import _finalise_sar_results
    bbox = _BBox(CASABLANCA_DRY["bbox"])
    shape = (64, 64)
    null_mask = np.zeros(shape, dtype=np.uint8)
    null_post_db = np.zeros(shape, dtype=np.float32)
    fake_det = {"mask": null_mask, "post_db": null_post_db}
    dem = _flat_dem(shape, elev_m=15.0)
    R = {}
    cm, ocean_m, info, post_results = _finalise_sar_results(
        R, fake_det, bbox,
        dem=dem, water_mask=None,
        roi_km2=10.0, write_files=False,
    )
    no_flood_flag = R.get("no_flood_detected")
    has_depth     = "depth" in R
    has_streets   = "streets" in R
    # The flood_geojson block is allowed (it's the UI's empty
    # FeatureCollection); we just confirm it has zero features.
    flood_geojson = R.get("flood_geojson", {})
    n_features = len(flood_geojson.get("features", [])) if flood_geojson else 0

    expected = {
        "no_flood_detected == True":                True,
        "depth/streets blocks ABSENT in finaliser": True,
        "flood_geojson features == 0":              True,
        "post_results.threshold.km2 == 0.0":        True,
    }
    got = {
        "no_flood_detected":   no_flood_flag,
        "depth_in_R":          has_depth,
        "streets_in_R":        has_streets,
        "flood_features":      n_features,
        "post_results_km2":    post_results["threshold"]["km2"],
        "finaliser":           "app._finalise_sar_results",
    }
    ok = (no_flood_flag is True
          and not has_depth
          and not has_streets
          and n_features == 0
          and float(post_results["threshold"]["km2"]) == 0.0)
    report["tests"]["NF-05"] = {
        "name":     "NF-05_ui_no_flood_badge",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "exact",
    }


# ── NF-06: Volume conservation gate in flood_sim.rainfall_runoff_depth ─
def run_NF06(report):
    """Synthetic over-shoot fixture: high boundary ring on a 64×64 DEM so
    FwDET integrates more volume than catchment runoff allows.

    Asserts:
      1. Gate fires → volume_conservation_factor ≤ 1.05.
      2. depth_volume_m3 ≤ runoff_volume_m3 × 1.05.
      3. depth_volume_m3 > 0 (positive sanity).
      4. Zero-mask fast-path → volume_conservation_factor == 1.0 and
         depth_volume_m3 == 0.0 (no regression on NF-01/NF-05).
    """
    from flood_sim import rainfall_runoff_depth

    shape = (64, 64)
    # Full flood mask — every pixel is flooded.
    mask = np.ones(shape, dtype=np.uint8)
    # High boundary ring (30 m) vs flat interior (10 m): FwDET pulls boundary
    # DEM (30 m) as water surface over interior (10 m) → depth ~ 20 m everywhere
    # → V_flood will vastly exceed catchment runoff from 50 mm rain.
    dem = np.full(shape, 10.0, dtype=np.float32)
    dem[:2, :] = 30.0; dem[-2:, :] = 30.0
    dem[:, :2] = 30.0; dem[:, -2:] = 30.0

    depth, stats = rainfall_runoff_depth(mask, dem, precip_total_mm=50.0)

    scale = float(stats.get("volume_conservation_factor", -1))
    v_depth = float(stats.get("depth_volume_m3", -1))
    v_runoff = float(stats.get("runoff_volume_m3", -1))
    has_keys = ("depth_volume_m3" in stats
                and "runoff_volume_m3" in stats
                and "volume_conservation_factor" in stats)

    gate_fired = (scale <= 1.05)
    depth_bounded = (v_depth <= v_runoff * 1.05)
    positive = (v_depth > 0)

    # Zero-mask fast-path
    _, stats0 = rainfall_runoff_depth(
        np.zeros(shape, dtype=np.uint8), dem, precip_total_mm=50.0)
    zero_ok = (stats0.get("volume_conservation_factor") == 1.0
               and stats0.get("depth_volume_m3") == 0.0)

    ok = gate_fired and depth_bounded and positive and has_keys and zero_ok

    expected = {
        "volume_conservation_factor <= 1.05":           True,
        "depth_volume_m3 <= runoff_volume_m3 * 1.05":  True,
        "depth_volume_m3 > 0":                          True,
        "keys depth_volume_m3/runoff_volume_m3/vcf present": True,
        "zero-mask: vcf==1.0 and depth_volume==0.0":   True,
    }
    got = {
        "volume_conservation_factor": scale,
        "depth_volume_m3":            v_depth,
        "runoff_volume_m3":           v_runoff,
        "gate_fired":                 gate_fired,
        "depth_bounded":              depth_bounded,
        "positive_depth":             positive,
        "has_keys":                   has_keys,
        "zero_mask_ok":               zero_ok,
    }
    report["tests"]["NF-06"] = {
        "name":     "NF-06_volume_conservation",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "vcf ≤ 1.05",
    }


# ── Abu Dhabi 2026 control fixture (regression guard) ─────────────────
def run_control_AD2026(report):
    """Abu Dhabi 2026 control: BWh_uae regime, 25-50 yr return-period,
    final_area_km² > 0 in a synthetic post-event SAR pair."""
    from precipitation import analyse_precipitation, precipitation_risk_score
    from detection import detect_flood

    bbox = ABU_DHABI_2026["bbox"]
    precip = _ad_2026_precip_data(bbox=bbox)
    analysis = analyse_precipitation(precip)
    risk = precipitation_risk_score(analysis)
    rp = analysis.get("return_period_est", "")
    regime = analysis.get("regime", "")

    # Synthetic post-event SAR pair: half the scene drops by ~10 dB
    # in linear power (×0.1 → −10 dB). That gives Otsu a clearly bimodal
    # distribution and a final_area_km² well above zero.
    shape = (96, 96, 2)
    pre = np.full(shape, 0.05, dtype=np.float32)
    rng = np.random.default_rng(11)
    pre *= (1.0 + 0.03 * rng.standard_normal(shape).astype(np.float32))
    pre = np.clip(pre, 1e-6, None)
    post = pre.copy()
    post[:, : shape[1] // 2, :] *= 0.1                # darken half
    post = np.clip(post, 1e-6, None)

    roi_km2 = _bbox_area_km2(bbox)
    px_m = max(1.0, np.sqrt(roi_km2 * 1e6 / (shape[0] * shape[1])))
    res = detect_flood(pre, post, pixel_m=px_m, auto_threshold=True)
    final_area_km2 = float(res["info"].get("final_area_km2", 0.0))

    expected = {
        "regime == 'BWh_uae'":              True,
        "return_period_est == '25-50 year'": True,
        "final_area_km2 > 0":                True,
        "risk_score > 0":                    True,
    }
    got = {
        "regime":            regime,
        "return_period_est": rp,
        "final_area_km2":    final_area_km2,
        "risk_score":        risk,
        "total_mm":          analysis.get("total_mm"),
        "max_3day_mm":       analysis.get("max_3day_mm"),
    }
    ok = (regime == "BWh_uae"
          and rp == "25-50 year"
          and final_area_km2 > 0
          and risk > 0)
    report["control"] = {
        "name":     "abu_dhabi_2026_control",
        "status":   "PASS" if ok else "FAIL",
        "expected": expected,
        "got":      got,
        "tolerance": "regression guard",
    }


# ── Main driver ───────────────────────────────────────────────────────
def main():
    t0 = time.time()
    report = {
        "timestamp": dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "fixture":   "casablanca_dry",
        "fixture_dir": str(FIXTURE_DIR),
        "tests":     {},
        "control":   {},
        "summary":   {"passed": 0, "failed": 0},
    }

    # NF-01..NF-06 on the Casablanca dry-window fixture
    for fn in (run_NF01, run_NF02, run_NF03, run_NF04, run_NF05, run_NF06):
        try:
            fn(report)
        except Exception as ex:
            LOG.exception(f"{fn.__name__} crashed: {ex}")
            report["tests"][fn.__name__.replace("run_", "")] = {
                "name":   fn.__name__,
                "status": "FAIL",
                "error":  str(ex),
            }

    # Abu Dhabi 2026 regression control
    try:
        run_control_AD2026(report)
    except Exception as ex:
        LOG.exception(f"control crashed: {ex}")
        report["control"] = {
            "name":   "abu_dhabi_2026_control",
            "status": "FAIL",
            "error":  str(ex),
        }

    # ── UAE byte-equal regression assertion (Round-2 request #4) ──
    # Asserts the AD2026 control's final_area_km2 has not drifted from
    # the canonical 270.5 km² baseline by more than 0.1 % when the SAR
    # detector runs with regime=None (legacy path). Catches any future
    # change to BHATTACHARYYA_MIN/MAX_FLOOD_SLOPE_DEG/THRESHOLD_DB or the
    # detector's auto-threshold logic.
    BASELINE_AREA_KM2 = 270.5
    try:
        control_area = float(report.get("control", {}).get("got", {})
                              .get("final_area_km2", -1.0))
        rel_drift = abs(control_area - BASELINE_AREA_KM2) / BASELINE_AREA_KM2
        regression_pass = (rel_drift < 0.001)
        report["uae_regression"] = {
            "name":              "uae_byte_equal_regression",
            "baseline_km2":      BASELINE_AREA_KM2,
            "control_area_km2":  control_area,
            "relative_drift":    round(rel_drift, 6),
            "tolerance":         "< 0.001 (0.1 %)",
            "status":            "PASS" if regression_pass else "FAIL",
        }
    except Exception as ex:
        report["uae_regression"] = {
            "name":   "uae_byte_equal_regression",
            "status": "FAIL",
            "error":  str(ex),
        }

    # Summarise
    passed = sum(1 for t in report["tests"].values()
                 if t.get("status") == "PASS")
    failed = sum(1 for t in report["tests"].values()
                 if t.get("status") != "PASS")
    report["summary"] = {"passed": passed, "failed": failed}
    report["control_passed"] = (report["control"].get("status") == "PASS")
    report["runtime_s"] = round(time.time() - t0, 2)

    out_dir = ROOT / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "null_hypothesis_results.json"
    out_path.write_text(json.dumps(report, indent=2, default=str))
    LOG.info(f"Results → {out_path}")
    LOG.info(f"Summary: passed={passed}  failed={failed}  "
             f"control={report['control'].get('status')}  "
             f"runtime={report['runtime_s']}s")

    # Friendly console summary
    print("\n" + "=" * 64)
    print(f"NULL-HYPOTHESIS RESULTS  ({report['fixture']})")
    print("=" * 64)
    for k in sorted(report["tests"].keys()):
        t = report["tests"][k]
        print(f"  {k}  {t.get('status', '?'):4s}  {t.get('name', '')}")
    c = report["control"]
    print(f"  CTRL  {c.get('status', '?'):4s}  {c.get('name', '')}")
    ur = report.get("uae_regression", {})
    print(f"  UAE   {ur.get('status', '?'):4s}  byte-equal regression "
          f"(area={ur.get('control_area_km2','?')} km², "
          f"baseline={ur.get('baseline_km2','?')}, "
          f"drift={ur.get('relative_drift','?')})")
    print(f"\nsummary.passed = {passed}  summary.failed = {failed}\n"
          f"control = {c.get('status')}\n"
          f"uae_regression = {ur.get('status')}\n"
          f"runtime = {report['runtime_s']} s\n")

    # Exit non-zero on any failure (NF / control / UAE regression)
    if (failed > 0
        or c.get("status") != "PASS"
        or ur.get("status") != "PASS"):
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
