"""
Round-4 live S2 flood test.

ROI: Abu Dhabi April 2024 preset (small 10x8 km window around 54.34-54.44E, 24.42-24.50N)
Event: UAE April 2024 extreme rainfall (241 mm in 24 h at Al Ain, widespread inundation).

Test 1 — FLOOD scene
  PRE:  2024-04-01 → 2024-04-14  (dry, before the rain)
  POST: 2024-04-16 → 2024-04-30  (post-rain, clouds expected to clear by ~Apr 20-25)

Test 2 — DRY CONTROL (null hypothesis)
  PRE:  2024-04-01 → 2024-04-07  (dry)
  POST: 2024-04-08 → 2024-04-14  (dry — second dry window before rain)

Both tests use the same ROI.  Acceptance:
  AC-2: flooded_km2 > 0 on the flood scene
  Null: flooded_km2 ≈ 0 on the dry control

Usage:
  cd /home/wassi/UAE_FloodMap/flood_v2
  S2_GEE_FALLBACK=1 EE_PROJECT=ee-wassimehtp python3 tools/run_live_s2_flood_test.py
"""
from __future__ import annotations
import os, sys, json, logging, time, datetime
import numpy as np

# ── paths ────────────────────────────────────────────────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

# ── logging ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)
L = logging.getLogger("live_s2_test")

# ── ROI — Al Ain April 2024 (254 mm fell here — pure inland desert/urban) ─
# Al Ain is inland, no sea, no mangroves → clean null for dry control.
# April 17-18 2024 saw record rainfall (254 mm at Al Ain gauge).
# ~9.1 km W-E, ~7.8 km N-S = ~71 km²  → ~20 MB for 7 bands at 10 m
BBOX_LONLAT = [55.73, 24.18, 55.82, 24.25]   # [west, south, east, north]

# ── date windows ─────────────────────────────────────────────────────
FLOOD_PRE_FROM  = "2024-04-01"
FLOOD_PRE_TO    = "2024-04-14"
FLOOD_POST_FROM = "2024-04-16"
FLOOD_POST_TO   = "2024-04-30"

# Dry control: two windows in March 2024 (clear desert skies, no rain)
# March is reliably cloud-free at Al Ain; S2 passes ~every 5 days
DRY_PRE_FROM  = "2024-03-01"
DRY_PRE_TO    = "2024-03-14"
DRY_POST_FROM = "2024-03-15"
DRY_POST_TO   = "2024-03-31"

CLOUD_PCT = 40   # liberal cloud filter for the post-event window


def _build_sh_bbox(lonlat):
    """Build a sentinelhub BBox if sentinelhub is installed, else None."""
    try:
        from sentinelhub import BBox, CRS
        w, s, e, n = lonlat
        return BBox([w, s, e, n], crs=CRS.WGS84)
    except Exception:
        return None


def _download(bbox_obj, date_from, date_to, label=""):
    """Call download_s2_flood (which auto-falls-back to GEE)."""
    from downloader import download_s2_flood
    L.info(f"Downloading S2 {label} [{date_from} → {date_to}] …")
    t0 = time.time()
    arr = download_s2_flood(bbox_obj or BBOX_LONLAT, date_from, date_to,
                            resolution=10.0)
    L.info(f"  Done in {time.time()-t0:.1f}s  shape={arr.shape}")
    return arr


def _run_detector(pre_arr, post_arr, label=""):
    """Split bands, call detect_flood_s2, return result dict."""
    from detection_s2 import detect_flood_s2
    # (H,W,7): bands 0-5 = B02..B12 DN, band 6 = SCL
    pre_bands = pre_arr[:, :, :6]    # B02..B12
    pre_scl   = pre_arr[:, :, 6].astype(np.uint8)
    post_bands = post_arr[:, :, :6]
    post_scl   = post_arr[:, :, 6].astype(np.uint8)

    L.info(f"Running detect_flood_s2 ({label}) …")
    t0 = time.time()
    result = detect_flood_s2(
        pre_bands=pre_bands,
        post_bands=post_bands,
        pre_scl=pre_scl,
        post_scl=post_scl,
        permanent_water=None,
        dem=None,
        pixel_m=10.0,
    )
    elapsed = time.time() - t0
    info = result["info"]
    km2 = info["final_area_km2"]
    cloud = info["cloud_fraction"]
    stages = info["stages"]
    L.info(
        f"  [{label}] flooded={km2} km²  cloud={cloud:.1%}  "
        f"seed={stages['seed_pixels']} cand={stages['candidate_pixels']} "
        f"grown={stages['after_growing']} final={stages['final']}  "
        f"elapsed={elapsed:.1f}s"
    )
    return result


def main():
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    out_dir = os.path.join(ROOT, "outputs", f"live_s2_round4_{ts}")
    os.makedirs(out_dir, exist_ok=True)
    L.info(f"Artefacts → {out_dir}")

    # Build bbox object (SH format if available, otherwise raw list)
    bbox_obj = _build_sh_bbox(BBOX_LONLAT)

    summary = {
        "timestamp": ts,
        "roi_lonlat": BBOX_LONLAT,
        "fixture": "abudhabi_apr2024",
    }

    # ── FLOOD SCENE ───────────────────────────────────────────────────
    L.info("=" * 60)
    L.info("TEST 1: FLOOD SCENE (pre=Apr 1-14, post=Apr 16-30)")
    L.info("=" * 60)
    try:
        pre_flood = _download(bbox_obj, FLOOD_PRE_FROM, FLOOD_PRE_TO,
                              label="FLOOD_PRE")
        np.save(os.path.join(out_dir, "flood_pre.npy"), pre_flood)
    except Exception as e:
        L.error(f"FLOOD PRE download failed: {e}")
        summary["flood_scene"] = {"status": "FAIL", "error": str(e)}
        pre_flood = None

    post_flood = None
    if pre_flood is not None:
        try:
            post_flood = _download(bbox_obj, FLOOD_POST_FROM, FLOOD_POST_TO,
                                   label="FLOOD_POST")
            np.save(os.path.join(out_dir, "flood_post.npy"), post_flood)
        except Exception as e:
            L.error(f"FLOOD POST download failed: {e}")
            summary["flood_scene"] = {"status": "FAIL", "error": str(e)}

    if pre_flood is not None and post_flood is not None:
        try:
            r_flood = _run_detector(pre_flood, post_flood, label="FLOOD")
            info_f = r_flood["info"]
            summary["flood_scene"] = {
                "status": "OK",
                "flooded_km2": info_f["final_area_km2"],
                "cloud_fraction_post": info_f["cloud_fraction"],
                "thresholds": info_f["thresholds"],
                "otsu_applied": info_f["otsu_applied"],
                "bhattacharyya": info_f["bhattacharyya"],
                "stages": info_f["stages"],
                "confidence": info_f["confidence"],
                "AC2_pass": info_f["final_area_km2"] > 0,
            }
            np.save(os.path.join(out_dir, "flood_mask.npy"),
                    r_flood["mask"])
        except Exception as e:
            L.error(f"Flood detector failed: {e}")
            summary["flood_scene"] = {"status": "FAIL", "error": str(e)}

    # ── DRY CONTROL ───────────────────────────────────────────────────
    L.info("=" * 60)
    L.info("TEST 2: DRY CONTROL (pre=Apr 1-7, post=Apr 8-14)")
    L.info("=" * 60)
    try:
        pre_dry = _download(bbox_obj, DRY_PRE_FROM, DRY_PRE_TO,
                            label="DRY_PRE")
        post_dry = _download(bbox_obj, DRY_POST_FROM, DRY_POST_TO,
                             label="DRY_POST")
        r_dry = _run_detector(pre_dry, post_dry, label="DRY_CTRL")
        info_d = r_dry["info"]
        summary["dry_control"] = {
            "status": "OK",
            "flooded_km2": info_d["final_area_km2"],
            "cloud_fraction_post": info_d["cloud_fraction"],
            "stages": info_d["stages"],
            "null_hyp_pass": info_d["final_area_km2"] < 0.5,
        }
    except Exception as e:
        L.error(f"Dry control failed: {e}")
        summary["dry_control"] = {"status": "FAIL", "error": str(e)}

    # ── Overall verdict ───────────────────────────────────────────────
    ac2 = summary.get("flood_scene", {}).get("AC2_pass", False)
    null = summary.get("dry_control", {}).get("null_hyp_pass", False)
    summary["verdict"] = {
        "AC2_flooded_gt0": ac2,
        "null_hyp_approx0": null,
        "overall": "PASS" if (ac2 and null) else ("PARTIAL" if ac2 else "FAIL"),
    }

    out_json = os.path.join(out_dir, "live_s2_results.json")
    with open(out_json, "w") as f:
        json.dump(summary, f, indent=2)

    L.info("=" * 60)
    L.info(f"RESULTS saved to {out_json}")
    L.info(f"  FLOOD flooded_km2 = {summary.get('flood_scene',{}).get('flooded_km2','?')} km²")
    L.info(f"  DRY   flooded_km2 = {summary.get('dry_control',{}).get('flooded_km2','?')} km²")
    L.info(f"  AC-2 (flood>0): {ac2}   Null-hyp (dry≈0): {null}")
    L.info(f"  OVERALL: {summary['verdict']['overall']}")
    L.info("=" * 60)

    return summary


if __name__ == "__main__":
    main()
