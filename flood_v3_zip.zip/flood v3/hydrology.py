"""
╔══════════════════════════════════════════════════════════════════════╗
║   UAE FloodMap — HEC-HMS-style hydrologic depth engine               ║
║                                                                      ║
║   Drives the per-pixel water depth from PRECIPITATION + DEM only.    ║
║   The SAR mask defines where flooding occurred (extent); the         ║
║   hydrology gives the metres of water inside it (height).            ║
║                                                                      ║
║   Pipeline                                                           ║
║   --------                                                           ║
║     1. SCS Curve-Number runoff transformation (USDA NRCS NEH-4 §10)  ║
║          S  = 25400 / CN − 254              [mm]                     ║
║          Ia = 0.2 · S                       [mm]                     ║
║          Q  = (P − Ia)² / (P − Ia + S)      for P > Ia, else 0       ║
║                                                                      ║
║     2. DEM depression filling (priority-flood, Wang & Liu 2006).     ║
║        Pre-conditions the DEM so flow accumulation is hydrologically ║
║        consistent and natural sinks are tagged for ponding.          ║
║                                                                      ║
║     3. D8 flow direction + flow accumulation (O'Callaghan & Mark     ║
║        1984). Each pixel inherits the cumulative upstream area.      ║
║                                                                      ║
║     4. Manning kinematic-wave depth on sloped cells                  ║
║        (Chow 1959 · NRCS Time of Concentration TR-55):               ║
║                                                                      ║
║          q  =  Q · A_up                  [m³/s per m of width]       ║
║          h  =  (q · n / √S)^(3/5)        [m]                          ║
║                                                                      ║
║        where Q [m/s] is unit-area runoff rate, A_up upstream area,   ║
║        n Manning's roughness, S local slope (m/m).                   ║
║                                                                      ║
║     5. FwDET sink-fill depth in depressions / very-flat cells        ║
║        (Cohen, Brakenridge, Kettner 2019).                           ║
║          depth  =  max(0, water_surface − DEM)                       ║
║        with water_surface = elevation of the nearest dry boundary    ║
║        (= the rim height the pond had to rise to before spilling).   ║
║                                                                      ║
║     6. Volume conservation (HEC-HMS reservoir balance). Total depth  ║
║        volume ≤ runoff volume — if our raw raster overshoots we      ║
║        scale it down uniformly so V_depth ≤ V_runoff. Storage and    ║
║        infiltration losses inside the basin would lower it further;  ║
║        we never inflate.                                             ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging
import numpy as np
from scipy.ndimage import (gaussian_filter, distance_transform_edt,
                           binary_dilation, binary_erosion, label)
from config import RESOLUTION_M, MAX_WATER_DEPTH_M, RUNOFF_COEFF

L = logging.getLogger("flood.hydro")


# ─────────────────────────────────────────────────────────────────────
# 0. AMC antecedent-moisture adjustment (NRCS NEH-4 Ch.10 Table 2-2a)
# ─────────────────────────────────────────────────────────────────────
def _resolve_amc(api_mm, amc_override=None):
    """Select AMC class from 5-day antecedent precipitation index (API).

    NRCS NEH-4 Table 2-1 (growing-season thresholds):
      API < 35.6 mm  → AMC-I  (dry antecedent)
      35.6 ≤ API < 53.3 mm → AMC-II (moderate — standard)
      API ≥ 53.3 mm  → AMC-III (wet antecedent)

    Parameters
    ----------
    api_mm : float  — 5-day antecedent precipitation total (mm).
    amc_override : str | None  — "I", "II", or "III"; bypasses auto.
    """
    if amc_override is not None:
        if amc_override not in ("I", "II", "III"):
            raise ValueError(f"amc_override must be 'I', 'II', or 'III'; got {amc_override!r}")
        return amc_override
    if float(api_mm) < 35.6:
        return "I"
    if float(api_mm) < 53.3:
        return "II"
    return "III"


def _adjust_cn_for_amc(cn_ii, amc):
    """Convert AMC-II curve number to AMC-I (dry) or AMC-III (wet).

    NRCS NEH-4 Table 2-2a:
      CN_I   = 4.2  · CN_II / (10 − 0.058 · CN_II)
      CN_III = 23   · CN_II / (10 + 0.13  · CN_II)
      CN_II  unchanged (standard condition).

    CN is clipped to [30, 100] after conversion so it stays physically
    meaningful (values outside that range are not tabulated in NEH-4).
    """
    cn = float(cn_ii)
    if amc == "I":
        adjusted = (4.2 * cn) / (10.0 - 0.058 * cn)
    elif amc == "III":
        adjusted = (23.0 * cn) / (10.0 + 0.13 * cn)
    else:
        adjusted = cn   # AMC-II = standard, no adjustment
    return float(np.clip(adjusted, 30.0, 100.0))


# ─────────────────────────────────────────────────────────────────────
# 1. SCS Curve-Number runoff
# ─────────────────────────────────────────────────────────────────────
def scs_cn_runoff_mm(precip_mm, curve_number):
    """USDA-NRCS Soil Conservation Service Curve-Number runoff.

    Parameters
    ----------
    precip_mm : float           cumulative storm rainfall depth (mm)
    curve_number : float        SCS CN (typical UAE values):
        - urban paved        95–98
        - urban mixed        85–92
        - bare soil / desert 70–80
        - irrigated cropland 60–70
    """
    P  = max(0.0, float(precip_mm))
    CN = float(np.clip(curve_number, 30, 100))
    S  = 25400.0 / CN - 254.0          # potential maximum retention (mm)
    Ia = 0.2 * S                        # initial abstraction
    if P <= Ia:
        return 0.0, S, Ia
    Q = (P - Ia) ** 2 / (P - Ia + S)    # runoff depth (mm)
    return float(Q), float(S), float(Ia)


# ─────────────────────────────────────────────────────────────────────
# 2. Priority-flood depression filling (Wang & Liu 2006)
# ─────────────────────────────────────────────────────────────────────
def fill_depressions(dem):
    """Priority-flood depression fill. Returns a hydrologically corrected
    DEM where every pixel has at least one downhill neighbour (except the
    boundary). Vectorised heap-based implementation; good enough for the
    O(10⁶) pixels we typically work with here."""
    import heapq
    h, w = dem.shape
    filled = dem.astype(np.float32).copy()
    closed = np.zeros((h, w), dtype=bool)
    pq = []
    # seed the priority queue with the boundary
    for y in (0, h - 1):
        for x in range(w):
            heapq.heappush(pq, (filled[y, x], y, x)); closed[y, x] = True
    for x in (0, w - 1):
        for y in range(1, h - 1):
            heapq.heappush(pq, (filled[y, x], y, x)); closed[y, x] = True

    nbrs = ((-1, -1), (-1, 0), (-1, 1), (0, -1),
            (0, 1),  (1, -1), (1, 0),  (1, 1))
    while pq:
        z, y, x = heapq.heappop(pq)
        for dy, dx in nbrs:
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and not closed[ny, nx]:
                # raise the neighbour to at least our height
                filled[ny, nx] = max(filled[ny, nx], z)
                heapq.heappush(pq, (filled[ny, nx], ny, nx))
                closed[ny, nx] = True
    return filled


# ─────────────────────────────────────────────────────────────────────
# 3. D8 flow direction + flow accumulation (O'Callaghan & Mark 1984)
# ─────────────────────────────────────────────────────────────────────
def flow_direction_d8(dem):
    """Per-pixel index 0..7 of the steepest-descent neighbour."""
    h, w = dem.shape
    padded = np.pad(dem, 1, mode='edge')
    dy = np.array([-1, -1, -1,  0, 0,  1, 1, 1])
    dx = np.array([-1,  0,  1, -1, 1, -1, 0, 1])
    dist = np.array([1.4142, 1.0, 1.4142, 1.0, 1.0, 1.4142, 1.0, 1.4142])

    best_slope = -np.inf * np.ones((h, w), dtype=np.float32)
    flow_dir   = np.zeros((h, w), dtype=np.int8)
    for i in range(8):
        nb = padded[1 + dy[i]:h + 1 + dy[i], 1 + dx[i]:w + 1 + dx[i]]
        slope = (dem - nb) / dist[i]
        upd = slope > best_slope
        best_slope[upd] = slope[upd]
        flow_dir[upd]   = i
    return flow_dir, dy, dx


def flow_accumulation_d8(dem, weights=None):
    """Cumulative upstream area (in number of pixels) using D8 routing on
    a depression-filled DEM. Returns acc[h, w]."""
    h, w = dem.shape
    flow_dir, dy, dx = flow_direction_d8(dem)
    acc = (np.ones((h, w), dtype=np.float64)
           if weights is None else weights.astype(np.float64).copy())

    # Process pixels in descending elevation order — each pixel's value is
    # complete by the time its downstream neighbour is visited.
    order = np.argsort(-dem.ravel())
    flat_acc = acc.ravel()
    for idx in order:
        y, x = divmod(idx, w)
        d = flow_dir[y, x]
        ny, nx = y + dy[d], x + dx[d]
        if 0 <= ny < h and 0 <= nx < w:
            flat_acc[ny * w + nx] += flat_acc[idx]
    return flat_acc.reshape(h, w)


# ─────────────────────────────────────────────────────────────────────
# 4. FwDET sink-fill depth (Cohen et al. 2019)
# ─────────────────────────────────────────────────────────────────────
def _fwdet_pond_depth(flood_mask, dem, max_depth, surface_smooth_px=9):
    """Component-aware FwDET. For each connected flood patch, water
    surface = elevation of the nearest dry boundary pixel (the rim)."""
    mask = flood_mask.astype(bool)
    depth = np.zeros_like(dem, dtype=np.float32)
    if mask.sum() == 0:
        return depth
    lbl, n = label(mask)
    for c in range(1, n + 1):
        comp = (lbl == c)
        ring = binary_dilation(comp) & (~mask)
        if ring.sum() < 3:
            ring = comp & (~binary_erosion(comp))
        if ring.sum() == 0:
            continue
        # nearest-dry-rim DEM via Euclidean transform with index returns
        _, (iy, ix) = distance_transform_edt(~ring, return_indices=True)
        surface = dem[iy, ix]
        if surface_smooth_px > 1:
            from scipy.ndimage import uniform_filter
            surface = uniform_filter(surface.astype(np.float32),
                                     size=surface_smooth_px)
        d_comp = np.clip(surface - dem, 0.0, max_depth)
        depth[comp] = d_comp[comp].astype(np.float32)
    depth[depth < 0.02] = 0.0          # < 2 cm = noise
    return depth


# ─────────────────────────────────────────────────────────────────────
# 5. Manning kinematic-wave sheet-flow depth
# ─────────────────────────────────────────────────────────────────────
def _kinematic_depth(flood_mask, dem, accumulation, runoff_q_m_per_s,
                     manning_n, pixel_m, max_depth,
                     min_slope=0.001):
    """Manning kinematic-wave sheet-flow depth for sloped cells.

    For unit-width sheet flow:    V = (1/n) · h^(2/3) · S^(1/2)
    Per-meter discharge q  = V · h  ⇒  h = (q · n / √S)^(3/5).

    `runoff_q_m_per_s` is the unit-area runoff rate (Q[mm] over the storm
    duration, converted to m/s — provided by the caller). The cell's
    upstream contribution is q = runoff_q × A_up / pixel_width.
    """
    mask = flood_mask.astype(bool)
    h_arr = np.zeros_like(dem, dtype=np.float32)
    if mask.sum() == 0 or runoff_q_m_per_s <= 0:
        return h_arr

    # local slope (m/m) — same convention as the SAR detector
    gy, gx = np.gradient(dem.astype(np.float32), pixel_m, pixel_m)
    slope  = np.hypot(gx, gy).astype(np.float32)
    slope  = np.maximum(slope, min_slope)

    # cell pixel width = pixel_m;  upstream area in m²:
    A_up_m2 = accumulation * (pixel_m * pixel_m)
    q_per_m = runoff_q_m_per_s * A_up_m2 / pixel_m   # m³/s per m of width
    h_arr  = (q_per_m * manning_n / np.sqrt(slope)) ** 0.6
    h_arr  = np.clip(h_arr, 0.0, max_depth).astype(np.float32)
    h_arr[~mask] = 0.0
    return h_arr


# ─────────────────────────────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────────────────────────────
def depth_from_precip_dem(flood_mask, dem, precip_total_mm,
                          curve_number=78,
                          amc=None,
                          antecedent_api=0.0,
                          manning_n=0.035,
                          storm_duration_h=6.0,
                          pixel_m=RESOLUTION_M,
                          max_depth=MAX_WATER_DEPTH_M,
                          flat_slope_threshold=0.005,
                          detected_mask=None):
    """Per-pixel water depth from precipitation + DEM, HEC-HMS-style.

    Parameters (new, all keyword-only with safe defaults)
    -------------------------------------------------------
    amc : None | "I" | "II" | "III"
        Antecedent Moisture Class override.  None = auto-resolved from
        ``antecedent_api`` using NRCS NEH-4 Table 2-1 thresholds.
    antecedent_api : float
        5-day antecedent precipitation index (mm).  Used when ``amc``
        is None to select the AMC class.  Defaults to 0.0 (dry) so the
        existing UAE baseline is preserved byte-for-byte when the param
        is not supplied.
    detected_mask : ndarray (H, W) uint8 | None
        When provided, depth is forced to 0 everywhere the sensor flood
        mask is 0 after every step that may contaminate dry pixels.
        Satisfies the WS-4 reconciliation invariant.

    Returns
    -------
    depth : ndarray (H, W)  float32, metres, 0 outside `flood_mask`.
    stats : dict with every equation parameter, runoff Q mm,
            volume conservation diagnostics and per-mode pixel counts.
            New keys: ``amc_used``, ``CN_adjusted``, ``volume_ratio``.
    """
    mask = flood_mask.astype(bool)
    h, w = dem.shape
    px_area = pixel_m * pixel_m
    catchment_area = h * w * px_area
    flood_area     = mask.sum() * px_area

    # ── 0b. AMC adjustment (NRCS NEH-4 Table 2-2a) ───────────────────
    amc_used   = _resolve_amc(float(antecedent_api), amc)
    cn_adj     = _adjust_cn_for_amc(curve_number, amc_used)
    L.info(f"AMC: API={antecedent_api:.1f}mm → {amc_used} → "
           f"CN_II={curve_number:.0f} → CN_adj={cn_adj:.0f}")

    # ── 1. SCS-CN runoff ─────────────────────────────────────────────
    Q_mm, S_mm, Ia_mm = scs_cn_runoff_mm(precip_total_mm, cn_adj)
    V_runoff_m3 = (Q_mm * 1e-3) * catchment_area
    L.info(f"SCS-CN: P={precip_total_mm:.1f} mm  CN={cn_adj:.1f}  "
           f"S={S_mm:.1f} mm  Ia={Ia_mm:.2f} mm  →  Q={Q_mm:.2f} mm  "
           f"V_runoff={V_runoff_m3:,.0f} m³")

    if mask.sum() == 0:
        empty = np.zeros_like(dem, dtype=np.float32)
        s = _empty_stats(precip_total_mm, curve_number, S_mm,
                         Ia_mm, Q_mm, V_runoff_m3, manning_n,
                         storm_duration_h, flood_area, catchment_area)
        s["amc_used"]    = amc_used
        s["CN_adjusted"] = round(cn_adj, 2)
        s["volume_ratio"] = 0.0
        return empty, s

    # ── 2. Depression fill + 3. flow accumulation ───────────────────
    L.info("Filling depressions (Wang & Liu 2006)…")
    dem_filled = fill_depressions(dem.astype(np.float32))
    L.info("Computing D8 flow accumulation…")
    accumulation = flow_accumulation_d8(dem_filled)
    # natural sinks = pixels where the filled DEM is appreciably above
    # the original. They will be treated as ponds.
    sink_depth_max = np.clip(dem_filled - dem, 0.0, max_depth).astype(np.float32)
    is_sink = sink_depth_max > 0.05    # > 5 cm of depression

    # ── 4. Manning kinematic depth on sloped cells ──────────────────
    duration_s = max(60.0, storm_duration_h * 3600.0)   # avoid /0
    runoff_q_ms = (Q_mm * 1e-3) / duration_s            # m/s unit-area rate
    h_kin = _kinematic_depth(mask, dem, accumulation, runoff_q_ms,
                             manning_n, pixel_m, max_depth)

    # ── 5. FwDET sink-fill depth (uses the FILLED − raw DEM as ceiling)
    h_pond = _fwdet_pond_depth(mask & is_sink, dem, max_depth=max_depth)
    # cap pond depth by the natural sink rim
    h_pond = np.minimum(h_pond, sink_depth_max)

    # local slope to decide which physics dominates per pixel
    gy, gx = np.gradient(dem.astype(np.float32), pixel_m, pixel_m)
    slope = np.hypot(gx, gy).astype(np.float32)

    use_pond = mask & ((slope < flat_slope_threshold) | is_sink)
    use_kin  = mask & ~use_pond

    depth = np.zeros_like(dem, dtype=np.float32)
    depth[use_kin]  = h_kin[use_kin]
    depth[use_pond] = h_pond[use_pond]

    # ── 6. Volume conservation against runoff ───────────────────────
    V_depth_raw = float(depth.sum()) * px_area
    scale = 1.0
    if V_depth_raw > V_runoff_m3 and V_depth_raw > 0:
        scale = V_runoff_m3 / V_depth_raw
        depth *= scale
    # Re-apply mask after scaling so dry pixels stay zero
    depth[~mask] = 0.0
    V_depth = float(depth.sum()) * px_area

    # final smoothing — kill 1-pixel speckle in the depth field
    depth_sm = gaussian_filter(depth, sigma=0.7).astype(np.float32)
    depth_sm[~mask] = 0.0
    depth_sm[depth_sm < 0.02] = 0.0    # below 2 cm = noise floor

    # ── 6b. detected_mask enforcement (WS-4 reconciliation invariant) ─
    # When a sensor flood mask is supplied, zero depth outside it.
    # Gaussian smoothing may contaminate pixels adjacent to the flood
    # boundary — re-applying the detected_mask after every step is
    # the safest guard.
    if detected_mask is not None:
        det_bool = detected_mask.astype(bool)
        depth_sm[~det_bool] = 0.0

    # Volume ratio diagnostic (reported even if no capping was needed)
    V_final = float(depth_sm.sum()) * px_area
    volume_ratio = round(V_final / max(V_runoff_m3, 1e-6), 4)
    if volume_ratio > 2.0:
        L.warning(
            f"volume_ratio={volume_ratio:.2f} > 2.0 — FwDET may exceed "
            f"runoff volume on flat terrain; quality grade should be C at most."
        )

    stats = _build_stats(depth_sm, mask, precip_total_mm, cn_adj,
                         S_mm, Ia_mm, Q_mm, V_runoff_m3, V_depth,
                         manning_n, storm_duration_h, scale, use_pond,
                         use_kin, flood_area, catchment_area, pixel_m)
    # ── New WS-4 stats keys ───────────────────────────────────────────
    stats["amc_used"]     = amc_used
    stats["CN_adjusted"]  = round(cn_adj, 2)
    # Keep original curve_number for comparison
    stats["curve_number"] = float(curve_number)
    stats["volume_ratio"] = volume_ratio

    L.info(f"Hydro depth: max={stats['max_depth_m']:.2f}m, "
           f"mean={stats['mean_depth_m']:.2f}m, "
           f"p90={stats['p90_depth_m']:.2f}m, "
           f"V_depth={V_depth:,.0f} m³  "
           f"(scaled ×{scale:.3f}; "
           f"{stats['pond_pixels']:,} pond + "
           f"{stats['kinematic_pixels']:,} kinematic)  "
           f"AMC={amc_used}  vol_ratio={volume_ratio}")
    return depth_sm, stats


# ─────────────────────────────────────────────────────────────────────
# Simulation-only depth — no SAR observation required
# ─────────────────────────────────────────────────────────────────────
def depth_simulated_from_precip(dem, precip_total_mm,
                                curve_number=78,
                                manning_n=0.035,
                                storm_duration_h=6.0,
                                pixel_m=RESOLUTION_M,
                                max_depth=MAX_WATER_DEPTH_M,
                                min_depth_m=0.02,
                                flat_slope_threshold=0.005):
    """Pure hydrologic depth simulation — NO Sentinel-1 required.

    Runs the full HEC-HMS chain (SCS-CN → depression fill → D8 flow
    accumulation → Manning kinematic wave + FwDET sink-fill) and then
    DERIVES the flooded extent itself from the depth field: pixels with
    depth >= `min_depth_m` (default 2 cm) become the simulated flood
    pixels.  Useful when there is no post-event Sentinel-1 pass for the
    ROI — you can still answer *"what depth would this storm produce on
    this terrain?"* purely from DEM + precipitation.

    Returns (mask, depth, stats). Same stats schema as the combined
    SAR+hydrology path, with source tagged as simulation-only.
    """
    h, w = dem.shape
    px_area = pixel_m * pixel_m
    catchment_area = h * w * px_area

    Q_mm, S_mm, Ia_mm = scs_cn_runoff_mm(precip_total_mm, curve_number)
    V_runoff_m3 = (Q_mm * 1e-3) * catchment_area
    L.info(f"[SIM] SCS-CN: P={precip_total_mm:.1f} mm  CN={curve_number}  "
           f"→ Q={Q_mm:.2f} mm  V_runoff={V_runoff_m3:,.0f} m³")

    if Q_mm <= 0:
        empty = np.zeros_like(dem, dtype=np.float32)
        empty_mask = np.zeros_like(dem, dtype=np.uint8)
        stats = _empty_stats(precip_total_mm, curve_number, S_mm, Ia_mm,
                             Q_mm, V_runoff_m3, manning_n,
                             storm_duration_h, 0, catchment_area)
        stats["source"] = "HEC-HMS simulated (no SAR) — no runoff (P ≤ Iₐ)"
        return empty_mask, empty, stats

    L.info("[SIM] Fill + flow accumulation…")
    dem_filled = fill_depressions(dem.astype(np.float32))
    accumulation = flow_accumulation_d8(dem_filled)
    sink_depth_max = np.clip(dem_filled - dem, 0.0, max_depth).astype(np.float32)
    is_sink = sink_depth_max > 0.05

    # Manning kinematic depth over the WHOLE domain
    duration_s = max(60.0, storm_duration_h * 3600.0)
    runoff_q_ms = (Q_mm * 1e-3) / duration_s
    whole = np.ones(dem.shape, dtype=np.uint8)
    h_kin = _kinematic_depth(whole, dem, accumulation, runoff_q_ms,
                             manning_n, pixel_m, max_depth)
    # FwDET: depressions capped by their rim height
    h_pond = np.minimum(sink_depth_max, max_depth).astype(np.float32)

    gy, gx = np.gradient(dem.astype(np.float32), pixel_m, pixel_m)
    slope = np.hypot(gx, gy).astype(np.float32)
    use_pond_arr = (slope < flat_slope_threshold) | is_sink
    depth = np.where(use_pond_arr, h_pond, h_kin).astype(np.float32)

    # Volume conservation
    V_depth_raw = float(depth.sum()) * px_area
    scale = 1.0
    if V_depth_raw > V_runoff_m3 and V_depth_raw > 0:
        scale = V_runoff_m3 / V_depth_raw
        depth *= scale

    # Smooth + threshold into a mask
    depth = gaussian_filter(depth, sigma=0.7).astype(np.float32)
    mask = (depth >= min_depth_m).astype(np.uint8)
    depth[mask == 0] = 0.0
    V_depth = float(depth.sum()) * px_area
    flood_area = int(mask.sum()) * px_area

    vals = depth[mask.astype(bool)]
    stats = {
        "source":          "HEC-HMS simulated (no SAR) — SCS-CN + D8 + Manning + FwDET",
        "max_depth_m":     float(vals.max())              if vals.size else 0.0,
        "mean_depth_m":    float(vals.mean())             if vals.size else 0.0,
        "median_depth_m":  float(np.median(vals))         if vals.size else 0.0,
        "p90_depth_m":     float(np.percentile(vals, 90)) if vals.size else 0.0,
        "volume_m3":       float(V_depth),
        "flooded_pixels":  int(mask.sum()),
        "precip_total_mm": float(precip_total_mm),
        "curve_number":    float(curve_number),
        "S_mm":            round(float(S_mm), 2),
        "Ia_mm":           round(float(Ia_mm), 2),
        "runoff_Q_mm":     round(float(Q_mm), 3),
        "runoff_volume_m3":   round(float(V_runoff_m3), 1),
        "depth_volume_m3":    round(float(V_depth), 1),
        "volume_conservation_factor": round(float(scale), 4),
        "manning_n":       float(manning_n),
        "storm_duration_h": float(storm_duration_h),
        "pond_pixels":     int(use_pond_arr.sum()),
        "kinematic_pixels": int((~use_pond_arr).sum()),
        "flooded_km2":     round(flood_area / 1e6, 4),
        "catchment_km2":   round(catchment_area / 1e6, 4),
        "min_simulated_depth_m": float(min_depth_m),
    }
    L.info(f"[SIM] → {mask.sum():,} flooded px  "
           f"({stats['flooded_km2']} km²)  "
           f"max={stats['max_depth_m']:.2f} m  mean={stats['mean_depth_m']:.2f} m  "
           f"scale=×{scale:.3f}")
    return mask, depth, stats


# ── Stats helpers ─────────────────────────────────────────────────────
def _empty_stats(P, CN, S, Ia, Q, Vr, n, T, fa, ca):
    return {
        "source":          "HEC-HMS-style (SCS-CN + D8 + Manning + FwDET)",
        "max_depth_m":     0.0, "mean_depth_m": 0.0, "median_depth_m": 0.0,
        "p90_depth_m":     0.0, "volume_m3": 0.0, "flooded_pixels": 0,
        "precip_total_mm": float(P), "curve_number": float(CN),
        "S_mm": round(S, 2), "Ia_mm": round(Ia, 2),
        "runoff_Q_mm": round(Q, 3), "runoff_volume_m3": round(Vr, 1),
        "depth_volume_m3": 0.0, "volume_conservation_factor": 1.0,
        "manning_n": float(n), "storm_duration_h": float(T),
        "pond_pixels": 0, "kinematic_pixels": 0,
        "flooded_km2": round(fa / 1e6, 4),
        "catchment_km2": round(ca / 1e6, 4),
    }

def _build_stats(depth, mask, P, CN, S, Ia, Q, Vr, Vd, n, T, scale,
                 use_pond, use_kin, fa, ca, pixel_m):
    vals = depth[mask & (depth > 0)]
    return {
        "source":          "HEC-HMS-style (SCS-CN + D8 + Manning + FwDET)",
        "max_depth_m":     float(vals.max())             if vals.size else 0.0,
        "mean_depth_m":    float(vals.mean())            if vals.size else 0.0,
        "median_depth_m":  float(np.median(vals))        if vals.size else 0.0,
        "p90_depth_m":     float(np.percentile(vals, 90)) if vals.size else 0.0,
        "volume_m3":       float(Vd),
        "flooded_pixels":  int((depth > 0).sum()),
        "precip_total_mm": float(P), "curve_number": float(CN),
        "S_mm":            round(float(S), 2),
        "Ia_mm":           round(float(Ia), 2),
        "runoff_Q_mm":     round(float(Q), 3),
        "runoff_volume_m3":   round(float(Vr), 1),
        "depth_volume_m3":    round(float(Vd), 1),
        "volume_conservation_factor": round(float(scale), 4),
        "manning_n":       float(n),
        "storm_duration_h": float(T),
        "pond_pixels":     int(use_pond.sum()),
        "kinematic_pixels": int(use_kin.sum()),
        "flooded_km2":     round(fa / 1e6, 4),
        "catchment_km2":   round(ca / 1e6, 4),
    }
