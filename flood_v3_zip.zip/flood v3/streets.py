"""
╔══════════════════════════════════════════════════════════════════════╗
║         UAE FloodMap – Road Network Flood Impact Analysis           ║
║  OSM download · Per-segment depth · Severity classification        ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, numpy as np
from config import OSM_ROAD_TAGS, STREET_BUFFER_M

L = logging.getLogger("flood.streets")

def download_osm_streets(bbox):
    """Download OSM road network via osmnx."""
    import osmnx as ox
    try:
        north, south = bbox.max_y, bbox.min_y
        east, west   = bbox.max_x, bbox.min_x
        try:
            G = ox.graph_from_bbox(north, south, east, west,
                                   network_type="drive", simplify=True)
        except TypeError:
            G = ox.graph_from_bbox(bbox=(west, south, east, north),
                                   network_type="drive", simplify=True)
        edges = ox.graph_to_gdfs(G, nodes=False)
        L.info(f"OSM streets: {len(edges)} road segments")
        return edges
    except Exception as e:
        L.error(f"OSM download failed: {e}")
        return None

def compute_street_water_depth(streets, water_depth, bbox):
    """Sample water depth raster along each road segment."""
    import geopandas as gpd
    from shapely.geometry import box

    if streets is None or len(streets) == 0:
        return None

    h, w = water_depth.shape
    results = []

    for idx, row in streets.iterrows():
        geom = row.geometry
        if geom is None: continue

        # sample points along line
        try:
            length = geom.length
            n_pts = max(5, int(length * 111000 / STREET_BUFFER_M))
            depths = []
            for frac in np.linspace(0, 1, n_pts):
                pt = geom.interpolate(frac, normalized=True)
                px = int((pt.x - bbox.min_x) / (bbox.max_x - bbox.min_x) * w)
                py = int((bbox.max_y - pt.y) / (bbox.max_y - bbox.min_y) * h)
                if 0 <= px < w and 0 <= py < h:
                    depths.append(water_depth[py, px])
            if depths:
                max_d = float(np.max(depths))
                mean_d = float(np.mean(depths))
                cls, color = _flood_class(max_d)
                results.append({
                    "geometry": geom,
                    "name": row.get("name", "Unnamed"),
                    "highway": row.get("highway", "unknown"),
                    "max_depth_m": max_d,
                    "mean_depth_m": mean_d,
                    "flood_class": cls,
                    "color": color,
                    "length_m": length * 111000,  # approx deg to m
                })
        except Exception:
            continue

    if not results:
        return None

    gdf = gpd.GeoDataFrame(results, crs="EPSG:4326")
    L.info(f"Street analysis: {len(gdf)} segments, "
           f"{sum(1 for r in results if r['flood_class'] != 'dry')} flooded")
    return gdf

def _flood_class(depth_m):
    """Classify road flooding severity."""
    if depth_m < 0.05: return "dry",      "#808080"
    if depth_m < 0.15: return "low",      "#FFD700"
    if depth_m < 0.35: return "medium",   "#FF8C00"
    if depth_m < 0.65: return "high",     "#FF4500"
    return                     "critical", "#8B0000"

def flooded_streets_summary(gdf):
    """Aggregate street flood statistics."""
    if gdf is None or len(gdf) == 0:
        return {"total_km": 0, "flooded_km": 0, "pct_flooded": 0,
                "by_class": {}}
    total = gdf["length_m"].sum() / 1000
    flooded = gdf[gdf["flood_class"] != "dry"]["length_m"].sum() / 1000
    by_class = {}
    for cls in ["dry", "low", "medium", "high", "critical"]:
        sub = gdf[gdf["flood_class"] == cls]
        by_class[cls] = {
            "km": round(sub["length_m"].sum() / 1000, 2),
            "segments": len(sub),
        }
    return {
        "total_km": round(total, 2),
        "flooded_km": round(flooded, 2),
        "pct_flooded": round(100 * flooded / total, 1) if total > 0 else 0,
        "by_class": by_class,
    }
