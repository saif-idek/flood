"""
╔══════════════════════════════════════════════════════════════════════╗
║          UAE FloodMap – Precipitation Analysis Module               ║
║  ERA5 time-series · Cumulative curves · Return period estimation   ║
║  Antecedent conditions · Intensity classification                  ║
║                                                                      ║
║  Regime portability (Round-1 NF-04, Beck et al. 2018 KGE):          ║
║    The return-period heuristic and heavy/extreme thresholds were   ║
║    UAE-arid (BWh) hard-codes. We now classify the ROI bbox into a  ║
║    coarse Köppen-Geiger band and select a regime-localised lookup  ║
║    table. Outside calibrated regions we degrade to                  ║
║    ``return_period_est = "n/a (uncalibrated region)"`` rather than ║
║    silently misreporting Mediterranean rainfall as 25-yr.          ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, os, numpy as np, datetime as dt
from config import PRECIP_HEAVY_THRESH, PRECIP_EXTREME_THRESH

L = logging.getLogger("flood.precip")


# ─────────────────────────────────────────────────────────────────────
# Köppen-Geiger regime helper (coarse bbox lookup, NF-04)
# ─────────────────────────────────────────────────────────────────────
def _bbox_centroid(bbox):
    """Accept a (lon_min, lat_min, lon_max, lat_max) tuple/list, a dict
    with min_x/min_y/max_x/max_y or x1/y1/x2/y2 keys, or any object that
    exposes ``.min_x``/``.min_y``/``.max_x``/``.max_y`` attributes.
    Returns (lon, lat) of the centre or ``(None, None)`` if unparsable."""
    if bbox is None:
        return None, None
    try:
        if isinstance(bbox, (tuple, list)) and len(bbox) >= 4:
            lon = 0.5 * (float(bbox[0]) + float(bbox[2]))
            lat = 0.5 * (float(bbox[1]) + float(bbox[3]))
            return lon, lat
        if isinstance(bbox, dict):
            mx = bbox.get("min_x", bbox.get("x1"))
            my = bbox.get("min_y", bbox.get("y1"))
            Mx = bbox.get("max_x", bbox.get("x2"))
            My = bbox.get("max_y", bbox.get("y2"))
            if None not in (mx, my, Mx, My):
                return 0.5 * (float(mx) + float(Mx)), 0.5 * (float(my) + float(My))
        # Last resort: SH BBox-style object
        lon = 0.5 * (float(bbox.min_x) + float(bbox.max_x))
        lat = 0.5 * (float(bbox.min_y) + float(bbox.max_y))
        return lon, lat
    except Exception:
        return None, None


def kg_regime(lon, lat):
    """Coarse Köppen-Geiger regime label from a single (lon, lat) point.

    This is *not* a full 1-km KGE raster (Beck et al. 2018); it is an
    operational bbox-lookup good enough to choose the right return-period
    table inside the platform. Three labels are emitted today:

      * ``BWh_uae``      — Arabian arid (UAE / NE Oman). 22≤lat≤27, 51≤lon≤57.
      * ``Csa_med``      — Mediterranean (incl. Casablanca-Atlantic Morocco).
                            30≤lat≤45, -10≤lon≤40.
      * ``uncalibrated`` — anything else (no localisation).
    """
    if lon is None or lat is None:
        return "uncalibrated"
    try:
        lon = float(lon); lat = float(lat)
    except Exception:
        return "uncalibrated"
    # UAE arid first (smallest, most specific box)
    if 22.0 <= lat <= 27.0 and 51.0 <= lon <= 57.0:
        return "BWh_uae"
    # Mediterranean / Maghreb-Atlantic Csa
    if 30.0 <= lat <= 45.0 and -10.0 <= lon <= 40.0:
        return "Csa_med"
    return "uncalibrated"


def _regime_for_bbox(bbox):
    """Resolve the regime label for the given bbox, honouring env knobs.

    Env knobs (additive, default = current UAE behaviour preserved):
      * ``FLOOD_PRECIP_REGIME_OVERRIDE`` — operator override; if set to one
        of the known regime labels it wins.
      * ``FLOOD_PRECIP_REGIME_AUTO`` — when ``"0"``, force ``BWh_uae`` so
        the legacy UAE table is used regardless of bbox (regression knob).
    """
    override = os.environ.get("FLOOD_PRECIP_REGIME_OVERRIDE", "").strip()
    if override in ("BWh_uae", "Csa_med", "uncalibrated"):
        return override
    if os.environ.get("FLOOD_PRECIP_REGIME_AUTO", "1").strip() == "0":
        return "BWh_uae"
    lon, lat = _bbox_centroid(bbox)
    return kg_regime(lon, lat)


def _intensity_thresholds_for_regime(regime):
    """Heavy / extreme daily-rain thresholds (mm/day) per regime.

    UAE default is preserved exactly (PRECIP_HEAVY_THRESH=20,
    PRECIP_EXTREME_THRESH=50) — the legacy thresholds remain in
    ``config.py`` for ``BWh_uae`` and ``uncalibrated``.
    """
    if regime == "Csa_med":
        return 30.0, 80.0
    # BWh_uae and uncalibrated → preserve UAE config defaults
    return float(PRECIP_HEAVY_THRESH), float(PRECIP_EXTREME_THRESH)


def _return_period_for_regime(max_3day_mm, regime):
    """Regime-localised return-period heuristic for the peak 3-day total.

    The BWh_uae table is the legacy UAE table (kept exactly so Abu Dhabi
    Mar-2026 still reports ``25-50 year`` at ~110 mm/3-day).
    """
    if regime == "BWh_uae":
        if max_3day_mm >= 100: return "25-50 year"
        if max_3day_mm >= 70:  return "10-25 year"
        if max_3day_mm >= 50:  return "5-10 year"
        if max_3day_mm >= 30:  return "2-5 year"
        return "< 2 year"
    if regime == "Csa_med":
        # Casablanca / coastal-Mediterranean climatology (CHIRPS v2.0 +
        # IPCC AR6 ATLAS p99). 100 mm/3-day recurs every 2-5 yr here, not
        # 25-50 — the table is shifted accordingly.
        if max_3day_mm >= 200: return "25-50 year"
        if max_3day_mm >= 150: return "10-25 year"
        if max_3day_mm >= 100: return "5-10 year"
        if max_3day_mm >= 70:  return "2-5 year"
        if max_3day_mm >= 40:  return "1-2 year"
        return "< 1 year"
    # uncalibrated → no claim
    return "n/a (uncalibrated region)"


def _return_period_basis(regime):
    if regime == "BWh_uae":
        return "UAE arid (BWh) — 100 mm/3-day ≈ 25 yr"
    if regime == "Csa_med":
        return "Mediterranean (Csa) — 100 mm/3-day ≈ 5-10 yr"
    return "uncalibrated — no climatology lookup"


# ─────────────────────────────────────────────────────────────────────
# Regime-aware DETECTION defaults (Flood request #5 — Twele 2016,
# Manfreda 2014, Beck 2018).
# ─────────────────────────────────────────────────────────────────────
def regime_detection_defaults(regime):
    """Return (bhattacharyya_min, max_flood_slope_deg) per regime.

    UAE arid (``BWh_uae``) preserves the legacy global config defaults
    exactly (``BHATTACHARYYA_MIN``, ``MAX_FLOOD_SLOPE_DEG``). Mediterranean
    (``Csa_med``) loosens the Otsu-acceptance bar (BC ≤ 0.55 — Twele 2016
    §3.2 reports BC ≈ 0.5 on Elbe 2013) and lifts the slope ceiling to
    12° (Manfreda 2014 — pluvial flash-flooding on 10-15° hillslopes is
    routine in hilly temperate catchments). ``uncalibrated`` sits at the
    midpoint so non-UAE / non-Mediterranean ROIs do not silently inherit
    the strict UAE bar.

    Parameters
    ----------
    regime : str
        One of ``"BWh_uae"``, ``"Csa_med"``, ``"uncalibrated"``. Anything
        else falls back to the UAE defaults (regression guard).

    Returns
    -------
    (float, float)
        (bhattacharyya_min, max_flood_slope_deg)
    """
    # Late import — config.BHATTACHARYYA_MIN / MAX_FLOOD_SLOPE_DEG can be
    # mutated at runtime by the Flask /run route; we want the LIVE value.
    from config import BHATTACHARYYA_MIN, MAX_FLOOD_SLOPE_DEG
    if regime == "Csa_med":
        return 0.55, 12.0
    if regime == "uncalibrated":
        return 0.65, 10.0   # midpoint between UAE strict and Csa loose
    # BWh_uae or anything unknown → preserve current global UAE defaults
    return float(BHATTACHARYYA_MIN), float(MAX_FLOOD_SLOPE_DEG)


def _detect_regime_for_bbox(bbox):
    """Resolve the *detection* regime label, honouring the dedicated
    ``FLOOD_DETECTION_REGIME_*`` env knobs (independent of the
    precipitation-side knobs).

    Default behaviour preserves UAE byte-equal regression: when neither
    knob is set, returns ``"BWh_uae"`` regardless of bbox so the legacy
    ``BHATTACHARYYA_MIN`` / ``MAX_FLOOD_SLOPE_DEG`` defaults apply.
    Set ``FLOOD_DETECTION_REGIME_AUTO=1`` to enable bbox-based regime
    selection, or ``FLOOD_DETECTION_REGIME_OVERRIDE=<regime>`` to force.
    """
    override = os.environ.get("FLOOD_DETECTION_REGIME_OVERRIDE", "").strip()
    if override in ("BWh_uae", "Csa_med", "uncalibrated"):
        return override
    if os.environ.get("FLOOD_DETECTION_REGIME_AUTO", "0").strip() != "1":
        return "BWh_uae"
    lon, lat = _bbox_centroid(bbox)
    return kg_regime(lon, lat)


# ─────────────────────────────────────────────────────────────────────
# Main analysis
# ─────────────────────────────────────────────────────────────────────
def analyse_precipitation(precip_data):
    """
    Comprehensive precipitation analysis from ERA5 daily data.
    Returns enriched dict with cumulative, intensity classes, and stats.

    The dict is REGIME-AWARE (NF-04): the heavy/extreme thresholds and the
    return-period heuristic are localised to the Köppen-Geiger band the
    ROI falls in (BWh_uae / Csa_med / uncalibrated). UAE behaviour is
    preserved when the bbox falls inside the UAE polygon or no bbox is
    supplied (back-compat).
    """
    dates  = precip_data.get("dates", [])
    values = precip_data.get("precip_mm", [])
    rain   = precip_data.get("rain_mm", [])
    et0    = precip_data.get("et0_mm", [])
    bbox   = precip_data.get("bbox")        # NF-04: optional, may be None

    # clean None values
    values = [v if v is not None else 0.0 for v in values]
    rain   = [v if v is not None else 0.0 for v in rain]
    et0    = [v if v is not None else 0.0 for v in et0]

    n = len(values)
    if n == 0:
        return {"error": "No precipitation data"}

    # ── regime resolution (NF-04) ────────────────────────────────────
    regime = _regime_for_bbox(bbox)
    heavy_thresh, extreme_thresh = _intensity_thresholds_for_regime(regime)

    # cumulative precipitation
    cumulative = np.cumsum(values).tolist()

    # intensity classification per day (regime-localised cutoffs)
    intensity = []
    for v in values:
        if v >= extreme_thresh:
            intensity.append("extreme")
        elif v >= heavy_thresh:
            intensity.append("heavy")
        elif v >= 5.0:
            intensity.append("moderate")
        elif v > 0.5:
            intensity.append("light")
        else:
            intensity.append("dry")

    # antecedent precipitation index (API) with decay factor 0.85
    api = [0.0]
    k = 0.85
    for i in range(1, n):
        api.append(api[-1] * k + values[i])

    # find peak event window (max 3-day sum)
    vals = np.array(values)
    max_3day = 0; peak_start = 0
    for i in range(max(0, n-2)):
        s = vals[i:i+3].sum()
        if s > max_3day:
            max_3day = s; peak_start = i
    peak_end = min(peak_start + 2, n - 1)

    # water balance: precip - ET0
    water_balance = [values[i] - et0[i] for i in range(n)]
    cum_water_balance = np.cumsum(water_balance).tolist()

    # rain/total ratio (how much is liquid vs snow)
    total = sum(values)
    rain_total = sum(rain)
    rain_ratio = rain_total / total if total > 0 else 1.0

    # regime-localised return-period (NF-04)
    rp_est = _return_period_for_regime(max_3day, regime)

    result = {
        "dates": dates,
        "daily_mm": values,
        "cumulative_mm": cumulative,
        "rain_mm": rain,
        "et0_mm": et0,
        "intensity": intensity,
        "api": api,
        "water_balance": water_balance,
        "cum_water_balance": cum_water_balance,
        "total_mm": total,
        "peak_day_mm": max(values),
        "peak_day_date": dates[values.index(max(values))] if values else None,
        "max_3day_mm": float(max_3day),
        "peak_3day_window": f"{dates[peak_start]} to {dates[peak_end]}",
        "heavy_days": sum(1 for i in intensity if i == "heavy"),
        "extreme_days": sum(1 for i in intensity if i == "extreme"),
        "dry_days": sum(1 for i in intensity if i == "dry"),
        "rain_ratio": rain_ratio,
        "return_period_est": rp_est,
        "max_api": max(api),
        "final_api": api[-1] if api else 0,
        "source":           precip_data.get("source", "ERA5"),
        "n_sample_points":  precip_data.get("n_sample_points", 1),
        "total_mean_mm":    precip_data.get("total_mean_mm"),
        # NF-04 additions — UI may surface them, never replaces the above.
        "regime":              regime,
        "return_period_basis": _return_period_basis(regime),
        "heavy_thresh_mm":     float(heavy_thresh),
        "extreme_thresh_mm":   float(extreme_thresh),
    }
    L.info(f"Precip analysis [{regime}]: total={total:.1f}mm, peak={max(values):.1f}mm, "
           f"3-day max={max_3day:.1f}mm, return period≈{rp_est}")
    return result


def precipitation_risk_score(analysis):
    """
    Compute a 0-100 flood risk score based on precipitation patterns.
    Factors: peak intensity, cumulative total, antecedent wetness, duration.

    NF-04 hard zero-floor: when ``total_mm <= 0.5`` (essentially a dry
    window), return 0 exactly. Without this floor, any non-zero antecedent
    API or peak-day term will lift the score above zero even though the
    window saw no rain.
    """
    if "error" in analysis: return 0
    # NF-04 zero-floor — operationally a window with < 0.5 mm total is
    # indistinguishable from a dry window; we should not be reporting
    # any flood risk against it.
    if analysis.get("total_mm", 0.0) <= 0.5:
        return 0
    score = 0
    # peak intensity (0-30 pts)
    peak = analysis.get("peak_day_mm", 0)
    score += min(30, peak * 0.6)
    # 3-day total (0-25 pts)
    m3d = analysis.get("max_3day_mm", 0)
    score += min(25, m3d * 0.35)
    # antecedent wetness (0-20 pts)
    api = analysis.get("max_api", 0)
    score += min(20, api * 0.15)
    # duration of heavy/extreme days (0-15 pts)
    hd = analysis.get("heavy_days", 0) + analysis.get("extreme_days", 0)
    score += min(15, hd * 5)
    # total accumulation bonus (0-10 pts)
    total = analysis.get("total_mm", 0)
    score += min(10, total * 0.05)
    return min(100, round(score, 1))
