"""Generate Sentinel-1 methodology PDF for UAE FloodMap."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, PageBreak)
from reportlab.lib.enums import TA_JUSTIFY

OUT = "/home/wassi/UAE_FloodMap/Sentinel1_Methodology.pdf"

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="Body2", parent=styles["BodyText"],
                          alignment=TA_JUSTIFY, fontSize=10, leading=14,
                          spaceAfter=6))
styles.add(ParagraphStyle(name="H1b", parent=styles["Heading1"],
                          fontSize=16, textColor=colors.HexColor("#0b4f6c"),
                          spaceBefore=14, spaceAfter=8))
styles.add(ParagraphStyle(name="H2b", parent=styles["Heading2"],
                          fontSize=12, textColor=colors.HexColor("#145374"),
                          spaceBefore=10, spaceAfter=4))
styles.add(ParagraphStyle(name="CodeBlk", parent=styles["BodyText"],
                          fontName="Courier", fontSize=9, leading=12,
                          leftIndent=12, textColor=colors.HexColor("#333333"),
                          spaceAfter=6))

doc = SimpleDocTemplate(OUT, pagesize=A4,
                        leftMargin=2*cm, rightMargin=2*cm,
                        topMargin=2*cm, bottomMargin=2*cm,
                        title="UAE FloodMap — Sentinel-1 Methodology")

S = []
P = lambda t, s="Body2": S.append(Paragraph(t, styles[s]))
SP = lambda h=0.3: S.append(Spacer(1, h*cm))

# Title
P("UAE FloodMap v3 — Sentinel-1 SAR Flood Detection Methodology", "Title")
P("Pre-processing and processing pipeline as implemented in the operational codebase "
  "(<i>downloader.py</i>, <i>detection.py</i>, <i>postprocessing.py</i>).", "Body2")
SP()

# 1. Acquisition
P("1. Acquisition", "H1b")
P("Sentinel-1 IW GRD scenes are retrieved on-demand from the Copernicus Data Space "
  "Ecosystem (CDSE) via the Sentinel Hub Process API "
  "(<font face='Courier'>DataCollection.SENTINEL1_IW</font>). Both VV and VH "
  "polarisations are requested in <b>LINEAR_POWER</b> units as 32-bit float, so "
  "that dB conversion and speckle filtering are performed locally under full "
  "numerical control.")
P("The following server-side processing options are passed with every request:", "Body2")

tbl = [["Option", "Value", "Purpose"],
       ["orthorectify", "True", "Geocoding to map grid"],
       ["demInstance", "COPERNICUS_30", "30 m DEM for terrain correction"],
       ["backCoeff", "GAMMA0_TERRAIN", "Radiometric terrain flattening (γ⁰)"],
       ["speckleFilter", "NONE", "Speckle handled locally (Lee / refined-Lee)"],
       ["mosaickingOrder", "mostRecent", "Latest acquisition within window"]]
t = Table(tbl, colWidths=[3.6*cm, 4.2*cm, 8.5*cm])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0b4f6c")),
    ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("FONTNAME", (0,1), (0,-1), "Courier"),
    ("FONTNAME", (1,1), (1,-1), "Courier"),
    ("FONTSIZE", (0,0), (-1,-1), 9),
    ("GRID", (0,0), (-1,-1), 0.3, colors.grey),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f2f6f8")]),
    ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
    ("LEFTPADDING", (0,0), (-1,-1), 4),
    ("RIGHTPADDING", (0,0), (-1,-1), 4)]))
S.append(t)
SP()

P("Large AOIs exceed the Sentinel Hub 2500 px/side synchronous limit, so "
  "<font face='Courier'>_split_bbox()</font> tiles the request, downloads each "
  "tile independently and mosaics them seamlessly. Default ground resolution is "
  "20 m, automatically relaxed to 40 m for AOIs &gt; 2500 km². Before/after "
  "pairs are cached as pickles under <font face='Courier'>outputs/cache/</font> "
  "keyed by an MD5 hash of <i>bbox + dates + resolution</i>, so repeated runs "
  "avoid re-downloading.")
SP()

# 2. Pre-processing
P("2. Local Pre-processing", "H1b")

P("2.1 Linear → decibels", "H2b")
P("All subsequent algorithms operate in dB space. Conversion clamps the input "
  "to avoid −∞:")
P("dB = 10 · log10( clip(x, 1e-10, inf) )", "CodeBlk")

P("2.2 Speckle filtering", "H2b")
P("Two adaptive speckle filters are implemented and selected per detection "
  "method:")
P("<b>Enhanced Lee</b> (default 5×5 window) — used by threshold, Otsu and "
  "Z-score methods. Adaptive weighting based on local vs. global variance:", "Body2")
P("w = var_local / (var_local + var_global)<br/>"
  "out = mean_local + w * (x - mean_local)", "CodeBlk")
P("<b>Refined Lee</b> (7×7) — used by the edge-aware method. Four directional "
  "kernels (horizontal, vertical, and two diagonals) are evaluated; for every "
  "pixel the direction with minimum local variance is retained. This preserves "
  "linear features (roads, channel edges, urban boundaries) that the isotropic "
  "Lee filter blurs.", "Body2")
SP()

# 3. Change detection
P("3. Bi-temporal Change Detection", "H1b")
P("Five detection methods are executed on the co-registered before/after pair "
  "(H×W×2 array, channels = VV, VH). Each returns a binary flood mask.")

tbl = [["#", "Method", "Signal", "Decision rule"],
       ["M1", "Fixed threshold", "ΔdB = dB_after − dB_before (VV)", "Δ < −1.0 dB"],
       ["M2", "Otsu",       "log₁₀(VV_after / VV_before)",      "lr < min(t_otsu, −0.1)"],
       ["M3", "Z-score",    "(ΔdB − μ)/σ of VV",                "z < −1.5 σ"],
       ["M4", "Edge-aware", "0.6·mask_VV + 0.4·mask_VH (refined-Lee)", "combined > 0.45"],
       ["M5", "Ensemble",   "majority vote of M1–M4",           "votes ≥ N_min"]]
t = Table(tbl, colWidths=[1.0*cm, 2.7*cm, 6.4*cm, 6.2*cm])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#145374")),
    ("TEXTCOLOR", (0,0), (-1,0), colors.white),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("FONTSIZE", (0,0), (-1,-1), 9),
    ("GRID", (0,0), (-1,-1), 0.3, colors.grey),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f2f6f8")]),
    ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
    ("LEFTPADDING", (0,0), (-1,-1), 4),
    ("RIGHTPADDING", (0,0), (-1,-1), 4)]))
S.append(t)
SP(0.4)

P("The physical rationale is that inundation drops VV backscatter sharply "
  "(specular reflection off smooth water) while VH, already low over land, "
  "changes less. The VV/VH weighting in M4 therefore emphasises the dominant "
  "VV signal while keeping VH as a consistency check. The ensemble (M5) is the "
  "mask forwarded to post-processing.")
SP()

# 4. Post-processing
P("4. Mask Post-processing", "H1b")
P("The ensemble mask is cleaned in a fixed 5-step sequence "
  "(<i>postprocessing.py</i>):")
steps = [
    ("1. Permanent water removal",
     "Sentinel-2 NDWI mask is resampled to the SAR grid and subtracted, "
     "so coastlines, rivers, lakes and aquaculture ponds are not flagged as flood."),
    ("2. Slope filter",
     "Slope is estimated from the Copernicus DEM as "
     "|∇DEM|·100 (approximate %). Pixels above the configured threshold are "
     "dropped — standing water does not pool on steep terrain."),
    ("3. Morphological closing",
     "3×3 structuring element, 2 iterations. Bridges 1–2 px speckle gaps in "
     "otherwise-contiguous flood patches."),
    ("4. Hole filling",
     "<font face='Courier'>binary_fill_holes</font> closes interior voids "
     "(e.g. buildings embedded in a flooded block)."),
    ("5. Small-blob removal",
     "Connected-component labelling removes components smaller than "
     "<font face='Courier'>MIN_FLOOD_PIXELS</font>, eliminating isolated "
     "speckle false positives.")]
for title, body in steps:
    P(f"<b>{title}</b> — {body}", "Body2")
SP()

P("The cleaned mask is then passed to <i>flood_sim.py</i>, which combines the "
  "DEM, rainfall-runoff (0.25–0.30 coefficient), D8 flow accumulation, "
  "depression filling and boundary interpolation to produce a per-pixel water "
  "depth map (capped at 0.50 m).")
SP()

# Footer
P("<i>Reference implementation: /home/wassi/UAE_FloodMap/ "
  "(downloader.py · detection.py · postprocessing.py · flood_sim.py). "
  "Validated on Abu Dhabi Apr-2024 and Mar-2026 flood events.</i>", "Body2")

doc.build(S)
print(f"Written: {OUT}")
