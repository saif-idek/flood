"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                UAE FloodMap v3 – Automatic Pipeline Backend                ║
║   Draw ROI → Full SAR flood analysis runs automatically                    ║
║   Precip first → Sentinel-1 → Detection → Depth → Streets                ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Author : Wassim                                                           ║
║  Stack  : Flask + Sentinel Hub CDSE + Open-Meteo + Mapbox GL JS           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
import logging, os, io, json, base64, hashlib, pickle, datetime as dt, traceback, threading
import numpy as np
from flask import Flask, request, jsonify, send_from_directory, send_file, Response
from flask_cors import CORS

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s")
L = logging.getLogger("flood.app")

app = Flask(__name__, static_folder="static")
CORS(app)
from config import *

# ── Pipeline State ───────────────────────────────────────────────────
STATE = {"phase":"idle","progress":0,"message":"","results":{},
         "bbox":None,"params":{},"roi_km2":0,
         "before_sar":None,"after_sar":None,
         "water_mask":None,"dem":None,"detections":None,
         "cleaned_masks":{},"water_depth":None,"depth_stats":None,
         "streets_gdf":None,"precip_analysis":None,"error":None}

CACHE_DIR = os.path.join(OUTPUT_DIR, "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

def _cache_key(bbox, params):
    """Generate a unique hash for bbox + date params."""
    sig = f"{bbox.min_x:.6f},{bbox.min_y:.6f},{bbox.max_x:.6f},{bbox.max_y:.6f}" \
          f"|{params.get('before_start')}|{params.get('before_end')}" \
          f"|{params.get('after_start')}|{params.get('after_end')}"
    return hashlib.md5(sig.encode()).hexdigest()[:12]

def _cache_save(key, tag, data):
    """Save numpy array or dict to cache."""
    path = os.path.join(CACHE_DIR, f"{key}_{tag}.pkl")
    with open(path, "wb") as f:
        pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)
    L.info(f"Cache saved: {tag} ({os.path.getsize(path)/1024:.0f} KB)")

def _cache_load(key, tag):
    """Load cached data, returns None if not found."""
    path = os.path.join(CACHE_DIR, f"{key}_{tag}.pkl")
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        data = pickle.load(f)
    L.info(f"Cache hit: {tag}")
    return data

def _cache_exists(key, tag):
    return os.path.exists(os.path.join(CACHE_DIR, f"{key}_{tag}.pkl"))

def _set(phase, progress, message):
    STATE["phase"]=phase; STATE["progress"]=progress; STATE["message"]=message
    L.info(f"[{progress}%] {phase}: {message}")

# ── Helpers ──────────────────────────────────────────────────────────
def _safe(obj):
    if isinstance(obj,(np.integer,)): return int(obj)
    if isinstance(obj,(np.floating,)): return float(obj)
    if isinstance(obj,np.ndarray): return obj.tolist()
    if isinstance(obj,dict): return {k:_safe(v) for k,v in obj.items()}
    if isinstance(obj,(list,tuple)): return [_safe(v) for v in obj]
    return obj

def _arr_to_png64(arr, cmap="viridis", vmin=None, vmax=None):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(1,1,figsize=(6,5))
    finite=arr[np.isfinite(arr)]
    if vmin is None and len(finite): vmin=np.percentile(finite,2)
    if vmax is None and len(finite): vmax=np.percentile(finite,98)
    ax.imshow(arr,cmap=cmap,vmin=vmin,vmax=vmax); ax.axis("off")
    buf=io.BytesIO()
    fig.savefig(buf,format="png",dpi=120,bbox_inches="tight",facecolor="#080C14",pad_inches=0.02)
    plt.close(fig); buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def _arr_to_geo_png(arr, out_path, cmap="gray", vmin=None, vmax=None,
                    alpha_mask=None):
    """Save a raster as a tight RGBA PNG with no axes/padding — ready to
    register as a Mapbox image source spanning the scene bbox.  If
    alpha_mask is provided, pixels where alpha_mask is 0 are fully
    transparent."""
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import cm as mpl_cm
    from matplotlib.colors import Normalize
    finite = arr[np.isfinite(arr)]
    if vmin is None: vmin = float(np.percentile(finite, 2)) if finite.size else 0.0
    if vmax is None: vmax = float(np.percentile(finite, 98)) if finite.size else 1.0
    norm = Normalize(vmin=vmin, vmax=vmax, clip=True)
    cmapper = mpl_cm.get_cmap(cmap)
    rgba = (cmapper(norm(arr)) * 255).astype(np.uint8)  # H,W,4
    if alpha_mask is not None:
        rgba[..., 3] = np.where(alpha_mask.astype(bool), rgba[..., 3], 0)
    # Also zero-alpha the NaN pixels
    rgba[..., 3] = np.where(np.isfinite(arr), rgba[..., 3], 0)
    try:
        import imageio.v2 as imageio
        imageio.imwrite(out_path, rgba)
    except Exception:
        fig, ax = plt.subplots(figsize=(8, 8), dpi=100)
        ax.imshow(rgba); ax.axis("off")
        fig.savefig(out_path, bbox_inches="tight", pad_inches=0, transparent=True)
        plt.close(fig)
    return vmin, vmax

def _build_ocean_mask(bbox, dem, target_shape):
    """Global ocean / coastal-water mask. Returns uint8 (1 = ocean).

    Combines (logical OR):
      - DEM ≤ 0.5 m (Copernicus DEM reports sea surface at 0)
      - OSM coastline + water polygons (dilated ~120 m to swallow speckle)

    Used to wipe flood polygons and depth from the sea before they
    reach the GeoJSON / streets / figures stages.
    """
    h, w = target_shape
    om = np.zeros((h, w), dtype=np.uint8)
    # 1. DEM-based: anything at/below sea level
    if dem is not None:
        d = dem
        if d.shape != target_shape:
            from scipy.ndimage import zoom
            zy = h / d.shape[0]; zx = w / d.shape[1]
            d = zoom(d, (zy, zx), order=1)
        om |= (d <= 0.5).astype(np.uint8)
    # 2. OSM coastline + water polygons
    try:
        from downloader import download_osm_water_mask
        osm = download_osm_water_mask(bbox, target_shape)
        if osm is not None and osm.size > 0:
            om |= osm.astype(np.uint8)
    except Exception as e:
        L.warning(f"OSM ocean mask skipped: {e}")
    # 3. Dilate to swallow coastline pixels
    try:
        from scipy.ndimage import binary_dilation
        om = binary_dilation(om.astype(bool), iterations=6).astype(np.uint8)
    except Exception:
        pass
    L.info(f"Ocean mask: {int(om.sum())} px ({100*om.mean():.1f}%)")
    return om

def _apply_ocean_mask(mask, depth, bbox, dem):
    """Strip ocean pixels from a flood mask + depth raster in-place-style.
    Returns (clean_mask, clean_depth, ocean_mask). Safe with depth=None."""
    target = mask.shape
    om = _build_ocean_mask(bbox, dem, target)
    cm = mask.copy()
    cm[om > 0] = 0
    cd = depth
    if depth is not None:
        cd = depth.copy()
        cd[om > 0] = 0.0
    return cm, cd, om

def _mask_to_geojson(mask, bbox):
    from rasterio.features import shapes as rio_shapes
    from rasterio.transform import from_bounds
    h,w=mask.shape; t=from_bounds(bbox.min_x,bbox.min_y,bbox.max_x,bbox.max_y,w,h)
    feats=[]
    for geom,val in rio_shapes(mask.astype(np.uint8),transform=t):
        if val==1: feats.append({"type":"Feature","properties":{"class":"flood"},"geometry":geom})
    return {"type":"FeatureCollection","features":feats}

def _depth_to_geojson(depth, bbox, mask):
    from rasterio.features import shapes as rio_shapes
    from rasterio.transform import from_bounds
    from water_depth import DEPTH_BANDS
    h,w=depth.shape; t=from_bounds(bbox.min_x,bbox.min_y,bbox.max_x,bbox.max_y,w,h)
    feats=[]; prev=0.01
    for threshold,label,color in DEPTH_BANDS:
        if label=="dry": prev=threshold; continue
        band=(depth>prev)&(depth<=threshold)&mask.astype(bool); prev_m=prev; prev=threshold
        if band.sum()==0: continue
        # Per-band statistics so the 3D extrusion can use a real metres-height.
        bd=depth[band]
        mean_m=float(bd.mean()); max_m=float(bd.max())
        for geom,val in rio_shapes(band.astype(np.uint8),transform=t):
            if val==1:
                feats.append({"type":"Feature","properties":{
                    "depth_class":label,"color":color,
                    "mean_depth_m":round(mean_m,3),
                    "max_depth_m":round(max_m,3),
                    "band_min_m":round(prev_m,3),
                    "band_max_m":round(min(threshold,max_m),3)},
                    "geometry":geom})
    return {"type":"FeatureCollection","features":feats}

def _streets_to_geojson(gdf):
    if gdf is None: return {"type":"FeatureCollection","features":[]}
    feats=[]
    for _,row in gdf.iterrows():
        if row.geometry is None: continue
        feats.append({"type":"Feature",
            "properties":{"name":str(row.get("name","Unnamed")),"highway":str(row.get("highway","")),
                          "max_depth_m":round(row.get("max_depth_m",0),3),
                          "mean_depth_m":round(row.get("mean_depth_m",0),3),
                          "flood_class":row.get("flood_class","dry"),"color":row.get("color","#808080")},
            "geometry":row.geometry.__geo_interface__})
    return {"type":"FeatureCollection","features":feats}

def _streets_to_buffered_geojson(gdf, buffer_m=8.0, only_flooded=True):
    """Buffer each street line into a thin polygon for 3D extrusion.
    Mapbox GL has no `line-extrusion` — turning every road into an 8 m-wide
    polygon lets the same `fill-extrusion` engine extrude it by depth.
    Buffering is done in local UTM (true metres), then back to WGS84."""
    if gdf is None or len(gdf) == 0:
        return {"type":"FeatureCollection","features":[]}
    g = gdf.copy()
    if only_flooded and "max_depth_m" in g.columns:
        g = g[g["max_depth_m"] > 0.02]
        if len(g) == 0:
            return {"type":"FeatureCollection","features":[]}
    utm = g.estimate_utm_crs()
    g_utm = g.to_crs(utm)
    g_utm["geometry"] = g_utm.geometry.buffer(float(buffer_m), cap_style=2,
                                              join_style=2)
    g_wgs = g_utm.to_crs("EPSG:4326")
    feats=[]
    for _, row in g_wgs.iterrows():
        if row.geometry is None or row.geometry.is_empty: continue
        feats.append({"type":"Feature",
            "properties":{"name":str(row.get("name","Unnamed")),
                          "highway":str(row.get("highway","")),
                          "max_depth_m":round(float(row.get("max_depth_m",0)),3),
                          "mean_depth_m":round(float(row.get("mean_depth_m",0)),3),
                          "flood_class":row.get("flood_class","dry"),
                          "color":row.get("color","#808080")},
            "geometry":row.geometry.__geo_interface__})
    return {"type":"FeatureCollection","features":feats}

def _roi_km2(bbox):
    from pyproj import Transformer
    t=Transformer.from_crs("EPSG:4326","EPSG:32640",always_xy=True)
    x1,y1=t.transform(bbox.min_x,bbox.min_y); x2,y2=t.transform(bbox.max_x,bbox.max_y)
    return abs(x2-x1)*abs(y2-y1)/1e6


# ─────────────────────────────────────────────────────────────────────
# SAR finalisation helper (NF-05 — request #4)
# ─────────────────────────────────────────────────────────────────────
def _finalise_sar_results(R, det, bbox, dem=None, water_mask=None,
                          roi_km2=None, write_files=True):
    """Common SAR post-processing finalisation.

    Pure rearrangement of the post-process block that used to live
    in-line inside ``_run_pipeline`` (~L757-782). Runs:
      1. ``postprocessing.clean_mask`` (permanent-water re-enforcement
         + connected-component count);
      2. ``_apply_ocean_mask`` (DEM ≤ 0.5 m ∪ OSM coastline);
      3. (optionally) writes the threshold raster + shapefile;
      4. mutates ``R`` in place with ``postprocess``, ``flood_geojson``,
         and the NF-05 ``no_flood_detected`` honesty flag.

    Returns the cleaned mask + the ocean mask so the caller can keep
    using them for downstream depth / streets stages without re-running
    the ocean computation.

    The helper is callable standalone (e.g. from the null-hypothesis
    harness with ``det = {"mask": np.zeros(...)}``) — no side-effects on
    STATE beyond what the caller wires in. The live SAR pipeline still
    pokes ``STATE["ocean_mask"]`` / ``STATE["cleaned_masks"]`` itself
    so behaviour is byte-identical to the pre-refactor code path.
    """
    from postprocessing import clean_mask
    from exporter import save_mask, save_flood_shapefile
    raw_mask = det["mask"] if isinstance(det, dict) else det
    cm, info = clean_mask(raw_mask, water_mask)
    cm, _, ocean_m = _apply_ocean_mask(cm, None, bbox, dem)
    if write_files:
        try:
            save_mask(cm, bbox, os.path.join(OUTPUT_DIR, "flood_threshold.tif"))
            save_flood_shapefile(
                cm, bbox,
                os.path.join(OUTPUT_DIR, "flood_threshold.shp"),
                method_name="threshold",
                post_db=det.get("post_db") if isinstance(det, dict) else None)
        except Exception as _e:
            L.warning(f"[finalise_sar] write_files skipped: {_e}")
    if roi_km2 is None:
        roi_km2 = float(STATE.get("roi_km2") or 0.0)
    post_results = {"threshold": {
        "pct":        round(100 * cm.mean(), 3),
        "km2":        round(roi_km2 * cm.mean(), 4),
        "polygons":   info.get("n_components", 0),
        "cleaned_px": info.get("final_pixels", 0),
    }}
    R["postprocess"]   = post_results
    R["flood_geojson"] = _mask_to_geojson(cm, bbox)
    # NF-05 — null-hypothesis honesty flag the UI keys off.
    R["no_flood_detected"] = bool(int(cm.sum()) == 0)
    return cm, ocean_m, info, post_results

# ═════════════════════════════════════════════════════════════════════
#  MODIS PIPELINE — fast, no SAR needed
# ═════════════════════════════════════════════════════════════════════
def _run_modis_pipeline(bbox, params, settings):
    try:
        import config
        for k,v in settings.items():
            if k=="resolution": config.RESOLUTION_M=int(v)

        STATE["bbox"]=bbox; STATE["params"]=params
        STATE["roi_km2"]=_roi_km2(bbox); STATE["error"]=None
        R=STATE["results"]; R["mode"]="modis"

        # ── 1. PRECIPITATION (0-15%) ─────────────────────────────────
        _set("precip",2,"Fetching precipitation data…")
        from downloader import download_precipitation_era5
        from precipitation import analyse_precipitation, precipitation_risk_score
        date_end=params.get("after_end",params.get("after_start"))
        precip_data=download_precipitation_era5(bbox, date_end, lookback_days=21)
        analysis=analyse_precipitation(precip_data)
        analysis["risk_score"]=precipitation_risk_score(analysis)
        STATE["precip_analysis"]=analysis; R["precip"]=analysis
        from visualizer import fig_precipitation
        fig_precipitation(analysis)
        _set("precip",15,f"Precip done: {analysis['total_mm']:.0f}mm, risk {analysis['risk_score']}/100")

        # ── 2. MODIS FLOOD MAP (15-50%) ──────────────────────────────
        _set("detection",20,"Downloading MODIS NRT flood map…")
        from downloader import download_modis_flood_map
        # Use the after_end date to find the closest MODIS map to the flood event
        modis_date = params.get("after_end", date_end)
        flood_mask, modis_stats = download_modis_flood_map(bbox, modis_date, days_window=10)

        if flood_mask is None:
            R["modis"]=modis_stats
            err_msg=modis_stats.get("error","No MODIS data available")
            STATE["error"]=err_msg
            _set("error",25,f"MODIS: {err_msg}")
            return

        R["modis"]=modis_stats
        flood_pct=modis_stats["flood_pct"]
        flood_px=modis_stats["flood_pixels"]
        R["detection"]={"modis":{"flood_pixels":flood_px,
            "pct":flood_pct,
            "km2":round(STATE["roi_km2"]*flood_pct/100,4)}}
        STATE["detections"]={"modis":{"mask":flood_mask}}

        if flood_px == 0:
            _set("detection",50,f"MODIS: No flood detected at 250m. {modis_stats.get('note','')}")
        else:
            _set("detection",50,f"MODIS flood: {flood_pct:.2f}% flooded ({flood_px} px)")

        # ── 3. DEM (50-65%) ──────────────────────────────────────────
        _set("auxiliary",55,"Downloading DEM…")
        from downloader import download_dem
        target=flood_mask.shape
        dem=download_dem(bbox,target); STATE["dem"]=dem
        R["dem"]={"min":float(dem.min()),"max":float(dem.max()),"mean":float(dem.mean()),
                  "preview":_arr_to_png64(dem,"terrain")}
        _set("auxiliary",65,f"DEM: {dem.min():.0f}–{dem.max():.0f}m")

        # ── 4. POST-PROCESS (65-72%) ─────────────────────────────────
        _set("postprocess",67,"Cleaning MODIS flood mask…")
        from postprocessing import clean_mask
        from exporter import save_mask, save_flood_shapefile
        if flood_px > 0:
            cm,info=clean_mask(flood_mask, None, dem=dem, max_slope=30)
        else:
            cm=flood_mask; info={"n_components":0,"final_pixels":0}
        # Global ocean guard (DEM ≤ 0.5 m ∪ OSM water).
        cm,_,ocean_m = _apply_ocean_mask(cm, None, bbox, dem)
        STATE["ocean_mask"]=ocean_m
        STATE["cleaned_masks"]["modis"]=cm
        save_mask(cm,bbox,os.path.join(OUTPUT_DIR,"flood_modis.tif"))
        if cm.sum()>0:
            save_flood_shapefile(cm,bbox,os.path.join(OUTPUT_DIR,"flood_modis.shp"),"modis")
        cp={"pct":round(100*cm.mean(),3),"km2":round(STATE["roi_km2"]*cm.mean(),4),
            "polygons":info.get("n_components",0),"cleaned_px":info.get("final_pixels",0)}
        R["postprocess"]={"modis":cp}
        # NF-05 — null-hypothesis honesty flag the UI keys off.
        R["no_flood_detected"] = bool(int(cm.sum()) == 0)
        if cm.sum()>0:
            R["flood_geojson"]=_mask_to_geojson(cm,bbox)
        _set("postprocess",72,f"MODIS cleaned: {cp['km2']:.3f} km²")

        # ── 5. FLOOD SIMULATION: DEM + Rainfall (72-84%) ────────────
        _set("depth",74,"Simulating flood depth: DEM + rainfall-runoff + flow accumulation…")
        from flood_sim import rainfall_runoff_depth
        precip_total=analysis.get("total_mm",0)
        depth,depth_stats=rainfall_runoff_depth(cm,dem,precip_total,None)
        if STATE.get("ocean_mask") is not None:
            depth[STATE["ocean_mask"]>0] = 0.0
        STATE["water_depth"]=depth; STATE["depth_stats"]=depth_stats
        R["depth"]=depth_stats
        if cm.sum()>0:
            R["depth_geojson"]=_depth_to_geojson(depth,bbox,cm)
            flooded_d=depth[depth>0.01]
            if len(flooded_d)>0:
                hist,edges=np.histogram(flooded_d,bins=25)
                R["depth_histogram"]={"counts":hist.tolist(),"edges":edges.tolist()}
        _set("depth",78,f"Depth: max {depth_stats['max_depth_m']:.2f}m, mean {depth_stats['mean_depth_m']:.2f}m")

        # ── 6. STREETS (78-88%) ──────────────────────────────────────
        _set("streets",80,"Downloading road network…")
        from streets import download_osm_streets, compute_street_water_depth, flooded_streets_summary
        streets_gdf=None
        try:
            streets=download_osm_streets(bbox)
            if streets is not None and len(streets)>0:
                streets_gdf=compute_street_water_depth(streets,depth,bbox)
                STATE["streets_gdf"]=streets_gdf
                R["streets"]=flooded_streets_summary(streets_gdf)
                R["streets_geojson"]=_streets_to_geojson(streets_gdf);R["streets_3d_geojson"]=_streets_to_buffered_geojson(streets_gdf)
                _set("streets",88,f"Roads: {R['streets']['flooded_km']:.1f} km flooded / {R['streets']['total_km']:.1f} km total")
            else:
                R["streets"]={"total_km":0,"flooded_km":0}
                R["streets_geojson"]={"type":"FeatureCollection","features":[]}
                _set("streets",88,"No roads found")
        except Exception as e:
            R["streets"]={"total_km":0,"flooded_km":0,"error":str(e)}
            R["streets_geojson"]={"type":"FeatureCollection","features":[]}
            _set("streets",88,f"Streets skipped: {e}")

        # ── 7. GENERATE MODIS PRO FIGURES (88-96%) ───────────────────
        _set("stats",90,"Generating MODIS analysis figures…")
        from visualizer import (fig_modis_flood_map, fig_modis_depth_map,
                                fig_modis_road_impact, fig_modis_summary,
                                fig_urban_water_height, fig_street_severity,
                                fig_precipitation)
        roi_km2=STATE["roi_km2"]
        flood_km2=round(roi_km2*cm.mean(),4) if cm.sum()>0 else 0
        fig_modis_flood_map(cm, dem, bbox, flood_km2, roi_km2, modis_stats.get("date",""))
        R["depth_preview"]=_arr_to_png64(depth,"Blues",0,MAX_WATER_DEPTH_M) if cm.sum()>0 else ""
        fig_modis_depth_map(depth, cm, dem, bbox, depth_stats)
        fig_urban_water_height(depth, dem, bbox, depth_stats, roi_km2)
        if streets_gdf is not None:
            fig_modis_road_impact(streets_gdf, cm, dem, bbox, R.get("streets",{}))
            fig_street_severity(streets_gdf, cm, dem, bbox, R.get("streets",{}), depth)

        # ── 8. STATS & EXPORT (96-100%) ──────────────────────────────
        _set("stats",96,"Building statistics…")
        from exporter import save_csv
        stats={"roi_km2":roi_km2,"mode":"modis","modis":modis_stats,
               "methods":{"modis":{"flood_pixels":int(cm.sum()),
                    "pct_flooded":round(100*cm.mean(),3),
                    "flooded_km2":flood_km2}},
               "precipitation":{"total_mm":analysis["total_mm"],
                    "peak_day_mm":analysis["peak_day_mm"]},
               "water_depth":depth_stats}
        if R.get("streets"): stats["streets"]=R["streets"]
        R["stats"]=stats
        save_csv(stats,os.path.join(OUTPUT_DIR,"flood_stats.csv"))
        fig_modis_summary(stats, modis_stats, analysis, depth_stats, R.get("streets"))

        # ── Advanced stats (WS-3) ──────────────────────────────────────
        from flood_stats import build_advanced_stats as _build_adv
        _conf_modis = np.full(cm.shape, 0.6, dtype=np.float32)   # MODIS: uniform 60% conf
        _conf_modis[cm == 0] = 0.0
        _depth_modis = depth if cm.sum() > 0 else np.zeros_like(depth, dtype=np.float32)
        # MODIS native resolution is 250 m; depth is resampled to match the flood mask.
        _modis_px_m = 250.0 if cm.shape[0] > 0 else 250.0
        R["advanced_stats"] = _build_adv(
            cm, _depth_modis, _conf_modis,
            precip_analysis=analysis,
            streets_summary=R.get("streets", {}),
            roi_km2=roi_km2, pixel_m=_modis_px_m,
            sensor="modis",
            regime=analysis.get("regime", "uncalibrated"),
        )
        _set("done",100,"MODIS pipeline complete! All results ready.")

    except Exception as e:
        L.error(traceback.format_exc())
        STATE["error"]=str(e)
        _set("error",STATE["progress"],f"Error: {e}")

# ═════════════════════════════════════════════════════════════════════
#  SAR PIPELINE — full Sentinel-1 change detection
# ═════════════════════════════════════════════════════════════════════
# ═════════════════════════════════════════════════════════════════════
#  SIMULATION-ONLY PIPELINE — no SAR required (DEM + precipitation only)
# ═════════════════════════════════════════════════════════════════════
def _run_simulation_pipeline(bbox, params, settings):
    """Runs precip download + DEM download + HEC-HMS-style depth
    simulation only. Fully standalone — does NOT use Sentinel-1, SAR date
    fields or any backscatter. Drives everything from the user-chosen
    simulation_date + simulation_lookback_days.
    """
    try:
        import config
        for k,v in settings.items():
            if   k=="resolution":           config.RESOLUTION_M=int(v)
            elif k=="curve_number":         config.CURVE_NUMBER=float(v)
            elif k=="manning_n":            config.MANNING_N=float(v)
            elif k=="storm_duration_h":     config.STORM_DURATION_H=float(v)

        # Simulation-only anchor date (NOT the SAR after_end).
        import datetime as _dt
        sim_date = settings.get("simulation_date") or _dt.date.today().isoformat()
        sim_lb   = int(settings.get("simulation_lookback_days") or 3)
        L.info(f"[SIM] standalone run · date={sim_date} · lookback={sim_lb} d")

        STATE["bbox"]=bbox
        STATE["params"]={"simulation_date": sim_date,
                         "simulation_lookback_days": sim_lb,
                         "mode":"simulate"}
        STATE["roi_km2"]=_roi_km2(bbox); STATE["error"]=None
        R=STATE["results"]
        R["mode"]="simulate"
        # Cache key: bbox + sim_date + lookback (NOT the SAR dates)
        sim_params={"before_start":"sim","before_end":"sim",
                    "after_start":sim_date, "after_end":sim_date+f"+{sim_lb}d"}
        ck=_cache_key(bbox, sim_params)

        # ── 1. Precipitation  (independent: uses simulation_date only) ─
        _set("precip",5,f"Downloading ERA5 rainfall ending {sim_date} "
                         f"({sim_lb}-day lookback)…")
        from precipitation import download_precipitation_era5, analyse_precipitation
        cached_p=_cache_load(ck,"precip")
        if cached_p is not None:
            precip_data=cached_p
        else:
            precip_data=download_precipitation_era5(bbox, sim_date,
                                                     lookback_days=sim_lb)
            _cache_save(ck,"precip",precip_data)
        analysis=analyse_precipitation(precip_data)
        R["precip"]=analysis
        _set("precip",15,f"Rainfall {analysis['total_mm']:.0f} mm "
                          f"({sim_lb} d up to {sim_date}), peak {analysis['peak_day_mm']:.0f} mm")

        # ── 2. DEM ────────────────────────────────────────────────
        _set("auxiliary",20,"Downloading Copernicus DEM 30 m…")
        from downloader import download_dem
        from sentinelhub import bbox_to_dimensions
        target_size=bbox_to_dimensions(bbox, resolution=config.RESOLUTION_M)
        cached_aux=_cache_load(ck,"aux")
        if cached_aux is not None and "dem" in cached_aux:
            dem=cached_aux["dem"]
        else:
            dem=download_dem(bbox, (target_size[1], target_size[0]))
            _cache_save(ck,"aux",{"dem":dem})
        STATE["dem"]=dem
        _set("auxiliary",35,f"DEM ready: {dem.shape[1]}×{dem.shape[0]} px · elev {float(dem.min()):.0f}-{float(dem.max()):.0f} m")

        # ── 3. Hydrologic simulation ─────────────────────────────
        _set("depth",45,f"Simulating HEC-HMS depth "
                         f"(CN={config.CURVE_NUMBER}, n={config.MANNING_N}, "
                         f"storm={config.STORM_DURATION_H} h)…")
        from detection import pixel_size_m
        from hydrology import depth_simulated_from_precip
        px_m=pixel_size_m(bbox, dem.shape[:2])
        mask, depth, depth_stats = depth_simulated_from_precip(
            dem,
            precip_total_mm=float(analysis["total_mm"]),
            curve_number=config.CURVE_NUMBER,
            manning_n=config.MANNING_N,
            storm_duration_h=config.STORM_DURATION_H,
            pixel_m=px_m, max_depth=config.MAX_WATER_DEPTH_M)
        # Global ocean guard — strip any sim spill at/below sea level
        # (and inside OSM coastline/water polygons).
        mask, depth, ocean_m = _apply_ocean_mask(mask, depth, bbox, dem)
        STATE["ocean_mask"]=ocean_m
        # Recompute flooded km² so the stats match the masked output.
        try:
            depth_stats["flooded_km2"] = round(STATE["roi_km2"] * float(mask.mean()), 4)
        except Exception:
            pass
        STATE["water_depth"]=depth
        STATE["cleaned_masks"]["simulation"]=mask
        STATE["depth_stats"]=depth_stats
        R["depth"]=depth_stats

        # ── 4. Vector outputs (flood_sim.* prefix — NEVER overwrites
        #      the SAR-mode flood_threshold.* files) ────────────────
        _set("postprocess",75,"Vectorising simulated flood mask…")
        from exporter import save_mask, save_float, save_flood_shapefile
        save_mask(mask,  bbox, os.path.join(OUTPUT_DIR,"flood_sim.tif"))
        save_float(depth, bbox, os.path.join(OUTPUT_DIR,"flood_sim_depth.tif"))
        save_flood_shapefile(mask, bbox,
                             os.path.join(OUTPUT_DIR,"flood_sim.shp"),
                             method_name="simulation", depth=depth)
        R["flood_geojson"]=_mask_to_geojson(mask, bbox)
        R["depth_geojson"]=_depth_to_geojson(depth, bbox, mask)
        R["depth_preview"]=_arr_to_png64(depth,"Blues",0,config.MAX_WATER_DEPTH_M)
        # NF-05 — null-hypothesis honesty flag the UI keys off.
        R["no_flood_detected"] = bool(int(mask.sum()) == 0)

        flooded_d=depth[depth>0.01]
        if flooded_d.size>0:
            hist,edges=np.histogram(flooded_d, bins=30,
                range=(0.0, float(max(0.05, np.percentile(flooded_d, 99)))))
            R["depth_histogram"]={"counts":hist.tolist(),"edges":edges.tolist()}
        # Expose the hydrology card directly as "detection" so the same
        # UI renders without changes.
        R["detection"]={"simulation":{"flood_pixels": int(mask.sum()),
            "pct": round(100*mask.mean(),3),
            "km2": round(STATE["roi_km2"]*mask.mean(),4),
            "info": {"method": depth_stats["source"]}}}

        # ── Advanced stats (WS-3) ──────────────────────────────────────
        from flood_stats import build_advanced_stats as _build_adv
        _roi = STATE["roi_km2"]
        _conf_sim = np.full(mask.shape, 0.7, dtype=np.float32)   # simulate: no sensor, 70% base
        _conf_sim[mask == 0] = 0.0
        R["advanced_stats"] = _build_adv(
            mask, depth.astype(np.float32) if mask.sum() > 0 else np.zeros_like(depth, dtype=np.float32),
            _conf_sim, precip_analysis=analysis,
            streets_summary=R.get("streets", {}),
            roi_km2=_roi, pixel_m=px_m,
            sensor="simulate",
            regime=analysis.get("regime", "uncalibrated"),
        )

        _set("stats",95,f"Simulation done: {depth_stats['flooded_km2']:.2f} km², "
                        f"max {depth_stats['max_depth_m']:.2f} m, "
                        f"Q={depth_stats['runoff_Q_mm']:.1f} mm")
        _set("done",100,"Simulation complete.")
    except Exception as e:
        L.error(traceback.format_exc())
        STATE["error"]=str(e); _set("error",STATE["progress"], f"ERROR: {e}")


# ═════════════════════════════════════════════════════════════════════
#  S2 OPTICAL PIPELINE — mirrors _run_pipeline stage-by-stage
#  Sentinel-2 multi-index (NDWI/MNDWI/AWEIsh) flood detection.
#  Tags R["mode"]="s2" so the UI renders the correct sensor badge.
# ═════════════════════════════════════════════════════════════════════
def _run_s2_pipeline(bbox, params, settings):
    try:
        import config
        for k, v in settings.items():
            if   k == "resolution":    config.RESOLUTION_M    = int(v)
            elif k == "max_slope_deg": config.MAX_FLOOD_SLOPE_DEG = float(v)
            elif k == "min_area_m2":   config.MIN_FLOOD_AREA_M2  = float(v)
            elif k == "curve_number":  config.CURVE_NUMBER        = float(v)
            elif k == "manning_n":     config.MANNING_N           = float(v)
            elif k == "storm_duration_h": config.STORM_DURATION_H = float(v)

        STATE["bbox"] = bbox; STATE["params"] = params
        STATE["roi_km2"] = _roi_km2(bbox); STATE["error"] = None
        R = STATE["results"]
        R["mode"] = "s2"
        ck = _cache_key(bbox, params)
        L.info(f"[S2] Cache key: {ck}")

        # ── Stage 1 (0-10%): PRECIPITATION ───────────────────────────
        _set("precip", 2, "Fetching precipitation data from Open-Meteo ERA5…")
        from downloader import download_precipitation_era5
        from precipitation import analyse_precipitation, precipitation_risk_score
        date_end = params.get("after_end", params.get("after_start"))
        analysis = _cache_load(ck, "precip")
        if analysis is None:
            precip_data = download_precipitation_era5(bbox, date_end, lookback_days=21)
            analysis = analyse_precipitation(precip_data)
            analysis["risk_score"] = precipitation_risk_score(analysis)
            _cache_save(ck, "precip", analysis)
        else:
            _set("precip", 5, "Precipitation loaded from cache")
        STATE["precip_analysis"] = analysis
        R["precip"] = analysis
        _set("precip", 8, "Generating precipitation figures…")
        from visualizer import fig_precipitation
        fig_precipitation(analysis)
        _set("precip", 10,
             f"Precipitation done: {analysis['total_mm']:.0f}mm total, "
             f"peak {analysis['peak_day_mm']:.0f}mm, risk {analysis['risk_score']}/100")

        # ── Stage 2 (10-35%): S2 DOWNLOAD pre + post event ───────────
        from downloader import download_s2_flood
        cached_s2 = _cache_load(ck, "s2_bands")
        if cached_s2 is not None:
            _set("s2_download", 12, "Loading S2 bands from cache…")
            pre_arr = cached_s2["pre"]; post_arr = cached_s2["post"]
            _set("s2_download", 32, "S2 bands loaded from cache")
        else:
            _set("s2_download", 12, "Downloading Sentinel-2 pre-event image (B02/03/04/08/11/12+SCL)…")
            pre_arr  = download_s2_flood(bbox, params["before_start"], params["before_end"],
                                         resolution=10.0)
            _set("s2_download", 22, "S2 pre-event done. Downloading post-event image…")
            post_arr = download_s2_flood(bbox, params["after_start"],  params["after_end"],
                                         resolution=10.0)
            _set("s2_download", 30, "S2 bands downloaded. Saving to cache…")
            _cache_save(ck, "s2_bands", {"pre": pre_arr, "post": post_arr})

        # Split bands: first 6 = B02-B12, last = SCL
        pre_bands  = pre_arr[:, :, :6].astype(np.float32)
        pre_scl    = pre_arr[:, :,  6].astype(np.uint8)
        post_bands = post_arr[:, :, :6].astype(np.float32)
        post_scl   = post_arr[:, :,  6].astype(np.uint8)
        target = post_bands.shape[:2]   # (H, W)
        _set("s2_download", 35,
             f"S2 complete: {target[1]}×{target[0]} px @ 10 m")

        # S2 preview (RGB = B04/B03/B02)
        def _s2_rgb_preview(bands_arr):
            rgb = bands_arr[:, :, [2, 1, 0]]  # B04, B03, B02
            rgb = np.clip(rgb / 3000.0, 0.0, 1.0)  # stretch DN for display
            import matplotlib; matplotlib.use("Agg")
            import matplotlib.pyplot as plt, io as _io, base64 as _b64
            fig, ax = plt.subplots(1, 1, figsize=(6, 5))
            ax.imshow(rgb); ax.axis("off")
            buf = _io.BytesIO()
            fig.savefig(buf, format="png", dpi=80, bbox_inches="tight",
                        facecolor="#080C14", pad_inches=0.02)
            plt.close(fig); buf.seek(0)
            return _b64.b64encode(buf.read()).decode()

        R["s2"] = {
            "pre_preview":  _s2_rgb_preview(pre_arr),
            "post_preview": _s2_rgb_preview(post_arr),
            "shape": list(pre_arr.shape),
        }

        # ── Stage 3 (35-48%): DEM + PERMANENT WATER MASK ─────────────
        from downloader import download_dem, download_water_mask
        cached_aux = _cache_load(ck, "aux")
        if cached_aux is not None:
            _set("auxiliary", 36, "Loading DEM & water mask from cache…")
            dem = cached_aux["dem"]; mask_w = cached_aux.get("water_mask")
            STATE["dem"] = dem; STATE["water_mask"] = mask_w
            _set("auxiliary", 48, f"Auxiliary loaded: elev {dem.min():.0f}–{dem.max():.0f}m")
        else:
            _set("auxiliary", 36, "Downloading Copernicus DEM 30m…")
            dem = download_dem(bbox, target); STATE["dem"] = dem
            _set("auxiliary", 42,
                 f"DEM done: {dem.min():.0f}–{dem.max():.0f}m. Downloading NDWI water mask…")
            mask_w = None
            try:
                mask_w, _ = download_water_mask(bbox, params["before_start"],
                                                params["before_end"], target)
                from scipy.ndimage import binary_dilation
                mask_w = binary_dilation(mask_w.astype(bool), iterations=3).astype(np.uint8)
                STATE["water_mask"] = mask_w
                _set("auxiliary", 48, f"NDWI water mask: {int(mask_w.sum())} px (+60m buffer)")
            except Exception as e:
                STATE["water_mask"] = None
                _set("auxiliary", 48, f"NDWI water mask skipped: {e}")
            _cache_save(ck, "aux", {"dem": dem, "water_mask": mask_w})
        R["dem"] = {
            "min": float(dem.min()), "max": float(dem.max()),
            "mean": float(dem.mean()),
            "preview": _arr_to_png64(dem, "terrain"),
        }

        # ── Stage 4 (48-62%): S2 FLOOD DETECTION ─────────────────────
        _set("detection", 50,
             f"Running S2 multi-index detector (NDWI+MNDWI+AWEIsh, "
             f"slope≤{config.MAX_FLOOD_SLOPE_DEG}°)…")
        from detection_s2 import detect_flood_s2
        px_m = 10.0   # S2 native 10 m
        det = detect_flood_s2(
            pre_bands, post_bands,
            pre_scl, post_scl,
            permanent_water=STATE.get("water_mask"),
            dem=STATE.get("dem"),
            pixel_m=px_m,
            max_slope_deg=config.MAX_FLOOD_SLOPE_DEG,
            min_area_m2=config.MIN_FLOOD_AREA_M2,
        )

        roi_km2 = STATE["roi_km2"]
        flood_pct = float(det["mask"].mean())
        R["s2_detection"] = {
            "thresholds":    det["info"]["thresholds"],
            "otsu_applied":  det["info"]["otsu_applied"],
            "bhattacharyya": det["info"]["bhattacharyya"],
            "cloud_fraction":det["info"]["cloud_fraction"],
            "stages":        det["info"]["stages"],
            "depth_m":       det["info"]["depth_m"],
            "confidence":    det["info"]["confidence"],
            "donut": {
                "flood_km2": round(roi_km2 * flood_pct, 4),
                "dry_km2":   round(roi_km2 * (1 - flood_pct), 4),
                "roi_km2":   round(roi_km2, 4),
                "flood_pct": round(100 * flood_pct, 3),
            },
            "method":        det["info"]["method"],
        }
        R["detection"] = {"s2": {
            "flood_pixels": int(det["mask"].sum()),
            "pct":  round(100 * flood_pct, 3),
            "km2":  round(roi_km2 * flood_pct, 4),
            "info": det["info"],
        }}

        # NDWI preview for the UI
        R["confidence_preview"] = _arr_to_png64(det["confidence"], "Blues", 0, 1)
        _set("detection", 62,
             f"S2 detection done: {100*flood_pct:.2f}% flooded "
             f"({det['info']['final_area_km2']:.3f} km²), "
             f"cloud={det['info']['cloud_fraction']:.1%}")

        # ── Stage 5 (62-72%): POST-PROCESS (ocean guard + vectorise) ──
        _set("postprocess", 64, "Vectorising S2 flood mask…")
        # Reuse the SAR finalisation helper: it applies clean_mask + ocean
        # guard + writes files + stamps R["no_flood_detected"].
        cm, ocean_m, info_pp, post_results = _finalise_sar_results(
            R, det, bbox,
            dem=STATE.get("dem"),
            water_mask=STATE.get("water_mask"),
            roi_km2=roi_km2,
            write_files=True,
        )
        STATE["ocean_mask"] = ocean_m
        STATE["cleaned_masks"]["s2"] = cm
        cp = post_results["threshold"]
        _set("postprocess", 72,
             f"Post-process done: {cp['km2']:.3f} km² in {cp['polygons']} polygons")

        # ── Stage 6 (72-84%): WATER DEPTH (HEC-HMS with S2 mask) ─────
        _set("depth", 74,
             f"HEC-HMS depth: SCS-CN (CN={config.CURVE_NUMBER}) + D8 + "
             f"Manning (n={config.MANNING_N}) + FwDET (S2 mask)…")
        ens_mask = STATE["cleaned_masks"]["s2"]
        precip_total = float(R["precip"].get("total_mm", 0.0))
        # NRCS NEH-4 §2.1: AMC-II is the standard design condition when
        # pre-event antecedent cannot be cleanly isolated from the analysis
        # window (api[-1] is post-storm accumulated, not pre-storm).
        # Override via env var FLOOD_AMC_DEFAULT=I|II|III.
        import os as _os
        _amc_default = _os.environ.get("FLOOD_AMC_DEFAULT", "II")
        if _amc_default not in ("I", "II", "III"):
            _amc_default = "II"  # guard against invalid env-var values
        from hydrology import depth_from_precip_dem
        depth, depth_stats = depth_from_precip_dem(
            ens_mask, dem, precip_total_mm=precip_total,
            curve_number=config.CURVE_NUMBER,
            amc=_amc_default,         # NEH-4 §2.1 standard condition (default II)
            antecedent_api=0.0,       # unused when amc is explicit
            detected_mask=ens_mask,   # WS-4: zero depth outside S2 mask
            manning_n=config.MANNING_N,
            storm_duration_h=config.STORM_DURATION_H,
            pixel_m=px_m, max_depth=config.MAX_WATER_DEPTH_M,
        )
        # Surface AMC diagnostics in R["depth"] (appended below)
        # Ocean guard on depth raster
        if STATE.get("ocean_mask") is not None:
            depth[STATE["ocean_mask"] > 0] = 0.0
        STATE["water_depth"] = depth; STATE["depth_stats"] = depth_stats
        # ── Back-fill s2_detection["depth_m"] with real HEC-HMS values ──
        # detect_flood_s2 returns placeholder zeros (comment: "filled by WS-4
        # hydrology coupling").  Now that depth_from_precip_dem has run,
        # we compute the per-pixel stats over the flooded mask and write
        # them back so R["s2_detection"]["depth_m"] agrees with
        # R["advanced_stats"]["depth_m"].  Only positive depths are
        # included (same convention as build_advanced_stats).
        _flood_bool_s2 = ens_mask.astype(bool)
        _pos_depths_s2 = depth[_flood_bool_s2]
        _pos_depths_s2 = _pos_depths_s2[_pos_depths_s2 > 0]
        if _pos_depths_s2.size > 0:
            R["s2_detection"]["depth_m"] = {
                "mean":   round(float(_pos_depths_s2.mean()), 4),
                "median": round(float(np.median(_pos_depths_s2)), 4),
                "p90":    round(float(np.percentile(_pos_depths_s2, 90)), 4),
                "max":    round(float(_pos_depths_s2.max()), 4),
            }
        # else: leave the placeholder zeros (no flood pixels with depth > 0)
        from exporter import save_float as _save_float
        _save_float(depth, bbox, os.path.join(OUTPUT_DIR, "flood_s2_depth.tif"))
        R["depth"] = depth_stats
        R["depth_preview"] = _arr_to_png64(depth, "Blues", 0, MAX_WATER_DEPTH_M)
        R["depth_geojson"] = _depth_to_geojson(depth, bbox, ens_mask)
        flooded_d = depth[depth > 0.02]
        if flooded_d.size > 0:
            hist, edges = np.histogram(flooded_d, bins=30,
                range=(0.0, float(max(0.05, np.percentile(flooded_d, 99)))))
            R["depth_histogram"] = {"counts": hist.tolist(), "edges": edges.tolist()}
        _set("depth", 82,
             f"HEC-HMS (S2): P={depth_stats['precip_total_mm']:.1f}mm  "
             f"CN={depth_stats['curve_number']}  "
             f"→ Q={depth_stats['runoff_Q_mm']:.1f}mm · "
             f"V_runoff={depth_stats['runoff_volume_m3']:.0f}m³ · "
             f"max={depth_stats['max_depth_m']:.2f}m")

        # ── Stage 7 (82-90%): STREETS ─────────────────────────────────
        _set("streets", 83, "Downloading OpenStreetMap road network…")
        from streets import download_osm_streets, compute_street_water_depth, flooded_streets_summary
        streets_gdf = None
        try:
            streets = download_osm_streets(bbox)
            if streets is not None and len(streets) > 0:
                _set("streets", 86,
                     f"Got {len(streets)} roads. Computing street-level water heights…")
                streets_gdf = compute_street_water_depth(streets, depth, bbox)
                STATE["streets_gdf"] = streets_gdf
                R["streets"] = flooded_streets_summary(streets_gdf)
                R["streets_geojson"] = _streets_to_geojson(streets_gdf)
                R["streets_3d_geojson"] = _streets_to_buffered_geojson(streets_gdf)
                _set("streets", 90,
                     f"Roads: {R['streets']['flooded_km']:.1f} km flooded / "
                     f"{R['streets']['total_km']:.1f} km total")
            else:
                R["streets"] = {"total_km": 0, "flooded_km": 0}
                R["streets_geojson"] = {"type": "FeatureCollection", "features": []}
                _set("streets", 90, "No road data")
        except Exception as e:
            L.warning(f"Streets (S2) failed: {e}")
            R["streets"] = {"total_km": 0, "flooded_km": 0, "error": str(e)}
            R["streets_geojson"] = {"type": "FeatureCollection", "features": []}
            _set("streets", 90, f"Streets skipped: {e}")

        # ── Stage 8 (90-100%): STATS + FIGURES ────────────────────────
        _set("stats", 92, "Generating analysis figures (S2)…")
        from visualizer import (fig_modis_flood_map, fig_modis_depth_map,
                                 fig_modis_road_impact, fig_modis_summary,
                                 fig_urban_water_height, fig_street_severity,
                                 fig_precipitation, fig_statistics)
        flood_km2 = round(roi_km2 * ens_mask.mean(), 4)
        fig_precipitation(analysis)
        fig_modis_flood_map(ens_mask, dem, bbox, flood_km2, roi_km2,
                            params.get("after_end", ""))
        fig_modis_depth_map(depth, ens_mask, dem, bbox, depth_stats)
        fig_urban_water_height(depth, dem, bbox, depth_stats, roi_km2)
        if streets_gdf is not None:
            fig_modis_road_impact(streets_gdf, ens_mask, dem, bbox,
                                  R.get("streets", {}))
            fig_street_severity(streets_gdf, ens_mask, dem, bbox,
                                R.get("streets", {}), depth)

        _set("stats", 96, "Building statistics (S2)…")
        from exporter import build_stats, save_csv
        # build_stats expects a detections dict keyed like _run_pipeline
        s2_det_compat = {"threshold": det}  # reuse existing stats builder contract
        stats = build_stats(s2_det_compat, roi_km2, analysis, depth_stats,
                            R.get("streets"))
        stats["precip_risk_score"] = analysis.get("risk_score", 0)
        stats["simulation"] = depth_stats.get("simulation", "")
        stats["sensor"] = "s2"
        if "depth_histogram" in R:
            stats["depth_histogram"] = R["depth_histogram"]
        R["stats"] = stats
        save_csv(stats, os.path.join(OUTPUT_DIR, "flood_s2_stats.csv"))
        fig_statistics(stats)
        fig_modis_summary(
            stats,
            {"date": params.get("after_end", ""),
             "flood_pixels": int(ens_mask.sum()),
             "flood_pct": round(100 * ens_mask.mean(), 3),
             "source": "Sentinel-2 optical (NDWI+MNDWI+AWEIsh)"},
            analysis, depth_stats, R.get("streets"),
        )

        # ── Advanced stats (WS-3) + surface AMC/CN keys (WS-4) ─────────
        from flood_stats import build_advanced_stats as _build_adv
        _conf_s2 = det.get("confidence", np.zeros(ens_mask.shape, dtype=np.float32))
        R["advanced_stats"] = _build_adv(
            ens_mask, depth.astype(np.float32), _conf_s2.astype(np.float32),
            precip_analysis=analysis,
            streets_summary=R.get("streets", {}),
            roi_km2=roi_km2, pixel_m=px_m,
            sensor="s2",
            regime=analysis.get("regime", "uncalibrated"),
            cloud_or_nodata_frac=float(det["info"].get("cloud_fraction", 0.0)),
        )
        # Surface WS-4 AMC keys alongside depth stats for UI transparency
        R["depth"]["amc_used"]    = depth_stats.get("amc_used", "II")
        R["depth"]["CN_adjusted"] = depth_stats.get("CN_adjusted", config.CURVE_NUMBER)
        R["depth"]["volume_ratio"]= depth_stats.get("volume_ratio", 1.0)

        _set("done", 100, "S2 pipeline complete! All results ready.")

    except Exception as e:
        L.error(traceback.format_exc())
        STATE["error"] = str(e)
        _set("error", STATE["progress"], f"S2 Error: {e}")


def _run_pipeline(bbox, params, settings):
    try:
        import config
        for k,v in settings.items():
            if   k=="resolution":           config.RESOLUTION_M=int(v)
            elif k=="threshold_db":         config.THRESHOLD_DB=float(v)
            elif k=="depth_scale_m_per_db": config.DEPTH_SCALE_M_PER_DB=float(v)
            elif k=="max_slope_deg":        config.MAX_FLOOD_SLOPE_DEG=float(v)
            elif k=="min_area_m2":          config.MIN_FLOOD_AREA_M2=float(v)
            elif k=="auto_threshold":       config.AUTO_THRESHOLD=bool(v)
            elif k=="seed_offset_db":       config.SEED_OFFSET_DB=float(v)
            elif k=="curve_number":         config.CURVE_NUMBER=float(v)
            elif k=="manning_n":            config.MANNING_N=float(v)
            elif k=="storm_duration_h":     config.STORM_DURATION_H=float(v)

        STATE["bbox"]=bbox; STATE["params"]=params
        STATE["roi_km2"]=_roi_km2(bbox); STATE["error"]=None
        R=STATE["results"]
        ck=_cache_key(bbox,params)
        L.info(f"Cache key: {ck}")

        # ── 1. PRECIPITATION FIRST (0-10%) — instant from Open-Meteo ─
        _set("precip",2,"Fetching precipitation data from Open-Meteo ERA5…")
        from downloader import download_precipitation_era5
        from precipitation import analyse_precipitation, precipitation_risk_score
        date_end=params.get("after_end",params.get("after_start"))
        analysis=_cache_load(ck,"precip")
        if analysis is None:
            precip_data=download_precipitation_era5(bbox, date_end, lookback_days=21)
            analysis=analyse_precipitation(precip_data)
            analysis["risk_score"]=precipitation_risk_score(analysis)
            _cache_save(ck,"precip",analysis)
        else:
            _set("precip",5,"Precipitation loaded from cache")
        STATE["precip_analysis"]=analysis
        R["precip"]=analysis
        _set("precip",8,"Generating precipitation figures…")
        from visualizer import fig_precipitation
        fig_precipitation(analysis)
        _set("precip",10,f"Precipitation done: {analysis['total_mm']:.0f}mm total, peak {analysis['peak_day_mm']:.0f}mm, risk {analysis['risk_score']}/100")

        # ── 2. DOWNLOAD SAR (10-35%) ─────────────────────────────────
        from downloader import download_s1, search_s1_dates
        # Query the Sentinel-1 catalog for *actual* acquisition dates in
        # each window — so the UI can show the user which pass we used
        # (not just the window boundaries) + days-after-flood context.
        try:
            before_passes = search_s1_dates(bbox, params["before_start"],
                                            params["before_end"])
            after_passes  = search_s1_dates(bbox, params["after_start"],
                                            params["after_end"])
            # Pre-event: we want the pass closest to the event (= latest).
            # Post-event: the earliest useful pass after the storm.
            before_date = before_passes[-1] if before_passes else None
            after_date  = after_passes[0]  if after_passes  else None
            R["acquisition"]=_build_acquisition_card(
                before_date, after_date, before_passes, after_passes, bbox)
        except Exception as _e:
            L.warning(f"Catalog search failed — falling back to window dates: {_e}")

        cached_sar=_cache_load(ck,"sar")
        if cached_sar is not None:
            _set("sar",12,"Loading SAR from cache…")
            before,after=cached_sar["before"],cached_sar["after"]
            _set("sar",32,"SAR loaded from cache")
        else:
            _set("sar",12,"Downloading Sentinel-1 SAR before-event image…")
            before=download_s1(bbox, params["before_start"], params["before_end"])
            _set("sar",22,"SAR before done. Downloading after-event image…")
            after=download_s1(bbox, params["after_start"], params["after_end"])
            _set("sar",30,"SAR downloaded. Saving to cache…")
            _cache_save(ck,"sar",{"before":before,"after":after})
        STATE["before_sar"]=before; STATE["after_sar"]=after
        _set("sar",32,"Computing SAR previews…")

        from detection import to_db, lee_filter
        bvv=to_db(lee_filter(before[:,:,0])); avv=to_db(lee_filter(after[:,:,0]))
        R["sar"]={
            "before_preview":_arr_to_png64(bvv,"gray"),
            "after_preview":_arr_to_png64(avv,"gray"),
            "change_preview":_arr_to_png64(avv-bvv,"RdBu_r",-8,8),
            "shape":list(before.shape),
        }

        # Georeferenced raster overlays for Mapbox (bbox-anchored RGBA PNGs).
        # Use stable dB limits so successive runs are comparable.
        _arr_to_geo_png(bvv, os.path.join(OUTPUT_DIR,"sar_before_geo.png"),
                        cmap="gray", vmin=-25, vmax=-5)
        _arr_to_geo_png(avv, os.path.join(OUTPUT_DIR,"sar_after_geo.png"),
                        cmap="gray", vmin=-25, vmax=-5)
        _arr_to_geo_png(avv-bvv, os.path.join(OUTPUT_DIR,"sar_change_geo.png"),
                        cmap="RdBu_r", vmin=-6, vmax=6)
        R["sar_rasters"]={
            "bbox":[bbox.min_x,bbox.min_y,bbox.max_x,bbox.max_y],
            "urls":{
                "before":"/api/figures/sar_before_geo.png",
                "after": "/api/figures/sar_after_geo.png",
                "change":"/api/figures/sar_change_geo.png",
            },
            "db_range":[-25,-5], "change_range":[-6,6],
        }
        from exporter import save_sar
        save_sar(before[:,:,0],before[:,:,1],bbox,os.path.join(OUTPUT_DIR,"sar_before.tif"))
        save_sar(after[:,:,0],after[:,:,1],bbox,os.path.join(OUTPUT_DIR,"sar_after.tif"))
        _set("sar",35,f"SAR complete: {before.shape[1]}x{before.shape[0]} px")

        # ── 3. AUXILIARY (35-48%) ────────────────────────────────────
        from downloader import download_dem, download_water_mask
        target=before.shape[:2]
        cached_aux=_cache_load(ck,"aux")
        if cached_aux is not None:
            _set("auxiliary",36,"Loading DEM & water mask from cache…")
            dem=cached_aux["dem"]; mask_w=cached_aux.get("water_mask")
            STATE["dem"]=dem; STATE["water_mask"]=mask_w
            _set("auxiliary",48,f"Auxiliary loaded from cache: elev {dem.min():.0f}–{dem.max():.0f}m")
        else:
            _set("auxiliary",36,"Downloading Copernicus DEM 30m…")
            dem=download_dem(bbox,target); STATE["dem"]=dem
            _set("auxiliary",42,f"DEM done: elev {dem.min():.0f}–{dem.max():.0f}m. Downloading NDWI water mask…")
            mask_w=None
            try:
                mask_w,_=download_water_mask(bbox,params["before_start"],params["before_end"],target)
                # Dilate by ~60 m (3 px at 20 m) to swallow the coastline
                # speckle ring where change detection tends to leak.
                from scipy.ndimage import binary_dilation
                mask_w=binary_dilation(mask_w.astype(bool), iterations=3).astype(np.uint8)
                STATE["water_mask"]=mask_w
                _set("auxiliary",48,f"NDWI water mask: {int(mask_w.sum())} px (+60m coastline buffer)")
            except Exception as e:
                STATE["water_mask"]=None
                _set("auxiliary",48,f"NDWI water mask skipped: {e}")
            _cache_save(ck,"aux",{"dem":dem,"water_mask":mask_w})
        R["dem"]={"min":float(dem.min()),"max":float(dem.max()),"mean":float(dem.mean()),
                  "preview":_arr_to_png64(dem,"terrain")}

        # ── 4. FLOOD DETECTION (48-62%) ──────────────────────────────
        _set("detection",50,
             f"Running ΔSAR detector (T={config.THRESHOLD_DB} dB, "
             f"slope≤{config.MAX_FLOOD_SLOPE_DEG}°, "
             f"depth-scale={config.DEPTH_SCALE_M_PER_DB} m/dB)…")
        from detection import detect_flood, pixel_size_m
        px_m=pixel_size_m(bbox, before.shape[:2])
        L.info(f"True pixel size: {px_m:.2f} m  ·  "
               f"T={config.THRESHOLD_DB} dB  ·  "
               f"slope≤{config.MAX_FLOOD_SLOPE_DEG}°  ·  "
               f"min-area={config.MIN_FLOOD_AREA_M2} m²  ·  "
               f"depth_scale={config.DEPTH_SCALE_M_PER_DB} m/dB")
        # IMPORTANT: pass the LIVE config values explicitly. `detection.py`
        # binds its defaults at module-load time (`from config import …`),
        # so mutating `config.THRESHOLD_DB` from the UI route does NOT
        # change detect_flood's default — we have to pass them through.
        # Regime defaults to None (UAE legacy / byte-equal regression);
        # only resolved when env knob enables AUTO or OVERRIDE is set.
        from precipitation import _detect_regime_for_bbox
        _det_regime = _detect_regime_for_bbox(bbox) \
            if (os.environ.get("FLOOD_DETECTION_REGIME_AUTO","0").strip()=="1"
                or os.environ.get("FLOOD_DETECTION_REGIME_OVERRIDE","").strip()) \
            else None
        det=detect_flood(before, after,
                         permanent_water=STATE.get("water_mask"),
                         dem=STATE.get("dem"),
                         pixel_m=px_m,
                         threshold_db=config.THRESHOLD_DB,
                         max_slope_deg=config.MAX_FLOOD_SLOPE_DEG,
                         min_area_m2=config.MIN_FLOOD_AREA_M2,
                         depth_scale_m_per_db=config.DEPTH_SCALE_M_PER_DB,
                         max_depth_m=config.MAX_WATER_DEPTH_M,
                         auto_threshold=config.AUTO_THRESHOLD,
                         seed_offset_db=config.SEED_OFFSET_DB,
                         regime=_det_regime)
        # Single-method results — keep the dict shape so downstream code
        # that iterates `detections.items()` keeps working.
        detections={"threshold": det}
        STATE["detections"]=detections

        m=det["mask"]
        roi_km2=STATE["roi_km2"]
        flood_pct=float(m.mean())
        method_stats={"threshold":{
            "flood_pixels": int(m.sum()),
            "pct": round(100*flood_pct,3),
            "km2": round(roi_km2*flood_pct,4),
            "info": det["info"],
        }}
        # Validation against known UAE flood events (Copernicus EMS, NCM)
        try:
            R["validation"]=_validation_card(bbox, params,
                round(roi_km2*flood_pct, 4))
        except Exception as _e:
            L.warning(f"Validation card skipped: {_e}")
        # Compact card the UI charts can read directly without re-parsing
        # the nested `info` blob.
        R["sar_detection"]={
            "threshold_db_used": det["info"]["threshold_db_used"],
            "seed_threshold_db_used": det["info"]["seed_threshold_db_used"],
            "auto":  det["info"]["auto_threshold"],
            "stages":det["info"]["stages"],
            "depth_m":    det["info"]["depth_m"],
            "confidence": det["info"]["confidence"],
            "change_db_in_flood": det["info"]["change_db_in_flood"],
            "histograms": det["info"]["histograms"],
            "donut": {"flood_km2": round(roi_km2*flood_pct,4),
                       "dry_km2":  round(roi_km2*(1-flood_pct),4),
                       "roi_km2":  round(roi_km2,4),
                       "flood_pct":round(100*flood_pct,3)},
            "polygons_target": "set after vectorisation",
        }
        R["detection"]=method_stats

        _set("detection",58,"Saving change raster & SAR figures…")
        from exporter import save_float
        save_float(det["change"], bbox, os.path.join(OUTPUT_DIR,"change_threshold.tif"))
        from visualizer import fig_sar_comparison
        fig_sar_comparison(before[:,:,0],after[:,:,0])
        thr_pct=method_stats["threshold"]["pct"]
        thr_km2=method_stats["threshold"]["km2"]
        _set("detection",62,f"Detection done: {thr_pct:.2f}% flooded ({thr_km2:.3f} km²)")

        # ── 5. POST-PROCESS (62-72%) ─────────────────────────────────
        # The threshold detector already does morphology, slope, water
        # exclusion, and min-area. _finalise_sar_results re-enforces the
        # permanent-water mask, applies the ocean guard, writes the
        # raster/shapefile, and stamps R["postprocess"]/flood_geojson/
        # no_flood_detected. Same code path is exercised by the null-
        # hypothesis harness (NF-05).
        _set("postprocess",64,"Vectorising flood mask to shapefile…")
        cm, ocean_m, info, post_results = _finalise_sar_results(
            R, det, bbox,
            dem=STATE.get("dem"),
            water_mask=STATE.get("water_mask"),
            roi_km2=STATE["roi_km2"],
            write_files=True,
        )
        STATE["ocean_mask"]=ocean_m
        STATE["cleaned_masks"]["threshold"]=cm
        cp=post_results["threshold"]
        _set("postprocess",72,f"Post-process done: {cp['km2']:.3f} km² in {cp['polygons']} polygons")

        # ── 6. WATER DEPTH — HEC-HMS-style hydrologic model (72-84%) ──
        # Precipitation + DEM drive the depth. The SAR mask sets the
        # spatial extent; SCS-CN gives runoff Q from rainfall, D8 routes
        # it on the depression-filled DEM, Manning's kinematic wave gives
        # depth on slopes, FwDET caps the depth in natural sinks, and
        # volume conservation enforces V_depth ≤ V_runoff.
        _set("depth",74,
             f"HEC-HMS depth: SCS-CN (CN={config.CURVE_NUMBER}) + D8 + "
             f"Manning (n={config.MANNING_N}) + FwDET sink-fill…")
        ens_mask=STATE["cleaned_masks"]["threshold"]
        precip_total=analysis.get("total_mm",0.0) if 'analysis' in dir() else 0.0
        try:
            precip_total=R["precip"].get("total_mm", precip_total) \
                if "precip" in R else precip_total
        except Exception:
            pass
        from hydrology import depth_from_precip_dem
        # NRCS NEH-4 §2.1: AMC-II is the standard design condition when
        # pre-event antecedent cannot be cleanly isolated from the analysis
        # window (api[-1] is post-storm accumulated, not pre-storm).
        # Override via env var FLOOD_AMC_DEFAULT=I|II|III.
        import os as _os
        _amc_default = _os.environ.get("FLOOD_AMC_DEFAULT", "II")
        if _amc_default not in ("I", "II", "III"):
            _amc_default = "II"  # guard against invalid env-var values
        depth, depth_stats = depth_from_precip_dem(
            ens_mask, dem, precip_total_mm=float(precip_total),
            curve_number=config.CURVE_NUMBER,
            amc=_amc_default,         # NEH-4 §2.1 standard condition (default II)
            antecedent_api=0.0,       # unused when amc is explicit
            detected_mask=ens_mask,   # WS-4: zero depth outside SAR mask
            manning_n=config.MANNING_N,
            storm_duration_h=config.STORM_DURATION_H,
            pixel_m=px_m, max_depth=config.MAX_WATER_DEPTH_M)
        # Final ocean guard on depth — even if the mask was clean, the
        # rainfall-runoff routing can spill 1-2 px past the coastline.
        if STATE.get("ocean_mask") is not None:
            depth[STATE["ocean_mask"]>0] = 0.0
        STATE["water_depth"]=depth; STATE["depth_stats"]=depth_stats
        # Save depth raster so /api/dl/depth.tif can stream it.
        from exporter import save_float as _save_float
        _save_float(depth, bbox, os.path.join(OUTPUT_DIR,
                                              "flood_threshold_depth.tif"))
        R["depth"]=depth_stats
        R["depth_preview"]=_arr_to_png64(depth,"Blues",0,MAX_WATER_DEPTH_M)
        R["depth_geojson"]=_depth_to_geojson(depth,bbox,ens_mask)
        flooded_d=depth[depth>0.02]
        if flooded_d.size>0:
            hist,edges=np.histogram(flooded_d, bins=30,
                range=(0.0, float(max(0.05, np.percentile(flooded_d, 99)))))
            R["depth_histogram"]={"counts":hist.tolist(),"edges":edges.tolist()}
        _set("depth",82,
             f"HEC-HMS: P={depth_stats['precip_total_mm']:.1f} mm  CN={depth_stats['curve_number']}  "
             f"→ Q={depth_stats['runoff_Q_mm']:.1f} mm · "
             f"V_runoff={depth_stats['runoff_volume_m3']:.0f} m³ · "
             f"max {depth_stats['max_depth_m']:.2f} m, "
             f"mean {depth_stats['mean_depth_m']:.2f} m  "
             f"({depth_stats['pond_pixels']:,} pond + "
             f"{depth_stats['kinematic_pixels']:,} kinematic)")

        # ── 7. STREETS (82-90%) ──────────────────────────────────────
        _set("streets",83,"Downloading OpenStreetMap road network…")
        from streets import download_osm_streets, compute_street_water_depth, flooded_streets_summary
        streets_gdf=None
        try:
            streets=download_osm_streets(bbox)
            if streets is not None and len(streets)>0:
                _set("streets",86,f"Got {len(streets)} roads. Computing street-level water heights…")
                streets_gdf=compute_street_water_depth(streets,depth,bbox)
                STATE["streets_gdf"]=streets_gdf
                R["streets"]=flooded_streets_summary(streets_gdf)
                R["streets_geojson"]=_streets_to_geojson(streets_gdf);R["streets_3d_geojson"]=_streets_to_buffered_geojson(streets_gdf)
                _set("streets",90,f"Roads: {R['streets']['flooded_km']:.1f} km flooded / {R['streets']['total_km']:.1f} km total")
            else:
                R["streets"]={"total_km":0,"flooded_km":0}
                R["streets_geojson"]={"type":"FeatureCollection","features":[]}
                _set("streets",90,"No road data")
        except Exception as e:
            L.warning(f"Streets failed: {e}")
            R["streets"]={"total_km":0,"flooded_km":0,"error":str(e)}
            R["streets_geojson"]={"type":"FeatureCollection","features":[]}
            _set("streets",90,f"Streets skipped: {e}")

        # ── 8. PRO FIGURES + STATS (90-100%) ─────────────────────────
        _set("stats",92,"Generating professional analysis figures…")
        from visualizer import (fig_sar_comparison,
                                fig_modis_flood_map, fig_modis_depth_map,
                                fig_modis_road_impact, fig_modis_summary,
                                fig_urban_water_height, fig_street_severity,
                                fig_precipitation, fig_statistics)
        roi_km2=STATE["roi_km2"]
        flood_km2=round(roi_km2*ens_mask.mean(),4)

        # SAR-specific figures
        fig_sar_comparison(before[:,:,0],after[:,:,0])
        fig_precipitation(analysis)

        # Pro geo-referenced figures
        fig_modis_flood_map(ens_mask, dem, bbox, flood_km2, roi_km2,
                            params.get("after_end",""))
        fig_modis_depth_map(depth, ens_mask, dem, bbox, depth_stats)
        fig_urban_water_height(depth, dem, bbox, depth_stats, roi_km2)
        if streets_gdf is not None:
            fig_modis_road_impact(streets_gdf, ens_mask, dem, bbox, R.get("streets",{}))
            fig_street_severity(streets_gdf, ens_mask, dem, bbox, R.get("streets",{}), depth)

        _set("stats",96,"Building statistics…")
        from exporter import build_stats, save_csv
        stats=build_stats(detections,roi_km2,analysis,depth_stats,R.get("streets"))
        stats["precip_risk_score"]=analysis.get("risk_score",0)
        stats["simulation"]=depth_stats.get("simulation","")
        if "depth_histogram" in R: stats["depth_histogram"]=R["depth_histogram"]
        R["stats"]=stats
        save_csv(stats,os.path.join(OUTPUT_DIR,"flood_stats.csv"))
        fig_statistics(stats)
        fig_modis_summary(stats, {"date":params.get("after_end",""),"flood_pixels":int(ens_mask.sum()),
                                   "flood_pct":round(100*ens_mask.mean(),3),"source":"Sentinel-1 SAR"},
                          analysis, depth_stats, R.get("streets"))

        # ── Advanced stats (WS-3) + surface AMC/CN keys (WS-4) ─────────
        from flood_stats import build_advanced_stats as _build_adv
        _conf_sar = det.get("confidence", np.zeros(ens_mask.shape, dtype=np.float32))
        R["advanced_stats"] = _build_adv(
            ens_mask, depth.astype(np.float32), _conf_sar.astype(np.float32),
            precip_analysis=analysis,
            streets_summary=R.get("streets", {}),
            roi_km2=roi_km2, pixel_m=px_m,
            sensor="s1",
            regime=analysis.get("regime", "uncalibrated"),
        )
        # Surface WS-4 AMC keys for UI transparency
        R["depth"]["amc_used"]    = depth_stats.get("amc_used", "II")
        R["depth"]["CN_adjusted"] = depth_stats.get("CN_adjusted", config.CURVE_NUMBER)
        R["depth"]["volume_ratio"]= depth_stats.get("volume_ratio", 1.0)

        _set("done",100,"Pipeline complete! All results ready.")

    except Exception as e:
        L.error(traceback.format_exc())
        STATE["error"]=str(e)
        _set("error",STATE["progress"],f"Error: {e}")

# ═════════════════════════════════════════════════════════════════════
#  ENDPOINTS
# ═════════════════════════════════════════════════════════════════════
@app.route("/")
def index(): return send_from_directory("static","index.html")

_BOOT_TS = dt.datetime.utcnow()
APP_VERSION = "3.1.0"

@app.route("/health")
def health():
    """Production healthcheck — Railway/Docker probes hit this."""
    up = (dt.datetime.utcnow() - _BOOT_TS).total_seconds()
    return jsonify({
        "status":   "ok",
        "version":  APP_VERSION,
        "uptime_s": round(up, 1),
        "phase":    STATE.get("phase", "idle"),
        "progress": STATE.get("progress", 0),
        "build":    "UAE FloodMap · ΔSAR Otsu detector + HEC-HMS depth",
    })

@app.route("/api/run", methods=["POST"])
def run_pipeline():
    if STATE["phase"] not in ("idle","done","error"):
        return jsonify({"ok":False,"error":"Pipeline already running"}),409
    try:
        data=request.json; roi=data.get("roi"); params=data.get("params",{}); settings=data.get("settings",{})
        from sentinelhub import BBox, CRS
        from shapely.geometry import shape as shp_shape
        if isinstance(roi,str): roi=json.loads(roi)
        geom=roi.get("geometry",roi)
        if geom.get("type")=="FeatureCollection": geom=geom["features"][0]["geometry"]
        elif geom.get("type")=="Feature": geom=geom["geometry"]
        s=shp_shape(geom); bbox=BBox(bbox=s.bounds,crs=CRS.WGS84)

        STATE.update({"phase":"starting","progress":0,"message":"Initializing…",
            "results":{},"error":None,"cleaned_masks":{},
            "before_sar":None,"after_sar":None,"detections":None,
            "water_depth":None,"streets_gdf":None})

        mode   = settings.get("mode",   "sar")   # sar | modis | simulate
        sensor = settings.get("sensor", "s1")    # s1  | s2   (only for mode != modis/simulate)

        if   mode == "modis":    target_fn = _run_modis_pipeline
        elif mode == "simulate": target_fn = _run_simulation_pipeline
        elif sensor == "s2":     target_fn = _run_s2_pipeline
        else:                    target_fn = _run_pipeline      # default: Sentinel-1 SAR
        t=threading.Thread(target=target_fn,args=(bbox,params,settings),daemon=True)
        t.start()

        from sentinelhub import bbox_to_dimensions
        import config
        size=bbox_to_dimensions(bbox,resolution=config.RESOLUTION_M)
        ck=_cache_key(bbox,params)
        has_cache=[t for t in ["precip","sar","aux"]
                   if _cache_exists(ck,t)]
        return jsonify({"ok":True,
            "bbox":[bbox.min_x,bbox.min_y,bbox.max_x,bbox.max_y],
            "roi_km2":round(_roi_km2(bbox),2),"grid":list(size),
            "cached":has_cache})
    except Exception as e:
        L.error(traceback.format_exc())
        return jsonify({"ok":False,"error":str(e)}),400

# Keys that are too large (base64 images, GeoJSON) to send every poll
_HEAVY_KEYS = {"flood_geojson","depth_geojson","streets_geojson",
               "streets_3d_geojson","confidence_preview","depth_preview"}

@app.route("/api/progress")
def progress():
    # Send lightweight results every poll; heavy data fetched once via /api/results/<key>
    lite = {k:v for k,v in STATE["results"].items() if k not in _HEAVY_KEYS}
    # Tell frontend which heavy keys are available
    lite["_ready"] = [k for k in _HEAVY_KEYS if k in STATE["results"]]
    # Strip base64 previews from nested dicts (sar, dem) — send via /api/results/<key>
    if "sar" in lite:
        lite["sar"] = {k:v for k,v in lite["sar"].items() if not k.endswith("_preview")}
        lite["sar"]["has_previews"] = True
    if "dem" in lite:
        lite["dem"] = {k:v for k,v in lite["dem"].items() if k != "preview"}
        lite["dem"]["has_preview"] = True
    return jsonify(_safe({
        "phase":STATE["phase"],"progress":STATE["progress"],
        "message":STATE["message"],"error":STATE.get("error"),
        "results":lite,"roi_km2":STATE.get("roi_km2",0)}))

@app.route("/api/results/<key>")
def get_result(key):
    """Fetch a single heavy result (GeoJSON, base64 image, full SAR previews)."""
    if key == "sar_previews":
        sar = STATE["results"].get("sar",{})
        return jsonify(_safe({k:v for k,v in sar.items() if k.endswith("_preview")}))
    if key == "dem_preview":
        return jsonify(_safe({"preview": STATE["results"].get("dem",{}).get("preview","")}))
    val = STATE["results"].get(key)
    if val is None:
        return jsonify({"error":"not ready"}),404
    return jsonify(_safe(val))

@app.route("/api/figures/<filename>")
def get_figure(filename): return send_from_directory(OUTPUT_DIR,filename)

@app.route("/api/download/<filename>")
def download_file(filename): return send_from_directory(OUTPUT_DIR,filename,as_attachment=True)


# ── Curated per-run downloads ────────────────────────────────────────
# ── Validation against known UAE flood events ────────────────────────
# Curated reference values from Copernicus EMS / DLR ZKI rapid mapping +
# Open-Meteo storm totals. Each entry: bbox approx, post-event date,
# expected detected open-water area (km²) range, headline storm metric.
_KNOWN_EVENTS = [
    {"name":"Dubai April 2024 flood",
     "bbox":(54.95, 24.80, 55.80, 25.45), "post_date":"2024-04-15",
     "ems_open_water_km2_lo": 22, "ems_open_water_km2_hi": 35,
     "expected_full_run_km2_lo": 400, "expected_full_run_km2_hi": 900,
     "rain_total_mm": 158,
     "ref":"Copernicus EMS EMSR724 + DLR ZKI rapid mapping"},
    {"name":"Abu Dhabi April 2024 flood",
     "bbox":(54.20, 24.20, 54.85, 24.70), "post_date":"2024-04-17",
     "ems_open_water_km2_lo": 15, "ems_open_water_km2_hi": 30,
     "expected_full_run_km2_lo": 250, "expected_full_run_km2_hi": 700,
     "rain_total_mm": 130,
     "ref":"Copernicus EMS EMSR724 + ERA5"},
    {"name":"Abu Dhabi March 2026 flood",
     "bbox":(54.10, 24.20, 54.85, 24.70), "post_date":"2026-03-30",
     "ems_open_water_km2_lo": 80, "ems_open_water_km2_hi": 200,
     "expected_full_run_km2_lo": 800, "expected_full_run_km2_hi": 1900,
     "rain_total_mm": 158,
     "ref":"NCM bulletin + Copernicus EMS"},
]

# Known UAE flood-event peak dates — used for the "N days after flood" badge.
# (Peak date = centroid of the heaviest 24 h of rainfall for each event.)
_EVENT_PEAKS = [
    ("Dubai April 2024 storm",       "2024-04-16", (55.10, 25.15)),
    ("Abu Dhabi April 2024 storm",   "2024-04-17", (54.50, 24.45)),
    ("Abu Dhabi March 2026 storm",   "2026-03-27", (54.50, 24.45)),
]

def _recession_stage(days):
    """Classify post-event stage (days since storm peak)."""
    if days is None:              return (None,  "—",          "#94A3B8")
    if days <= 1:                 return ("peak",      "peak flood — most water still visible",     "#EF4444")
    if days <= 3:                 return ("early",     "early recession — urban sheet drained, low-lying pooled",  "#FB923C")
    if days <= 7:                 return ("mid",       "mid recession — only wadis + depressions retain water", "#FBBF24")
    if days <= 21:                return ("late",      "late recession — residual ponds only",  "#22D3EE")
    return ("old", "long after — mostly drained / permanent water only", "#94A3B8")


def _days_after_flood(after_date, bbox):
    """Returns {event, peak_date, days_since_peak, stage, stage_label, color}
    when after_date is within ±30 days of a known UAE storm AND the ROI
    centroid is near the event centroid; else None."""
    if not after_date: return None
    try:
        from datetime import date
        post = date.fromisoformat(after_date[:10])
    except Exception:
        return None
    cx, cy = 0.5*(bbox.min_x+bbox.max_x), 0.5*(bbox.min_y+bbox.max_y)
    best=None
    for name, peak_iso, (ex, ey) in _EVENT_PEAKS:
        if abs(cx-ex) > 1.2 or abs(cy-ey) > 1.2:  # generous: UAE-wide
            continue
        peak = date.fromisoformat(peak_iso)
        d = (post - peak).days
        if -3 <= d <= 30 and (best is None or abs(d) < abs(best["days_since_peak"])):
            stage, label, color = _recession_stage(d)
            best = {"event": name, "peak_date": peak_iso,
                    "days_since_peak": d, "stage": stage,
                    "stage_label": label, "color": color}
    return best


def _build_acquisition_card(before_date, after_date, before_passes,
                             after_passes, bbox):
    """Returns a compact dict for R["acquisition"] — shown in the UI."""
    from datetime import date
    interval_days = None
    if before_date and after_date:
        try:
            b = date.fromisoformat(before_date[:10])
            a = date.fromisoformat(after_date[:10])
            interval_days = (a - b).days
        except Exception: pass
    return {
        "before_date":     before_date,
        "after_date":      after_date,
        "interval_days":   interval_days,
        "before_passes":   list(before_passes) if before_passes else [],
        "after_passes":    list(after_passes)  if after_passes  else [],
        "days_after_flood":_days_after_flood(after_date, bbox),
        "roi_center":      [round(0.5*(bbox.min_x+bbox.max_x),4),
                            round(0.5*(bbox.min_y+bbox.max_y),4)],
    }


def _validation_card(bbox, params, detected_km2):
    """Return None if no known event matches, else a comparison dict."""
    if bbox is None or detected_km2 is None: return None
    pd = (params or {}).get("after_end") or (params or {}).get("after_start")
    cx, cy = 0.5*(bbox.min_x+bbox.max_x), 0.5*(bbox.min_y+bbox.max_y)
    for ev in _KNOWN_EVENTS:
        ex_cx = 0.5*(ev["bbox"][0]+ev["bbox"][2])
        ex_cy = 0.5*(ev["bbox"][1]+ev["bbox"][3])
        if abs(cx-ex_cx) > 0.4 or abs(cy-ex_cy) > 0.4: continue
        try:
            from datetime import date
            d_run = date.fromisoformat(pd[:10]) if pd else None
            d_ev  = date.fromisoformat(ev["post_date"])
            if d_run and abs((d_run-d_ev).days) > 14: continue
        except Exception: pass
        lo, hi = ev["expected_full_run_km2_lo"], ev["expected_full_run_km2_hi"]
        if   detected_km2 < lo: agreement, verdict = round(100*detected_km2/lo,1), "below expected — try a looser T"
        elif detected_km2 > hi: agreement, verdict = round(100*hi/detected_km2,1), "above expected — try a stricter T"
        else: agreement, verdict = 100.0, "within validated range ✓"
        return {
            "event":          ev["name"],
            "post_date":      ev["post_date"],
            "rain_total_mm":  ev["rain_total_mm"],
            "ems_open_water_km2": [ev["ems_open_water_km2_lo"], ev["ems_open_water_km2_hi"]],
            "expected_full_run_km2":  [lo, hi],
            "detected_km2":   round(detected_km2, 2),
            "agreement_pct":  agreement,
            "verdict":        verdict,
            "reference":      ev["ref"],
        }
    return None


def _resolve_basename():
    """Pick the active output basename. The SAR pipeline writes:
        outputs/flood_threshold.tif        (mask)
        outputs/flood_threshold_depth.tif  (depth, if hydrology stage ran)
        outputs/change_threshold.tif       (ΔSAR, dB)
        outputs/flood_threshold.shp + .shx + .dbf + .prj
    The MODIS pipeline writes flood_modis.* analogues.
    The Simulate pipeline writes flood_sim.* analogues (never overwrites
    SAR results, so a user can compare both side by side).
    """
    mode = STATE.get("results", {}).get("mode")
    if mode == "modis":     return "flood_modis",     "modis"
    if mode == "simulate":  return "flood_sim",       "simulation"
    return "flood_threshold", "threshold"

@app.route("/api/dl/mask.tif")
def dl_mask():
    base,_=_resolve_basename()
    p=os.path.join(OUTPUT_DIR, f"{base}.tif")
    if not os.path.exists(p): return jsonify({"ok":False,"error":"no run"}), 404
    return send_file(p, as_attachment=True, download_name="flood_mask.tif")

@app.route("/api/dl/depth.tif")
def dl_depth():
    base,_=_resolve_basename()
    p=os.path.join(OUTPUT_DIR, f"{base}_depth.tif")
    # SAR pipeline doesn't always write _depth.tif yet — fall back to
    # building it on-demand from STATE["water_depth"].
    if not os.path.exists(p):
        depth=STATE.get("water_depth"); bbox=STATE.get("bbox")
        if depth is None or bbox is None:
            return jsonify({"ok":False,"error":"no depth raster"}), 404
        from exporter import save_float
        save_float(depth, bbox, p)
    return send_file(p, as_attachment=True, download_name="flood_depth.tif")

@app.route("/api/dl/change.tif")
def dl_change():
    pat=os.path.join(OUTPUT_DIR, "change_threshold.tif")
    if not os.path.exists(pat): return jsonify({"ok":False,"error":"no change raster"}), 404
    return send_file(pat, as_attachment=True, download_name="delta_sar.tif")

@app.route("/api/dl/polygons.shp.zip")
def dl_shp_zip():
    """Stream a zipped shapefile (4 sidecars)."""
    import io, zipfile
    base,_=_resolve_basename()
    parts=[f"{base}{ext}" for ext in (".shp",".shx",".dbf",".prj",".cpg")]
    parts=[p for p in parts if os.path.exists(os.path.join(OUTPUT_DIR,p))]
    if not parts: return jsonify({"ok":False,"error":"no shapefile"}), 404
    buf=io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in parts:
            z.write(os.path.join(OUTPUT_DIR,p), arcname=os.path.basename(p))
        # also include the UTM sibling if present
        for ext in (".shp",".shx",".dbf",".prj",".cpg"):
            up = f"{base}_utm{ext}"
            full=os.path.join(OUTPUT_DIR, up)
            if os.path.exists(full):
                z.write(full, arcname=up)
    buf.seek(0)
    return Response(buf.read(), mimetype="application/zip",
        headers={"Content-Disposition":'attachment; filename="flood_polygons.shp.zip"'})

@app.route("/api/dl/summary.json")
def dl_summary():
    """Run summary as a tidy JSON download."""
    R=STATE.get("results",{})
    payload={
        "bbox":     [STATE["bbox"].min_x, STATE["bbox"].min_y,
                     STATE["bbox"].max_x, STATE["bbox"].max_y]
                    if STATE.get("bbox") else None,
        "params":   STATE.get("params"),
        "roi_km2":  STATE.get("roi_km2"),
        "phase":    STATE.get("phase"),
        "detection":      R.get("detection"),
        "sar_detection":  R.get("sar_detection"),
        "depth":          R.get("depth"),
        "streets":        R.get("streets"),
        "validation":     R.get("validation"),
        "stats":          R.get("stats"),
    }
    return Response(json.dumps(_safe(payload), indent=2),
        mimetype="application/json",
        headers={"Content-Disposition":'attachment; filename="run_summary.json"'})

@app.route("/api/dl/polygons.csv")
def dl_polygons_csv():
    """CSV table of every flood polygon — the same attributes as the .shp."""
    base,_=_resolve_basename()
    shp=os.path.join(OUTPUT_DIR, f"{base}.shp")
    if not os.path.exists(shp):
        return jsonify({"ok":False,"error":"no shapefile"}), 404
    import geopandas as gpd, io as _io
    gdf=gpd.read_file(shp)
    gdf=gdf.drop(columns=["geometry"], errors="ignore")
    out=_io.StringIO(); gdf.to_csv(out, index=False)
    return Response(out.getvalue(), mimetype="text/csv",
        headers={"Content-Disposition":'attachment; filename="flood_polygons.csv"'})

@app.route("/api/dl/methodology.pdf")
def dl_methodology():
    """One-page A4 PDF explaining the pipeline + thresholds used."""
    p=os.path.join(OUTPUT_DIR, "methodology.pdf")
    _build_methodology_pdf(p)
    return send_file(p, as_attachment=True, download_name="UAE_FloodMap_methodology.pdf")

def _build_methodology_pdf(path):
    """Build a one-page methodology PDF with the run-time thresholds."""
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    R=STATE.get("results",{})
    sar=R.get("sar_detection",{}) or {}
    dep=R.get("depth",{}) or {}
    c=canvas.Canvas(path, pagesize=A4)
    W,H=A4
    # Header
    c.setFillColorRGB(0.04,0.07,0.12); c.rect(0, H-26*mm, W, 26*mm, fill=1, stroke=0)
    c.setFillColorRGB(0.13,0.83,0.93); c.setFont("Helvetica-Bold", 22)
    c.drawString(15*mm, H-15*mm, "UAE FloodMap v3 — Run Methodology")
    c.setFont("Helvetica", 10); c.setFillColorRGB(0.59,0.64,0.72)
    c.drawString(15*mm, H-21*mm, "Sentinel-1 SAR change-detection · HEC-HMS-style depth · Mapbox visualisation")
    y=H-36*mm
    def section(title):
        nonlocal y
        c.setFillColorRGB(0.98,0.74,0.14); c.setFont("Helvetica-Bold", 12)
        c.drawString(15*mm, y, title); y -= 6*mm
        c.setFillColorRGB(0.10,0.13,0.20)
    def line(s, mono=False):
        nonlocal y
        c.setFillColorRGB(0.10,0.13,0.20)
        c.setFont("Courier" if mono else "Helvetica", 10)
        c.drawString(18*mm, y, s); y -= 5*mm
    section("1. SAR change detection")
    line("ΔSAR = min(ΔVV, ΔVH)  in dB", True)
    auto = sar.get("auto", {})
    line(f"Threshold mode : {auto.get('applied','manual').upper()}  "
         f"(Otsu candidate {auto.get('otsu_db','—')} dB, "
         f"BC={auto.get('bhattacharyya','—')})")
    line(f"T used        : {sar.get('threshold_db_used','—')} dB"
         f"      seed T : {sar.get('seed_threshold_db_used','—')} dB", True)
    line("Region growing : binary_propagation(seed, mask=candidate)", True)
    line("Filters         : permanent water (OSM ∪ NDWI), slope ≤ 8°, "
         "min area = 1500 m²")
    section("2. Hydrology (HEC-HMS-style depth)")
    line("S = 25400/CN − 254       Q = (P − 0.2S)² / (P + 0.8S)", True)
    line(f"P = {dep.get('precip_total_mm','—')} mm   "
         f"CN = {dep.get('curve_number','—')}   "
         f"S = {dep.get('S_mm','—')} mm   "
         f"Iₐ = {dep.get('Ia_mm','—')} mm   "
         f"Q = {dep.get('runoff_Q_mm','—')} mm")
    line(f"Manning n = {dep.get('manning_n','—')}    "
         f"storm duration = {dep.get('storm_duration_h','—')} h")
    line("Depth on slopes : h = (q · n / √S_local)^(3/5)            (Chow 1959)", True)
    line("Depth in sinks  : depth = max(0, surface_rim − DEM)        (Cohen 2019)", True)
    line(f"Volume conservation factor = {dep.get('volume_conservation_factor','—')}")
    section("3. Run results")
    stages=sar.get("stages",{})
    line(f"Final flood pixels = {stages.get('final','—'):,}   "
         f"area = {sar.get('donut',{}).get('flood_km2','—')} km²"
            if isinstance(stages.get('final'),int) else "(no run yet)")
    dm=dep.get("depth_m") if isinstance(dep.get("depth_m"),dict) else None
    if dep:
        line(f"Depth: max {dep.get('max_depth_m','—')} m, mean {dep.get('mean_depth_m','—')} m, "
             f"p90 {dep.get('p90_depth_m','—')} m")
        line(f"Volumes: V_runoff = {dep.get('runoff_volume_m3','—')} m³ · "
             f"V_depth = {dep.get('depth_volume_m3','—')} m³")
    section("References")
    for r in [
        "Otsu (1979) IEEE TSMC 9(1) — automatic threshold",
        "Lee (1980) IEEE PAMI 2(2) — Refined-Lee speckle filter",
        "Twele et al. (2016) IJRS 37(13) — Sentinel-1 flood processing chain",
        "Markert et al. (2018) Remote Sens. — change-image Otsu (SERVIR)",
        "Cohen et al. (2019) JAWRA — FwDET sink-fill depth",
        "USDA-NRCS NEH-4 §10 — SCS Curve-Number runoff",
        "Chow (1959) — Manning kinematic-wave depth",
    ]: line("• " + r)
    c.setFillColorRGB(0.59,0.64,0.72); c.setFont("Helvetica", 8)
    c.drawString(15*mm, 10*mm, f"Generated {dt.datetime.utcnow().isoformat(timespec='seconds')}Z   ·   "
                               f"UAE FloodMap v3   ·   Author: Wassim Ehtouhami")
    c.save()

@app.route("/api/list-outputs")
def list_outputs():
    files=[]
    if os.path.isdir(OUTPUT_DIR):
        for f in sorted(os.listdir(OUTPUT_DIR)):
            p=os.path.join(OUTPUT_DIR,f)
            if os.path.isfile(p): files.append({"name":f,"size_kb":round(os.path.getsize(p)/1024,1)})
    return jsonify({"ok":True,"files":files})

@app.route("/api/reset", methods=["POST"])
def reset():
    STATE.update({"phase":"idle","progress":0,"message":"","results":{},"error":None,"bbox":None})
    return jsonify({"ok":True})

@app.route("/api/cache")
def list_cache():
    """List cached runs."""
    entries=[]
    if os.path.isdir(CACHE_DIR):
        keys=set()
        for f in os.listdir(CACHE_DIR):
            if f.endswith(".pkl"):
                k=f.rsplit("_",1)[0]
                keys.add(k)
        for k in sorted(keys):
            tags=[f.replace(k+"_","").replace(".pkl","")
                  for f in os.listdir(CACHE_DIR) if f.startswith(k)]
            size_kb=sum(os.path.getsize(os.path.join(CACHE_DIR,f))
                        for f in os.listdir(CACHE_DIR) if f.startswith(k))/1024
            entries.append({"key":k,"tags":tags,"size_kb":round(size_kb,1)})
    return jsonify({"ok":True,"entries":entries})

@app.route("/api/cache/clear", methods=["POST"])
def clear_cache():
    """Clear all cached data."""
    import glob
    removed=0
    for f in glob.glob(os.path.join(CACHE_DIR,"*.pkl")):
        os.remove(f); removed+=1
    return jsonify({"ok":True,"removed":removed})

if __name__=="__main__":
    port=int(os.environ.get("PORT",5000))
    L.info(f"UAE FloodMap v3 starting on port {port}")
    app.run(host="0.0.0.0",port=port,debug=False,threaded=True)
