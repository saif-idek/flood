"""
╔══════════════════════════════════════════════════════════════════════╗
║   UAE FloodMap — Advanced Flood Statistics                          ║
║                                                                      ║
║   build_advanced_stats() is the single authoritative output dict    ║
║   for EVERY run (any sensor: s1 / s2 / simulate / modis).          ║
║                                                                      ║
║   Standards:                                                         ║
║     Depth-band histogram — Copernicus EMS GRD v2.2 specification   ║
║     Volume — Cohen, Brakenridge & Kettner (2019) JAWRA 55(4)        ║
║     Severity — WMO No. 168 Guide to Hydrological Practices §5.5    ║
║     Quality grade — EMS product specification (confidence + cloud)  ║
║                                                                      ║
║   Hard zero-floor: mask.sum() == 0 → every numeric field = 0.0,    ║
║     no_flood = True, severity = "none", quality_grade = "A".        ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging
import numpy as np

L = logging.getLogger("flood.stats")

# ── Copernicus EMS GRD v2.2 depth-band specification ─────────────────
DEPTH_BANDS = [
    (0.00,  0.25),
    (0.25,  0.50),
    (0.50,  1.00),
    (1.00,  2.00),
    (2.00,  np.inf),
]
BAND_KEYS = ["0_25cm", "25_50cm", "50_100cm", "1_2m", "gt2m"]


def _depth_band_km2(depth_arr, pixel_area_m2):
    """Return ordered dict of Copernicus EMS depth-band areas (km²).

    Parameters
    ----------
    depth_arr : 1-D float32 array of positive depths (flood pixels only).
    pixel_area_m2 : float — area of one pixel in m².
    """
    result = {}
    for (lo, hi), key in zip(DEPTH_BANDS, BAND_KEYS):
        in_band = ((depth_arr >= lo) & (depth_arr < hi)).sum()
        result[key] = float(in_band) * pixel_area_m2 / 1e6
    return result


def _quality_grade(mean_conf, cloud_or_nodata_frac, no_flood):
    """Single-letter quality grade A–D.

    A: high confidence and minimal cloud / data gaps.
    B: acceptable confidence or limited cloud.
    C: marginal confidence.
    D: below C — report but caveat.

    If no_flood is True → always "A" (vacuous truth: nothing to be wrong
    about; a correct zero result is the best possible outcome).
    """
    if no_flood:
        return "A", "No flood detected — null result is unambiguous."
    if mean_conf >= 0.7 and cloud_or_nodata_frac < 0.10:
        return "A", "High confidence, low cloud/gap fraction."
    if mean_conf >= 0.5 or cloud_or_nodata_frac < 0.30:
        return "B", "Moderate confidence or moderate cloud fraction."
    if mean_conf >= 0.3:
        return "C", "Low confidence — extent uncertain."
    return "D", "Very low confidence — treat as indicative only."


def _severity(no_flood, total_mm, flooded_pct_roi, max_depth_m):
    """Joint extent × depth severity classification.

    Hard zero-floor: if no_flood OR total_mm == 0 → "none".

    Thresholds use a 2-axis matrix: inundation extent (% of ROI) AND
    maximum water depth (m) must BOTH be considered.  Neither axis
    alone determines the label — this prevents a handful of deep pixels
    in a narrow wadi from being reported as "severe" over an otherwise
    dry ROI (the pre-fix bug), and equally prevents a shallow sheet
    flood covering 30 % of an ROI from being under-reported.

    Reference matrix
    ────────────────
    Based on Copernicus EMS GRD v2.2 §4.3 "severity classification"
    (extent-class × depth-class lookup) and NWS/FEMA depth-damage
    conventions (Merz et al. 2010, Nat. Hazards Earth Syst. Sci.
    10:1697-1724 §3.1) which establish that below 0.5 m depth flood
    damage is minor even over large areas, and that very-deep water
    (>3 m) warrants "major" only when it covers a non-trivial extent.

    extent class:
        tiny   < 1 % ROI
        small  1–5 %
        medium 5–25 %
        large  > 25 %

    depth class (max depth):
        shallow  < 0.5 m
        mid      0.5–1.5 m
        deep     1.5–3.0 m
        extreme  > 3.0 m

    Matrix (extent_class → severity by depth_class):
               shallow   mid      deep     extreme
    tiny       minor     minor    moderate  major
    small      minor     moderate major     severe
    medium     moderate  major    severe    extreme
    large      major     severe   extreme   extreme
    """
    if no_flood or total_mm == 0:
        return "none"
    if flooded_pct_roi <= 0:
        return "none"

    # ── classify extent ───────────────────────────────────────────────
    if flooded_pct_roi < 1.0:
        e = 0   # tiny
    elif flooded_pct_roi < 5.0:
        e = 1   # small
    elif flooded_pct_roi < 25.0:
        e = 2   # medium
    else:
        e = 3   # large

    # ── classify depth ────────────────────────────────────────────────
    if max_depth_m < 0.5:
        d = 0   # shallow
    elif max_depth_m < 1.5:
        d = 1   # mid
    elif max_depth_m < 3.0:
        d = 2   # deep
    else:
        d = 3   # extreme

    # ── lookup matrix [extent][depth] ────────────────────────────────
    _MATRIX = [
        # shallow    mid       deep      extreme
        ["minor",   "minor",  "moderate", "major"],    # tiny
        ["minor",   "moderate","major",   "severe"],   # small
        ["moderate","major",  "severe",  "extreme"],   # medium
        ["major",   "severe", "extreme", "extreme"],   # large
    ]
    return _MATRIX[e][d]


def build_advanced_stats(
    flood_mask,         # uint8 (H, W) — 1 = flooded pixel
    depth,              # float32 (H, W) — metres, 0 outside mask
    confidence,         # float32 (H, W) — 0..1 per-pixel
    precip_analysis,    # dict from precipitation.analyse_precipitation()
    streets_summary,    # dict from streets.flooded_streets_summary() or {}
    roi_km2,            # float — total ROI area in km²
    pixel_m,            # float — pixel edge length in metres
    sensor,             # "s1" | "s2" | "simulate" | "modis"
    regime="uncalibrated",  # KGE regime for severity context
    cloud_or_nodata_frac=0.0,  # optional float [0..1]
):
    """Compute the WS-3 advanced flood-statistics block.

    Returns a flat dict with all required JSON keys. Pure-numpy; no I/O.

    Guaranteed invariants
    ---------------------
    - When flood_mask.sum() == 0 every numeric field is exactly 0.0 (not
      np.nan, not -0.0); no_flood = True; quality_grade = "A"; severity = "none".
    - depth_band_km2 values sum to flooded_km2 (within floating-point precision).
    - confidence_weighted_km2 <= flooded_km2 always.
    - p90_depth_m <= max_depth_m always.
    """
    flood_mask = np.asarray(flood_mask, dtype=np.uint8)
    depth      = np.asarray(depth,      dtype=np.float32)
    confidence = np.asarray(confidence, dtype=np.float32)

    pixel_area_m2 = float(pixel_m) ** 2
    roi_km2       = float(roi_km2)

    # ── Hard zero-floor ───────────────────────────────────────────────
    no_flood = bool(flood_mask.sum() == 0)

    if no_flood:
        L.info("build_advanced_stats: mask is empty → returning all-zero stats.")
        return {
            "sensor":                   sensor,
            "flooded_km2":              0.0,
            "flooded_pct_roi":          0.0,
            "depth_band_km2":           {k: 0.0 for k in BAND_KEYS},
            "depth_m": {
                "mean":   0.0,
                "median": 0.0,
                "p90":    0.0,
                "max":    0.0,
            },
            "flood_volume_m3":          0.0,
            "affected_streets_km":      0.0,
            "affected_street_segments": 0,
            "confidence_weighted_km2":  0.0,
            "quality_grade":            "A",
            "quality_notes":            "No flood detected — null result is unambiguous.",
            "severity":                 "none",
            "return_period_est":        precip_analysis.get("return_period_est", "n/a"),
            "regime":                   precip_analysis.get("regime", regime),
            "no_flood":                 True,
        }

    # ── Flood area ────────────────────────────────────────────────────
    n_flood_px    = int(flood_mask.sum())
    flooded_km2   = float(n_flood_px) * pixel_area_m2 / 1e6
    flooded_pct   = (flooded_km2 / roi_km2 * 100.0) if roi_km2 > 0 else 0.0

    # ── Depth statistics (flood pixels only) ─────────────────────────
    flood_bool  = flood_mask.astype(bool)
    depth_vals  = depth[flood_bool]
    # guard: only positive depths (some callers may zero-out below noise floor)
    pos_vals    = depth_vals[depth_vals > 0]
    if pos_vals.size > 0:
        mean_d   = float(pos_vals.mean())
        median_d = float(np.median(pos_vals))
        p90_d    = float(np.percentile(pos_vals, 90))
        max_d    = float(pos_vals.max())
    else:
        mean_d = median_d = p90_d = max_d = 0.0

    # ── Flood volume (Cohen et al. 2019) ─────────────────────────────
    # Guard against NaN/inf depth inside the mask (e.g. a single bad DEM
    # pixel or a 0/0 reflectance ratio).  np.nan_to_num converts NaN→0,
    # inf→large finite; then summing only finite positive depths keeps
    # the volume physically meaningful and avoids poisoning to NaN.
    _depth_safe = np.where(
        np.isfinite(depth[flood_bool]) & (depth[flood_bool] >= 0),
        depth[flood_bool],
        0.0,
    )
    flood_volume_m3 = float(_depth_safe.sum()) * pixel_area_m2

    # ── Depth-band histogram (Copernicus EMS GRD v2.2) ───────────────
    # Re-derive depth_vals with the same NaN/inf guard so band counts
    # match the volume (no phantom NaN pixels leaking into any band).
    depth_vals = _depth_safe.astype(np.float32)
    band_km2 = _depth_band_km2(depth_vals, pixel_area_m2)

    # ── Confidence-weighted area ──────────────────────────────────────
    conf_weighted_km2 = float(
        (flood_mask.astype(np.float32) * confidence).sum()
    ) * pixel_area_m2 / 1e6
    # clamp to flooded_km2 in case of floating-point overflow
    conf_weighted_km2 = min(conf_weighted_km2, flooded_km2)

    # ── Quality grade ─────────────────────────────────────────────────
    mean_conf = float(confidence[flood_bool].mean()) if n_flood_px > 0 else 0.0
    grade, grade_notes = _quality_grade(mean_conf, cloud_or_nodata_frac, no_flood)

    # ── Severity ──────────────────────────────────────────────────────
    total_mm   = float(precip_analysis.get("total_mm", 0))
    sev        = _severity(no_flood, total_mm, flooded_pct, max_d)

    # ── Affected streets ──────────────────────────────────────────────
    affected_km  = float(streets_summary.get("flooded_km", 0.0))

    # flooded_segments: sum segments across by_class excluding "dry"
    by_class = streets_summary.get("by_class", {})
    if by_class:
        affected_segs = sum(
            v.get("segments", 0)
            for cls, v in by_class.items()
            if cls != "dry"
        )
    else:
        affected_segs = int(streets_summary.get("flooded_segments", 0))

    # ── Assemble output dict ──────────────────────────────────────────
    result = {
        "sensor":                   sensor,
        "flooded_km2":              round(flooded_km2, 4),
        "flooded_pct_roi":          round(flooded_pct, 4),
        "depth_band_km2":           {k: round(v, 6) for k, v in band_km2.items()},
        "depth_m": {
            "mean":   round(mean_d,   4),
            "median": round(median_d, 4),
            "p90":    round(p90_d,    4),
            "max":    round(max_d,    4),
        },
        "flood_volume_m3":          round(flood_volume_m3, 1),
        "affected_streets_km":      round(affected_km, 2),
        "affected_street_segments": affected_segs,
        "confidence_weighted_km2":  round(conf_weighted_km2, 4),
        "quality_grade":            grade,
        "quality_notes":            grade_notes,
        "severity":                 sev,
        "return_period_est":        precip_analysis.get("return_period_est", "n/a"),
        "regime":                   precip_analysis.get("regime", regime),
        "no_flood":                 False,
    }

    L.info(
        f"build_advanced_stats [{sensor}]: {flooded_km2:.3f} km²  "
        f"({flooded_pct:.2f}% ROI)  vol={flood_volume_m3:,.0f} m³  "
        f"max_d={max_d:.2f}m  severity={sev}  grade={grade}"
    )
    return result
