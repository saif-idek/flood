#!/usr/bin/env python3
"""
============================================================================
 UAE FloodMap - ML flood-classification driver
============================================================================

Trains and compares the three ML flood-classification methodologies
(Random Forest, U-Net, pixel-MLP) on a scene, using the same feature stack
and the same (weak or ground-truth) labels, then reports per-method
flood-area + agreement so they can be benchmarked head-to-head.

Two ways to get a scene
-----------------------
1. SYNTHETIC (default, no network/credentials) - a deterministic test scene
   with a known water patch. Verifies the whole package end-to-end:
       python run_ml_classify.py

2. LIVE Sentinel-2 over an ROI via the project's downloader (GEE fallback) -
   builds a real {green,nir,swir1,dem} feature scene and classifies it:
       set -a && . /home/wassi/Bathymetry_VMarch/.env && set +a
       export S2_GEE_FALLBACK=1 EE_PROJECT=ee-wassimehtp
       python run_ml_classify.py --live --bbox 55.73 24.18 55.82 24.25 \
              --post 2024-04-16 2024-04-30

The three methods all expose the project's detector contract
({"mask","confidence","info"}), so any of them can be dropped into the
existing vectorise / advanced-stats / water-height pipeline.
"""
from __future__ import annotations
import argparse
import logging
import numpy as np

from ml_classifiers import (FloodRandomForest, weak_labels_from_detectors)

L = logging.getLogger("flood.ml.driver")


def synthetic_scene(seed=7):
    rng = np.random.default_rng(seed)
    H, W = 120, 160
    green = rng.uniform(0.05, 0.15, (H, W)).astype(np.float32)
    nir = rng.uniform(0.20, 0.35, (H, W)).astype(np.float32)
    swir1 = rng.uniform(0.15, 0.30, (H, W)).astype(np.float32)
    truth = np.zeros((H, W), np.uint8)
    truth[30:85, 40:130] = 1               # a river-like flood patch
    truth[90:110, 60:75] = 1               # a detached pond
    green[truth == 1] = 0.18; nir[truth == 1] = 0.03; swir1[truth == 1] = 0.02
    dem = (rng.uniform(0, 4, (H, W)) + np.linspace(0, 30, W)[None, :]).astype(np.float32)
    inputs = dict(green=green, nir=nir, swir1=swir1, blue=green * 0.9,
                  red=nir * 0.9, dem=dem)
    return inputs, truth


def live_scene(bbox, pre, post):
    """Build a real S2 feature scene via the project downloader (GEE fallback)."""
    from downloader import download_s2_flood, download_dem
    L.info("LIVE: fetching post-event S2 over %s (%s..%s)", bbox, *post)
    post_arr = download_s2_flood(bbox, post[0], post[1])   # (H,W,7) B02,B03,B04,B08,B11,B12,SCL
    pre_arr = download_s2_flood(bbox, pre[0], pre[1]) if pre else None
    # band order from detection_s2 contract: 0=B02 blue,1=B03 green,2=B04 red,
    # 3=B08 nir,4=B11 swir1,5=B12 swir2,6=SCL  (reflectance already /10000)
    inputs = dict(blue=post_arr[..., 0], green=post_arr[..., 1], red=post_arr[..., 2],
                  nir=post_arr[..., 3], swir1=post_arr[..., 4], swir2=post_arr[..., 5])
    try:
        dem = download_dem(bbox, target_shape=post_arr.shape[:2])
        inputs["dem"] = np.asarray(dem, np.float32)
    except Exception as e:
        L.warning("DEM unavailable (%s) - proceeding without terrain features", e)
    perm = None
    if pre_arr is not None:
        g, n = pre_arr[..., 1], pre_arr[..., 3]
        ndwi_pre = (g - n) / (g + n + 1e-6)
        perm = ndwi_pre > 0.2          # pre-event permanent water
    return inputs, perm


def iou(a, b):
    a, b = a.astype(bool), b.astype(bool)
    u = np.logical_or(a, b).sum()
    return float(np.logical_and(a, b).sum() / u) if u else 1.0


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(name)s] %(levelname)s %(message)s")
    ap = argparse.ArgumentParser(description="ML flood classification (RF / U-Net / MLP)")
    ap.add_argument("--live", action="store_true", help="fetch a real S2 scene")
    ap.add_argument("--bbox", nargs=4, type=float, metavar=("W", "S", "E", "N"))
    ap.add_argument("--pre", nargs=2, metavar=("FROM", "TO"))
    ap.add_argument("--post", nargs=2, metavar=("FROM", "TO"))
    ap.add_argument("--methods", default="rf,unet,mlp",
                    help="comma list: rf,unet,mlp")
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--pixel-m", type=float, default=10.0)
    args = ap.parse_args()

    truth = None
    if args.live:
        if not (args.bbox and args.post):
            ap.error("--live requires --bbox and --post")
        inputs, perm = live_scene(args.bbox, args.pre, args.post)
        labels = weak_labels_from_detectors(inputs, permanent_water=perm)
    else:
        inputs, truth = synthetic_scene()
        labels = truth
        perm = None

    methods = [m.strip() for m in args.methods.split(",") if m.strip()]
    results = {}
    roi_px = next(iter(inputs.values())).size

    for m in methods:
        L.info("=== training methodology: %s ===", m)
        if m == "rf":
            clf = FloodRandomForest(n_estimators=200).fit_scene(
                inputs, labels=labels, permanent_water=perm,
                n_per_class=8000, pixel_m=args.pixel_m)
            out = clf.predict_scene(inputs, threshold=args.threshold, pixel_m=args.pixel_m)
            L.info("RF top features: %s", clf.feature_importances()[:4])
        elif m == "unet":
            from ml_classifiers import FloodUNet
            clf = FloodUNet(patch=48).fit_scene(inputs, labels=labels,
                                                epochs=25, n_patches=48,
                                                pixel_m=args.pixel_m)
            out = clf.predict_scene(inputs, threshold=args.threshold, pixel_m=args.pixel_m)
        elif m == "mlp":
            from ml_classifiers import FloodMLP
            clf = FloodMLP().fit_scene(inputs, labels=labels, permanent_water=perm,
                                       epochs=40, n_per_class=8000, pixel_m=args.pixel_m)
            out = clf.predict_scene(inputs, threshold=args.threshold,
                                    pixel_m=args.pixel_m, mc_passes=10)
        else:
            L.warning("unknown method '%s' - skipping", m); continue
        results[m] = out
        frac = out["mask"].mean()
        line = "  %-5s flood %.2f%% of ROI  (conf mean %.3f)" % (
            m, 100 * frac, float(out["confidence"].mean()))
        if truth is not None:
            line += "  | IoU-vs-truth %.3f" % iou(out["mask"], truth)
        print(line)

    # cross-method agreement
    if len(results) > 1:
        print("\n--- pairwise IoU agreement between methodologies ---")
        ms = list(results)
        for i in range(len(ms)):
            for j in range(i + 1, len(ms)):
                print("  %s vs %s : IoU %.3f" % (
                    ms[i], ms[j], iou(results[ms[i]]["mask"], results[ms[j]]["mask"])))
    print("\nDone. %d pixels/scene, methods: %s" % (roi_px, ", ".join(results)))


if __name__ == "__main__":
    main()
