"""
╔══════════════════════════════════════════════════════════════════════╗
║   UAE FloodMap – Standalone Sentinel-1 Threshold Flood Mapper       ║
║   Threshold-only · accurate shapefile · no Otsu / Z / ensemble      ║
║                                                                      ║
║   Usage:                                                            ║
║                                                                      ║
║     # Live (downloads via Sentinel Hub if not cached):              ║
║     python flood_threshold.py \                                      ║
║       --bbox 54.2792 24.3351 54.5210 24.5649 \                      ║
║       --before 2026-03-14 2026-03-21 \                               ║
║       --after  2026-03-27 2026-03-31 \                               ║
║       --out    outputs/flood_threshold                              ║
║                                                                      ║
║     # From an existing cache file (no network, useful for tuning):  ║
║     python flood_threshold.py \                                      ║
║       --bbox 54.2792 24.3351 54.5210 24.5649 \                      ║
║       --from-cache 2547d911e81a \                                    ║
║       --out outputs/flood_threshold                                 ║
║                                                                      ║
║   Outputs (alongside <out>):                                        ║
║     <out>.tif       — uint8 binary flood raster (EPSG:4326)         ║
║     <out>.shp       — flood polygons (EPSG:4326)                     ║
║     <out>_utm.shp   — same polygons in local UTM (true metres)      ║
║     <out>_change.tif — ΔVV in dB (diagnostic)                       ║
║     <out>.json      — run config + per-stage pixel accounting       ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import argparse, json, logging, os, pickle, sys
from pathlib import Path
import numpy as np

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s")
L = logging.getLogger("flood.threshold")


def _load_cache(cache_dir, key, tag):
    p = Path(cache_dir) / f"{key}_{tag}.pkl"
    if not p.exists():
        return None
    with open(p, "rb") as f:
        return pickle.load(f)


def _make_bbox(coords):
    from sentinelhub import BBox, CRS
    return BBox(bbox=list(coords), crs=CRS.WGS84)


def _ensure_aux(bbox, target_shape):
    """Try cache; otherwise download DEM + NDWI water mask."""
    from downloader import download_dem, download_water_mask
    dem = download_dem(bbox, target_shape)
    try:
        wmask, _ = download_water_mask(bbox, "2024-01-01", "2024-12-31", target_shape)
    except Exception as e:
        L.warning(f"NDWI water mask unavailable ({e}) — proceeding without")
        wmask = None
    return dem, wmask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bbox", nargs=4, type=float, required=True,
                    metavar=("W", "S", "E", "N"))
    ap.add_argument("--before", nargs=2, metavar=("FROM", "TO"))
    ap.add_argument("--after",  nargs=2, metavar=("FROM", "TO"))
    ap.add_argument("--from-cache", help="Cache key prefix to load SAR (and aux if present) without re-downloading")
    ap.add_argument("--cache-dir", default="outputs/cache")
    ap.add_argument("--out", default="outputs/flood_threshold",
                    help="Output basename (no extension)")
    ap.add_argument("--threshold-db", type=float, default=None,
                    help="Override min(ΔVV, ΔVH) threshold (dB)")
    ap.add_argument("--depth-scale-m-per-db", type=float, default=None,
                    help="Override depth-per-dB scale (m/dB)")
    ap.add_argument("--max-slope-deg", type=float, default=None,
                    help="Override slope ceiling for flood pixels")
    ap.add_argument("--min-area-m2", type=float, default=None,
                    help="Override minimum connected-component area")
    ap.add_argument("--no-aux", action="store_true",
                    help="Skip DEM + water-mask download (raw threshold only)")
    args = ap.parse_args()

    bbox = _make_bbox(args.bbox)

    # ── 1. SAR ─────────────────────────────────────────────────────
    if args.from_cache:
        sar = _load_cache(args.cache_dir, args.from_cache, "sar")
        if sar is None:
            sys.exit(f"No SAR cache for key '{args.from_cache}' in {args.cache_dir}")
        before, after = sar["before"], sar["after"]
        L.info(f"Loaded SAR cache {args.from_cache}: before={before.shape}, after={after.shape}")
    else:
        if not (args.before and args.after):
            sys.exit("Provide --before FROM TO and --after FROM TO (or --from-cache KEY)")
        from downloader import download_s1
        L.info(f"Downloading Sentinel-1 before={args.before} after={args.after}")
        before = download_s1(bbox, args.before[0], args.before[1])
        after  = download_s1(bbox, args.after[0],  args.after[1])

    # ── 2. Auxiliary (DEM + permanent water) ───────────────────────
    dem, wmask = None, None
    if not args.no_aux:
        if args.from_cache:
            aux = _load_cache(args.cache_dir, args.from_cache, "aux")
            if aux is not None:
                dem = aux.get("dem")
                wmask = aux.get("water_mask")
                L.info(f"Loaded aux cache: dem={None if dem is None else dem.shape}, "
                       f"water_mask={None if wmask is None else wmask.shape}")
        if dem is None:
            try:
                dem, wmask = _ensure_aux(bbox, before.shape[:2])
            except Exception as e:
                L.warning(f"Aux download failed ({e}) — running without DEM/water mask")

    # ── 3. Threshold detection ─────────────────────────────────────
    from detection import detect_flood, pixel_size_m
    px_m = pixel_size_m(bbox, before.shape[:2])
    L.info(f"True pixel size: {px_m:.2f} m  (raster {before.shape[1]}×{before.shape[0]} over bbox)")

    kwargs = {"pixel_m": px_m}
    for cfg_key, arg_key in [("threshold_db",         "threshold_db"),
                             ("depth_scale_m_per_db", "depth_scale_m_per_db"),
                             ("max_slope_deg",        "max_slope_deg"),
                             ("min_area_m2",          "min_area_m2")]:
        v = getattr(args, arg_key)
        if v is not None:
            kwargs[cfg_key] = v

    det = detect_flood(before, after,
                       permanent_water=wmask, dem=dem, **kwargs)

    # ── 4. Save rasters + shapefile + depth raster ─────────────────
    out_base = Path(args.out)
    out_base.parent.mkdir(parents=True, exist_ok=True)

    from exporter import save_mask, save_float, save_flood_shapefile
    tif_path    = str(out_base.with_suffix(".tif"))
    change_path = str(out_base.parent / f"{out_base.stem}_change.tif")
    depth_path  = str(out_base.parent / f"{out_base.stem}_depth.tif")
    shp_path    = str(out_base.with_suffix(".shp"))
    json_path   = str(out_base.with_suffix(".json"))

    save_mask(det["mask"], bbox, tif_path)
    save_float(det["change"], bbox, change_path)
    save_float(det["depth"],  bbox, depth_path)
    gdf = save_flood_shapefile(det["mask"], bbox, shp_path,
                               method_name="threshold",
                               post_db=det["post_db"],
                               depth=det["depth"])

    summary = {
        "bbox":     list(args.bbox),
        "shape":    [int(before.shape[0]), int(before.shape[1])],
        "info":     det["info"],
        "polygons": 0 if gdf is None else int(len(gdf)),
        "area_km2": 0.0 if gdf is None else float(gdf["area_km2"].sum()),
        "outputs":  {"raster": tif_path, "shapefile": shp_path,
                     "change_db_raster": change_path,
                     "depth_raster": depth_path},
    }
    with open(json_path, "w") as f:
        json.dump(summary, f, indent=2)
    L.info(f"Wrote summary → {json_path}")
    L.info(f"FLOOD: {summary['area_km2']:.4f} km² across {summary['polygons']} polygons")


if __name__ == "__main__":
    main()
