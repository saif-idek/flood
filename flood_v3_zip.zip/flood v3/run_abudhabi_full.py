#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║   Abu Dhabi Full City — DEM + Precipitation Flood Simulation           ║
║   ~3850 km² · Every street colored by modeled water height             ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
import sys, os, time, logging, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s")
L = logging.getLogger("sim.abudhabi")

from config import *
import config
config.RESOLUTION_M = 40  # 40m for large area
config.MAX_WATER_DEPTH_M = 0.50

from sentinelhub import BBox, CRS, bbox_to_dimensions

BBOX = [54.1607, 24.1658, 54.8407, 24.6735]
bbox = BBox(bbox=BBOX, crs=CRS.WGS84)
size = bbox_to_dimensions(bbox, resolution=40)
PRECIP_DATE = "2026-03-31"
PRECIP_MM = 158.0  # total mm from ERA5

L.info(f"Abu Dhabi Full: {BBOX}, grid={size}, res=40m")

# ── 1. DEM ──────────────────────────────────────────────────────────
L.info("Downloading DEM…")
t0 = time.time()
from downloader import download_dem
dem = download_dem(bbox, resolution=40)
L.info(f"DEM: {dem.shape}, range [{dem.min():.1f}, {dem.max():.1f}]m, {time.time()-t0:.0f}s")

# ── 2. Flow accumulation + flood simulation ─────────────────────────
L.info("Running flow accumulation…")
t0 = time.time()
from flood_sim import flow_accumulation
from scipy.ndimage import gaussian_filter

dem_s = gaussian_filter(dem, sigma=3)
flow_acc = flow_accumulation(dem_s, smooth_sigma=3)
L.info(f"Flow acc done: {time.time()-t0:.0f}s")

# Identify flood-prone areas: low elevation + high flow accumulation
# Normalize both
dem_norm = (dem_s - dem_s.min()) / max(dem_s.max() - dem_s.min(), 1)
fa_norm = np.log1p(flow_acc)
fa_norm = (fa_norm - fa_norm.min()) / max(fa_norm.max() - fa_norm.min(), 1)

# Flood susceptibility: high flow + low elevation
susceptibility = 0.6 * fa_norm + 0.4 * (1.0 - dem_norm)

# Rainfall-driven depth: areas with susceptibility > threshold get water
# Higher susceptibility = deeper water
rain_m = PRECIP_MM * 0.001
runoff_coeff = 0.30  # urban areas ~0.3

# Threshold: top 40% susceptibility gets flooded
thresh = np.percentile(susceptibility, 60)
flood_mask = (susceptibility >= thresh).astype(np.uint8)

# Remove ocean/sea (dem < -2m)
flood_mask[dem < -2] = 0

# Water depth proportional to susceptibility above threshold
depth = np.zeros_like(dem, dtype=np.float32)
flooded = flood_mask.astype(bool)
if flooded.sum() > 0:
    s_flooded = susceptibility[flooded]
    s_min, s_max = s_flooded.min(), s_flooded.max()
    s_range = max(s_max - s_min, 0.01)
    # scale to 0-0.5m, with rain volume influence
    depth[flooded] = ((susceptibility[flooded] - s_min) / s_range) * 0.45 + 0.02
    # add rainfall base
    depth[flooded] += rain_m * runoff_coeff * 0.3
    depth = np.clip(depth, 0, 0.50)
    depth[~flooded] = 0

pixel_area = 40 * 40
flood_km2 = flooded.sum() * pixel_area / 1e6
volume = depth.sum() * pixel_area

L.info(f"Flood: {flood_km2:.1f} km², max={depth.max():.2f}m, "
       f"mean={depth[flooded].mean():.2f}m, vol={volume:,.0f}m³")

# ── 3. Download ALL streets ─────────────────────────────────────────
L.info("Downloading ALL Abu Dhabi streets…")
t0 = time.time()
from streets import download_osm_streets, compute_street_water_depth, flooded_streets_summary
streets = download_osm_streets(bbox)
L.info(f"Streets: {len(streets)} segments, {time.time()-t0:.0f}s")

L.info("Computing street water heights…")
t0 = time.time()
gdf = compute_street_water_depth(streets, depth, bbox)
summary = flooded_streets_summary(gdf)
L.info(f"Roads: {summary['flooded_km']:.1f} km flooded / {summary['total_km']:.1f} km total, {time.time()-t0:.0f}s")

# ── 4. Generate professional figures ────────────────────────────────
L.info("Generating figures…")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

BG = "#0B1120"
CARD = "#111827"
BORDER = "#334155"
TEXT = "#E2E8F0"
TEXT2 = "#94A3B8"
TEXT3 = "#64748B"
NAVY = "#0F172A"

extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]

def hillshade(d, az=315, alt=35):
    dy, dx = np.gradient(d)
    slope = np.sqrt(dx**2 + dy**2)
    aspect = np.arctan2(-dy, dx)
    az_r, alt_r = np.radians(az), np.radians(alt)
    shade = np.sin(alt_r)*np.cos(slope) + np.cos(alt_r)*np.sin(slope)*np.cos(az_r - aspect)
    return np.clip(shade, 0, 1)

def terrain_bg(ax):
    hs = hillshade(dem_s)
    rgb = np.zeros((*hs.shape, 3))
    rgb[:,:,0] = 0.04 + hs * 0.14
    rgb[:,:,1] = 0.06 + hs * 0.17
    rgb[:,:,2] = 0.10 + hs * 0.24
    ax.imshow(rgb, extent=extent, aspect="equal", interpolation="bilinear")

def style(ax):
    ax.set_facecolor(CARD)
    for sp in ax.spines.values():
        sp.set_color(BORDER); sp.set_linewidth(0.6)
    ax.tick_params(colors=TEXT2, labelsize=8, length=3, width=0.5)
    ax.grid(True, alpha=0.1, color=BORDER, linewidth=0.4)

# Depth colormap: cyan → yellow → orange → red
DCMAP = LinearSegmentedColormap.from_list("street_depth", [
    (0.00, "#0B1120"),
    (0.04, "#164E63"),
    (0.10, "#22D3EE"),
    (0.25, "#38BDF8"),
    (0.40, "#FBBF24"),
    (0.60, "#FB923C"),
    (0.80, "#EF4444"),
    (1.00, "#991B1B"),
])

# Street severity colors
STREET_COLORS = {
    "dry":      "#2D3748",
    "low":      "#FACC15",
    "medium":   "#FB923C",
    "high":     "#EF4444",
    "critical": "#991B1B",
}

# ═══════════════════════════════════════════════════════════════════
# FIGURE 1: Full city water depth model
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 1: Urban water depth…")
fig, ax = plt.subplots(1, 1, figsize=(18, 14), facecolor=BG)
style(ax)
terrain_bg(ax)

masked = np.ma.masked_where(depth < 0.005, depth)
im = ax.imshow(masked, cmap=DCMAP, vmin=0, vmax=0.50,
               extent=extent, aspect="equal", alpha=0.85, interpolation="bilinear")

cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.015, aspect=35)
cb.set_label("Water Height (m)", color=TEXT2, fontsize=11, labelpad=10)
cb.ax.tick_params(colors=TEXT2, labelsize=9, length=3)
cb.outline.set_edgecolor(BORDER); cb.outline.set_linewidth(0.5)
cb.set_ticks([0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50])
cb.set_ticklabels(["0", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50 cm"])

ax.set_xlabel("Longitude", color=TEXT2, fontsize=10)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=10)
ax.set_title("URBAN WATER HEIGHT MODEL", color=TEXT, fontsize=12,
             fontweight="700", pad=10, loc="left")

# stats box
stats_text = (f"ABU DHABI FLOOD SIMULATION\n"
              f"Model:    DEM + Rainfall-Runoff\n"
              f"Precip:   {PRECIP_MM:.0f} mm  (runoff {runoff_coeff:.0%})\n"
              f"Flooded:  {flood_km2:.1f} km²\n"
              f"Max:      {depth.max():.2f} m\n"
              f"Volume:   {volume:,.0f} m³\n"
              f"Area:     {flood_km2 + (1-flooded.mean())*flood_km2/(flooded.mean()+1e-9)*0:.0f} km² ROI")
ax.text(0.02, 0.98, stats_text, transform=ax.transAxes, fontsize=9,
        fontfamily="monospace", fontweight="600", color=TEXT, va="top",
        bbox=dict(boxstyle="round,pad=0.5", facecolor=NAVY, edgecolor=BORDER, alpha=0.9))

fig.suptitle("ABU DHABI — URBAN FLOOD WATER HEIGHT SIMULATION",
             color=TEXT, fontsize=15, fontweight="800", x=0.02, ha="left", y=0.98)
fig.text(0.02, 0.955, f"DEM + {PRECIP_MM:.0f}mm precipitation  |  "
         f"{flood_km2:.1f} km² flooded  |  Max depth: {depth.max():.2f} m  |  "
         f"Volume: {volume:,.0f} m³",
         color=TEXT3, fontsize=9, ha="left")
fig.text(0.99, 0.005, "UAE FloodMap v3", color=TEXT3, fontsize=7, ha="right", alpha=0.4)

fig.savefig("outputs/abudhabi_water_height.png", dpi=200, bbox_inches="tight",
            facecolor=BG, pad_inches=0.15)
plt.close(fig)
L.info("Saved: abudhabi_water_height.png")

# ═══════════════════════════════════════════════════════════════════
# FIGURE 2: Street severity map — every road colored by water height
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 2: Street severity (this may take a moment for 60k+ roads)…")
fig, ax = plt.subplots(1, 1, figsize=(18, 14), facecolor=BG)
style(ax)
terrain_bg(ax)

# light depth background
masked2 = np.ma.masked_where(depth < 0.005, depth)
ax.imshow(masked2, cmap=DCMAP, vmin=0, vmax=0.5, extent=extent,
          aspect="equal", alpha=0.25, interpolation="bilinear")

# Collect road segments as LineCollection for performance
segments_by_class = {"dry": [], "low": [], "medium": [], "high": [], "critical": []}
for _, row in gdf.iterrows():
    geom = row.geometry
    if geom is None: continue
    cls = row.get("flood_class", "dry")
    lines = [geom] if geom.geom_type == "LineString" else (
        geom.geoms if geom.geom_type == "MultiLineString" else [])
    for line in lines:
        coords = list(line.coords)
        if len(coords) >= 2:
            segments_by_class[cls].append(coords)

# Draw dry first (bottom), critical last (top)
draw_order = [
    ("dry",      0.3, 0.20),
    ("low",      1.5, 0.85),
    ("medium",   2.0, 0.90),
    ("high",     2.5, 0.95),
    ("critical", 3.0, 1.00),
]
for cls, lw, alpha in draw_order:
    segs = segments_by_class.get(cls, [])
    if not segs: continue
    lc = LineCollection(segs, colors=STREET_COLORS[cls], linewidths=lw,
                        alpha=alpha, capstyle="round")
    ax.add_collection(lc)

ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.set_xlabel("Longitude", color=TEXT2, fontsize=10)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=10)
ax.set_title("STREET-LEVEL FLOOD SEVERITY", color=TEXT, fontsize=12,
             fontweight="700", pad=10, loc="left")

# Legend with km per severity
leg_items = []
for cls, lw, _ in draw_order:
    sub = gdf[gdf["flood_class"] == cls]
    km = sub["length_m"].sum() / 1000
    n = len(sub)
    if n > 0:
        label_map = {"dry":"Dry","low":"Low risk","medium":"Medium","high":"High risk","critical":"Critical"}
        leg_items.append(Line2D([0], [0], color=STREET_COLORS[cls], linewidth=max(lw, 1.5),
                                label=f"{label_map[cls]}  ({km:,.1f} km · {n:,} seg)"))

ax.legend(handles=leg_items, loc="lower left", fontsize=9, framealpha=0.9,
          facecolor=NAVY, edgecolor=BORDER, labelcolor=TEXT,
          title="Road Flood Severity", title_fontproperties={"weight": "bold", "size": 10})

# stats box
ax.text(0.02, 0.98,
        f"ROAD NETWORK FLOOD IMPACT\n"
        f"Total roads:   {summary['total_km']:,.1f} km  ({len(gdf):,} segments)\n"
        f"Affected:      {summary['flooded_km']:,.1f} km  ({summary['pct_flooded']:.1f}%)\n"
        f"Unaffected:    {summary['total_km']-summary['flooded_km']:,.1f} km",
        transform=ax.transAxes, fontsize=9, fontfamily="monospace", fontweight="600",
        color=TEXT, va="top",
        bbox=dict(boxstyle="round,pad=0.5", facecolor=NAVY, edgecolor=BORDER, alpha=0.9))

fig.suptitle("ABU DHABI — STREET-LEVEL FLOOD SEVERITY MAP",
             color=TEXT, fontsize=15, fontweight="800", x=0.02, ha="left", y=0.98)
fig.text(0.02, 0.955,
         f"{summary['flooded_km']:,.1f} km affected  |  "
         f"{summary['total_km']:,.1f} km total  |  {len(gdf):,} road segments  |  "
         f"Green=safe · Yellow=low · Orange=medium · Red=high/critical",
         color=TEXT3, fontsize=9, ha="left")
fig.text(0.99, 0.005, "UAE FloodMap v3", color=TEXT3, fontsize=7, ha="right", alpha=0.4)

fig.savefig("outputs/abudhabi_street_severity.png", dpi=200, bbox_inches="tight",
            facecolor=BG, pad_inches=0.15)
plt.close(fig)
L.info("Saved: abudhabi_street_severity.png")

# ═══════════════════════════════════════════════════════════════════
# FIGURE 3: Street depth — continuous color per road by max water height
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 3: Street depth continuous…")
fig, ax = plt.subplots(1, 1, figsize=(18, 14), facecolor=BG)
style(ax)
terrain_bg(ax)

# Draw roads colored continuously by max_depth_m
max_depths = gdf["max_depth_m"].values
# normalize to 0-1 for colormap
d_norm = np.clip(max_depths / 0.50, 0, 1)

# sort by depth so deeper roads draw on top
sort_idx = np.argsort(max_depths)
all_segments = []
all_colors = []

cmap = DCMAP
for idx in sort_idx:
    row = gdf.iloc[idx]
    geom = row.geometry
    if geom is None: continue
    d_val = d_norm[idx]
    color = cmap(d_val)
    lw = 0.3 + d_val * 3.0  # thicker = deeper
    lines = [geom] if geom.geom_type == "LineString" else (
        geom.geoms if geom.geom_type == "MultiLineString" else [])
    for line in lines:
        coords = list(line.coords)
        if len(coords) >= 2:
            all_segments.append(coords)
            all_colors.append(color)

lc = LineCollection(all_segments, colors=all_colors, linewidths=np.linspace(0.3, 3.0, len(all_segments)),
                    capstyle="round")
ax.add_collection(lc)

# add colorbar for street depth
import matplotlib.cm as mcm
sm = plt.cm.ScalarMappable(cmap=DCMAP, norm=plt.Normalize(vmin=0, vmax=0.50))
sm.set_array([])
cb = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.015, aspect=35)
cb.set_label("Max Water Height at Road (m)", color=TEXT2, fontsize=11, labelpad=10)
cb.ax.tick_params(colors=TEXT2, labelsize=9, length=3)
cb.outline.set_edgecolor(BORDER); cb.outline.set_linewidth(0.5)
cb.set_ticks([0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50])
cb.set_ticklabels(["0", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50 cm"])

ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.set_xlabel("Longitude", color=TEXT2, fontsize=10)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=10)
ax.set_title("STREET WATER HEIGHT — CONTINUOUS MODEL", color=TEXT, fontsize=12,
             fontweight="700", pad=10, loc="left")

# top 10 most affected roads
flooded_roads = gdf[gdf["max_depth_m"] > 0.01].nlargest(10, "max_depth_m")
if len(flooded_roads) > 0:
    table_text = "TOP AFFECTED ROADS\n" + "─" * 35 + "\n"
    for _, r in flooded_roads.iterrows():
        name = str(r.get("name", "Unnamed"))[:22]
        d_m = r["max_depth_m"]
        table_text += f"{name:22s}  {d_m*100:5.1f} cm\n"
    ax.text(0.02, 0.98, table_text, transform=ax.transAxes, fontsize=8,
            fontfamily="monospace", fontweight="500", color=TEXT, va="top",
            bbox=dict(boxstyle="round,pad=0.5", facecolor=NAVY, edgecolor=BORDER, alpha=0.9))

fig.suptitle("ABU DHABI — STREET WATER HEIGHT (CONTINUOUS MODEL)",
             color=TEXT, fontsize=15, fontweight="800", x=0.02, ha="left", y=0.98)
fig.text(0.02, 0.955,
         f"Every road colored by modeled water depth  |  "
         f"{len(gdf):,} segments  |  Max: {max_depths.max()*100:.1f} cm  |  "
         f"DEM + {PRECIP_MM:.0f}mm rainfall-runoff model",
         color=TEXT3, fontsize=9, ha="left")
fig.text(0.99, 0.005, "UAE FloodMap v3", color=TEXT3, fontsize=7, ha="right", alpha=0.4)

fig.savefig("outputs/abudhabi_street_depth.png", dpi=200, bbox_inches="tight",
            facecolor=BG, pad_inches=0.15)
plt.close(fig)
L.info("Saved: abudhabi_street_depth.png")

# ═══════════════════════════════════════════════════════════════════
L.info("═" * 60)
L.info(f"ALL DONE — 3 figures generated in outputs/")
L.info(f"  1. abudhabi_water_height.png    — DEM flood depth model")
L.info(f"  2. abudhabi_street_severity.png — roads green/yellow/orange/red")
L.info(f"  3. abudhabi_street_depth.png    — continuous depth per road")
L.info(f"Results: {flood_km2:.1f} km² flooded, {summary['flooded_km']:.1f}/{summary['total_km']:.1f} km roads")
L.info("═" * 60)
