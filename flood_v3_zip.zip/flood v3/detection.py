"""
╔══════════════════════════════════════════════════════════════════════╗
║   UAE FloodMap – Sentinel-1 Flood Detection                          ║
║                                                                      ║
║   Methodology                                                        ║
║   -----------                                                        ║
║   The flood signal in Sentinel-1 is a per-pixel DROP in backscatter   ║
║   between a pre-event and post-event acquisition: smooth standing    ║
║   water reflects C-band away from the satellite (specular geometry). ║
║                                                                      ║
║   We work on the change image                                        ║
║                                                                      ║
║         ΔSAR  =  min(ΔVV, ΔVH)   in dB                               ║
║                                                                      ║
║   instead of the absolute backscatter, then choose the cutoff        ║
║   automatically:                                                     ║
║                                                                      ║
║     1. Refined-Lee speckle filter on linear-power VV / VH            ║
║     2. Compute ΔVV, ΔVH, then ΔSAR = element-wise min                ║
║     3. AUTO-THRESHOLD via Otsu (1979) on the ΔSAR histogram          ║
║          - Bhattacharyya overlap test → trust the auto T only if     ║
║            the histogram is bimodal (BC < BHATTACHARYYA_MIN)         ║
║          - else fall back to a user/operator-supplied THRESHOLD_DB   ║
║     4. SEED MASK     = ΔSAR <  T_seed   (T_otsu − 2 dB; high conf)   ║
║        CANDIDATE SET = ΔSAR <  T_grow   (T_otsu        ; permissive) ║
║     5. REGION GROW the seed inside the candidate set with binary     ║
║        propagation — adopts ambiguous pixels only if connected to a  ║
║        confident core, killing isolated speckle false positives.     ║
║     6. Apply spatial cleanups: permanent water mask, slope ≤ T°,     ║
║        binary closing 3×3, min connected-component area.             ║
║     7. Compute a CONFIDENCE raster (0..1) from the change magnitude: ║
║          conf = clip( (|ΔSAR| − |T_otsu|) / 8 dB, 0, 1 )             ║
║     8. Compute WATER DEPTH from |ΔSAR|:                              ║
║          depth_m = clip( (|ΔSAR| − |T_otsu|) × s, 0, cap )           ║
║                                                                      ║
║   References                                                         ║
║     Otsu (1979); Lee (1980); Martinis et al. (2009);                 ║
║     Twele et al. (2016); Markert et al. (2018, SERVIR Mekong);       ║
║     Chini et al. (2017); Bauer-Marschallinger et al. (2022).         ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging
import numpy as np
from scipy.ndimage import (uniform_filter, label, zoom,
                           binary_closing, binary_fill_holes,
                           binary_propagation)
from config import (SPECKLE_WINDOW, VV_VALID_MIN_DB, VV_VALID_MAX_DB,
                    MAX_FLOOD_SLOPE_DEG, MIN_FLOOD_AREA_M2, RESOLUTION_M,
                    THRESHOLD_DB, DEPTH_SCALE_M_PER_DB, MAX_WATER_DEPTH_M,
                    AUTO_THRESHOLD, BHATTACHARYYA_MIN, SEED_OFFSET_DB)

L = logging.getLogger("flood.detect")


# ── Conversion / filtering ───────────────────────────────────────────
def to_db(linear):
    return 10.0 * np.log10(np.clip(linear, 1e-10, None))


def refined_lee(img, size=SPECKLE_WINDOW):
    """Refined-Lee speckle filter on linear-power SAR."""
    img = img.astype(np.float64)
    mean = uniform_filter(img, size)
    sqr_mean = uniform_filter(img * img, size)
    var = np.clip(sqr_mean - mean * mean, 0, None)
    overall_var = float(np.var(img))
    if overall_var < 1e-12:
        return img.astype(np.float32)
    weight = var / (var + overall_var)
    return (mean + weight * (img - mean)).astype(np.float32)


def _valid(vv_db):
    return np.isfinite(vv_db) & (vv_db > VV_VALID_MIN_DB) & (vv_db < VV_VALID_MAX_DB)


def _prep_db(linear):
    return to_db(refined_lee(linear))


def _resample_like(arr, shape):
    if arr is None:
        return None
    if arr.shape == shape:
        return arr
    zy, zx = shape[0] / arr.shape[0], shape[1] / arr.shape[1]
    return zoom(arr.astype(np.float32), (zy, zx), order=0)


def _slope_deg(dem, pixel_m):
    if dem is None:
        return None
    gy, gx = np.gradient(dem.astype(np.float32), pixel_m, pixel_m)
    return np.degrees(np.arctan(np.hypot(gx, gy)))


def pixel_size_m(bbox, shape):
    """Average pixel size in metres for a (h, w) raster covering a WGS84 bbox."""
    from pyproj import Transformer
    h, w = shape[0], shape[1]
    cx = 0.5 * (bbox.min_x + bbox.max_x)
    cy = 0.5 * (bbox.min_y + bbox.max_y)
    base = 32600 if cy >= 0 else 32700
    epsg = base + int((cx + 180) // 6) + 1
    t = Transformer.from_crs("EPSG:4326", f"EPSG:{epsg}", always_xy=True)
    x0, y0 = t.transform(bbox.min_x, bbox.min_y)
    x1, y1 = t.transform(bbox.max_x, bbox.max_y)
    return float(np.mean([(x1 - x0) / w, (y1 - y0) / h]))


# ── Statistical thresholding ─────────────────────────────────────────
def _otsu_on_change(values, n_bins=256, lo=-25.0, hi=10.0):
    """Otsu (1979) optimal split point for a 1-D distribution.
    Returns (threshold, between_var, within_var, hist, edges)."""
    values = values[np.isfinite(values)]
    if values.size < 1000:
        return None, 0.0, 1.0, None, None
    # ΔSAR has a long flat tail; clip aggressively to focus on the body.
    hist, edges = np.histogram(np.clip(values, lo, hi), bins=n_bins,
                               range=(lo, hi))
    p = hist.astype(np.float64) / max(hist.sum(), 1)
    centers = 0.5 * (edges[:-1] + edges[1:])

    omega = np.cumsum(p)
    mu    = np.cumsum(p * centers)
    mu_T  = mu[-1]

    denom = omega * (1.0 - omega)
    denom[denom == 0] = np.nan
    sigma_b2 = (mu_T * omega - mu) ** 2 / denom
    # Degenerate distribution (e.g. NF-02 pre/pre pair where ΔSAR ≡ 0):
    # every entry of sigma_b2 is NaN. Otsu has nothing to maximise — we
    # bail out gracefully so the caller falls back to the manual threshold.
    if not np.any(np.isfinite(sigma_b2)):
        return None, 0.0, 1.0, hist, edges
    k = int(np.nanargmax(sigma_b2))
    thr = float(centers[k])

    total_var = float(np.var(values))
    between   = float(np.nanmax(sigma_b2))
    within    = max(total_var - between, 1e-9)
    return thr, between, within, hist, edges


def _bhattacharyya(values, thr, n_bins=128):
    """Bhattacharyya coefficient between the two sub-distributions split at
    `thr`. ≈ 0 → well-separated bimodal (good Otsu); → 1 → unimodal."""
    values = values[np.isfinite(values)]
    a = values[values <= thr]
    b = values[values >  thr]
    if a.size < 100 or b.size < 100:
        return 1.0
    lo = float(min(a.min(), b.min()))
    hi = float(max(a.max(), b.max()))
    edges = np.linspace(lo, hi, n_bins + 1)
    pa, _ = np.histogram(a, bins=edges); pa = pa / max(pa.sum(), 1)
    pb, _ = np.histogram(b, bins=edges); pb = pb / max(pb.sum(), 1)
    return float(np.sum(np.sqrt(pa * pb)))


# ── Main detector ────────────────────────────────────────────────────
def detect_flood(before, after,
                 permanent_water=None, dem=None,
                 threshold_db=THRESHOLD_DB,
                 max_slope_deg=MAX_FLOOD_SLOPE_DEG,
                 min_area_m2=MIN_FLOOD_AREA_M2,
                 depth_scale_m_per_db=DEPTH_SCALE_M_PER_DB,
                 max_depth_m=MAX_WATER_DEPTH_M,
                 pixel_m=RESOLUTION_M,
                 auto_threshold=AUTO_THRESHOLD,
                 seed_offset_db=SEED_OFFSET_DB,
                 bhattacharyya_min=BHATTACHARYYA_MIN,
                 regime=None):
    """ΔSAR change-detection flood mapper with Otsu auto-threshold,
    region-growing and per-pixel confidence + depth.

    Parameters
    ----------
    before, after : (H, W, 2) linear-power VV/VH stacks (download_s1).
    permanent_water : optional binary mask, True = exclude.
    dem : optional DEM in metres for slope-shadow exclusion.
    threshold_db : manual fallback threshold if auto-Otsu unimodal or off.
    auto_threshold : if True, pick T from the data via Otsu on ΔSAR.
    seed_offset_db : T_seed = T_otsu + seed_offset_db (negative, more strict).

    Returns
    -------
    dict with keys
        mask        binary flood mask (uint8)
        depth       per-pixel water depth in metres (float32)
        confidence  per-pixel detection confidence in [0, 1] (float32)
        change      ΔSAR = min(ΔVV, ΔVH) in dB (float32)
        change_vv   ΔVV in dB (float32)
        change_vh   ΔVH in dB (float32)
        post_db     post-event VV in dB (float32)
        info        run config + per-stage pixel accounting + Otsu diag
    """
    # ── Regime-aware default resolution (Flood request #5) ─────────
    # When ``regime`` is None the legacy hardcoded values flow through
    # unchanged — UAE byte-equal regression is guaranteed. When regime
    # is provided, the helper picks (BC_min, slope_max) for that regime,
    # but ONLY overrides args the caller left at the legacy default
    # (sentinel-style). Operator escape hatches:
    #   - FLOOD_DETECT_BC_OVERRIDE=<float>
    #   - FLOOD_DETECT_SLOPE_OVERRIDE=<float>
    regime_used = None
    if regime is not None:
        try:
            from precipitation import regime_detection_defaults
            bc_default, slope_default = regime_detection_defaults(regime)
            # Only override if the caller is using the legacy value
            if bhattacharyya_min == BHATTACHARYYA_MIN:
                bhattacharyya_min = bc_default
            if max_slope_deg == MAX_FLOOD_SLOPE_DEG:
                max_slope_deg = slope_default
            regime_used = regime
        except Exception as _e:
            L.warning(f"detect_flood regime resolve failed ({_e}); "
                      f"falling back to legacy defaults")
            regime_used = None
    # Operator escape hatches (apply *after* regime resolution so they
    # always win over both UAE and regime-aware defaults).
    import os as _os
    bc_env = _os.environ.get("FLOOD_DETECT_BC_OVERRIDE", "").strip()
    if bc_env:
        try:    bhattacharyya_min = float(bc_env)
        except Exception: pass
    slope_env = _os.environ.get("FLOOD_DETECT_SLOPE_OVERRIDE", "").strip()
    if slope_env:
        try:    max_slope_deg = float(slope_env)
        except Exception: pass

    bvv, bvh = before[:, :, 0], before[:, :, 1]
    avv, avh = after[:, :,  0], after[:, :,  1]

    db_b_vv = _prep_db(bvv); db_a_vv = _prep_db(avv)
    db_b_vh = _prep_db(bvh); db_a_vh = _prep_db(avh)

    diff_vv = db_a_vv - db_b_vv
    diff_vh = db_a_vh - db_b_vh
    diff    = np.minimum(diff_vv, diff_vh).astype(np.float32)
    valid   = _valid(db_b_vv) & _valid(db_a_vv)

    # ── AUTO-THRESHOLD on the ΔSAR distribution ─────────────────────
    auto_info = {"requested": bool(auto_threshold), "applied": "manual"}
    T = float(threshold_db)
    if auto_threshold:
        sample = diff[valid & (diff < 5.0)]   # keep room around 0
        otsu_T, between, within, _, _ = _otsu_on_change(sample)
        if otsu_T is not None:
            bc = _bhattacharyya(sample, otsu_T)
            bcv_ratio = between / (between + within)
            auto_info.update({
                "otsu_db":       round(otsu_T, 3),
                "bhattacharyya": round(bc, 3),
                "bcv_ratio":     round(bcv_ratio, 3),
                "bimodal":       bool(bc < bhattacharyya_min and
                                      bcv_ratio > 0.10 and otsu_T < -1.0),
            })
            if auto_info["bimodal"]:
                T = float(otsu_T); auto_info["applied"] = "otsu"
    auto_info["T_db"]      = round(T, 3)
    auto_info["T_seed_db"] = round(T + seed_offset_db, 3)

    # ── Seed + candidate sets, region growing ───────────────────────
    seed_mask = (diff < (T + seed_offset_db)) & valid    # high confidence
    cand_mask = (diff < T) & valid                        # permissive
    n_seed = int(seed_mask.sum())
    n_cand = int(cand_mask.sum())

    # Region growing: keep candidate pixels only if they are 4-connected
    # to a seed. Eliminates isolated speckle while preserving the natural
    # extent of every real flood patch.
    if n_seed > 0:
        mask = binary_propagation(seed_mask, mask=cand_mask)
    else:
        mask = cand_mask
    n_after_grow = int(mask.sum())

    # ── Permanent-water exclusion ───────────────────────────────────
    n_after_pw = n_after_grow
    if permanent_water is not None:
        pw = _resample_like(permanent_water, mask.shape).astype(bool)
        mask &= ~pw
        n_after_pw = int(mask.sum())

    # ── Slope filter ────────────────────────────────────────────────
    n_after_slope = n_after_pw
    if dem is not None and max_slope_deg is not None:
        slope = _slope_deg(_resample_like(dem, mask.shape), pixel_m=pixel_m)
        mask &= ~(slope > max_slope_deg)
        n_after_slope = int(mask.sum())

    # ── Light morphology + min-area filter ─────────────────────────
    mask = binary_closing(mask, structure=np.ones((3, 3)), iterations=1)
    mask = binary_fill_holes(mask)
    px_area_m2 = pixel_m * pixel_m
    min_px = max(1, int(round(min_area_m2 / px_area_m2)))
    lbl, n = label(mask)
    if n > 0:
        sizes = np.bincount(lbl.ravel()); sizes[0] = 0
        keep = sizes >= min_px
        mask = keep[lbl]
    mask = mask.astype(np.uint8)
    n_final = int(mask.sum())

    # ── Confidence raster (0..1) ───────────────────────────────────
    excess_db  = np.maximum(0.0, -diff - (-T))
    confidence = np.clip(excess_db / 8.0, 0.0, 1.0).astype(np.float32)
    confidence = np.where(mask.astype(bool), confidence, 0.0)

    # ── Water depth from |ΔSAR| above threshold ─────────────────────
    depth = np.clip(excess_db * depth_scale_m_per_db, 0.0, max_depth_m)
    depth = np.where(mask.astype(bool), depth, 0.0).astype(np.float32)

    # ── Histograms + summary stats for the UI ──────────────────────
    flooded_diff  = diff[mask.astype(bool)]
    flooded_depth = depth[mask.astype(bool)]
    flooded_conf  = confidence[mask.astype(bool)]

    diff_finite_vis = diff[valid & (diff < 5.0) & (diff > -25.0)]
    diff_hist_counts, diff_hist_edges = np.histogram(
        diff_finite_vis, bins=80, range=(-25.0, 5.0))
    if flooded_depth.size:
        depth_hist_counts, depth_hist_edges = np.histogram(
            flooded_depth, bins=40,
            range=(0.0, float(max(0.05, np.percentile(flooded_depth, 99)))))
    else:
        depth_hist_counts = np.zeros(1, dtype=int)
        depth_hist_edges  = np.array([0.0, 0.05])

    info = {
        "method":          "ΔSAR change-only · Otsu auto-threshold · region growing",
        "auto_threshold":  auto_info,
        "threshold_db_used":         round(T, 3),
        "seed_threshold_db_used":    round(T + seed_offset_db, 3),
        "depth_scale_m_per_db":      depth_scale_m_per_db,
        "max_depth_m":               max_depth_m,
        "max_slope_deg":             max_slope_deg,
        "min_area_m2":               min_area_m2,
        "min_component_px":          min_px,
        "pixel_m":                   round(pixel_m, 2),
        "regime":                    regime_used,
        "bhattacharyya_min":         round(float(bhattacharyya_min), 3),
        "stages": {
            "seed_pixels":       n_seed,
            "candidate_pixels":  n_cand,
            "after_growing":     n_after_grow,
            "after_perm_water":  n_after_pw,
            "after_slope":       n_after_slope,
            "final":             n_final,
        },
        "final_area_km2":  round(n_final * px_area_m2 / 1e6, 4),
        "depth_m": {
            "mean":   round(float(flooded_depth.mean()), 3) if flooded_depth.size else 0.0,
            "median": round(float(np.median(flooded_depth)), 3) if flooded_depth.size else 0.0,
            "p90":    round(float(np.percentile(flooded_depth, 90)), 3) if flooded_depth.size else 0.0,
            "max":    round(float(flooded_depth.max()), 3) if flooded_depth.size else 0.0,
        },
        "confidence": {
            "mean":   round(float(flooded_conf.mean()), 3) if flooded_conf.size else 0.0,
            "p90":    round(float(np.percentile(flooded_conf, 90)), 3) if flooded_conf.size else 0.0,
        },
        "change_db_in_flood": {
            "mean":   round(float(flooded_diff.mean()), 3) if flooded_diff.size else 0.0,
            "p90":    round(float(np.percentile(flooded_diff, 10)), 3) if flooded_diff.size else 0.0,
            "max":    round(float(flooded_diff.min()), 3) if flooded_diff.size else 0.0,
        },
        # Histograms — small enough to send each poll if needed.
        "histograms": {
            "delta_sar": {"counts": diff_hist_counts.tolist(),
                          "edges":  diff_hist_edges.tolist()},
            "depth":     {"counts": depth_hist_counts.tolist(),
                          "edges":  depth_hist_edges.tolist()},
        },
    }

    L.info(f"ΔSAR detector: T={T:.2f} dB ({auto_info['applied']}, "
           f"BC={auto_info.get('bhattacharyya', '–')}, "
           f"Otsu={auto_info.get('otsu_db', '–')})  "
           f"regime={regime_used or 'legacy'} "
           f"(BC_min={bhattacharyya_min:.2f}, slope_max={max_slope_deg}°) → "
           f"seed={n_seed:,} cand={n_cand:,} grown={n_after_grow:,} → "
           f"perm-water={n_after_pw:,} slope={n_after_slope:,} → "
           f"final={n_final:,} px ({info['final_area_km2']} km²)  "
           f"depth median={info['depth_m']['median']} m, "
           f"max={info['depth_m']['max']} m")

    return {
        "mask":        mask,
        "depth":       depth,
        "confidence":  confidence,
        "change":      diff,
        "change_vv":   diff_vv.astype(np.float32),
        "change_vh":   diff_vh.astype(np.float32),
        "post_db":     db_a_vv.astype(np.float32),
        "info":        info,
    }


# ── Back-compat shims ────────────────────────────────────────────────
def run_all_detections(before, after, threshold_db=None, **_):
    det = detect_flood(before, after,
                       threshold_db=threshold_db or THRESHOLD_DB)
    return {"threshold": {"mask": det["mask"], "change": det["change"],
                          "post_db": det["post_db"], "info": det["info"]}}


def lee_filter(img, size=SPECKLE_WINDOW):
    return refined_lee(img, size)
