"""
╔══════════════════════════════════════════════════════════════════════╗
║       UAE FloodMap – DEM + Rainfall Flood Simulation Engine         ║
║   FwDET-style depth (Cohen et al. 2019) + hydrological diagnostics ║
╚══════════════════════════════════════════════════════════════════════╝

Physical model (FwDET — Floodwater Depth Estimation Tool)
──────────────────────────────────────────────────────────
For each flooded pixel, the *local water-surface elevation* equals the
elevation of the nearest DRY pixel on the flood boundary (the water had
to rise to that level in order to spill out).  The water depth at the
pixel is therefore

    depth(x,y) = max(0, water_surface(x,y) - DEM(x,y))

where water_surface is obtained by smoothing the boundary DEM
interpolated across the flood mask.  This gives a physically realistic
inundation surface without requiring a coupled hydraulic solver.

Reference:  Cohen, Brakenridge & Kettner, 2019.
   "Estimating floodwater depths from flood inundation maps and
    topography". JAWRA 55(4): 847-858.

Rainfall is used here only as a sanity-check statistic — we compare the
DEM-inferred flood volume against the catchment runoff volume
P · C · A_catchment and report both.  We never force the depths to a
rainfall-derived magnitude (the old code did that and hit the cap on
every pixel whenever the flood patch was small relative to the ROI).
"""
import logging, os, numpy as np
from scipy.ndimage import (gaussian_filter, distance_transform_edt,
                           binary_dilation, binary_erosion, label,
                           uniform_filter)
from config import (DEM_SMOOTHING_PX, MAX_WATER_DEPTH_M, RESOLUTION_M,
                    RUNOFF_COEFF)

L = logging.getLogger("flood.sim")


def flow_accumulation(dem, smooth_sigma=2):
    """D8 flow accumulation — diagnostic only."""
    dem_s = gaussian_filter(dem, sigma=smooth_sigma)
    h, w = dem_s.shape
    acc = np.ones((h, w), dtype=np.float64)

    padded = np.pad(dem_s, 1, mode='edge')
    flow_dir = np.zeros((h, w), dtype=int)
    dy = [-1, -1, -1,  0, 0,  1, 1, 1]
    dx = [-1,  0,  1, -1, 1, -1, 0, 1]
    dist = [1.414, 1.0, 1.414, 1.0, 1.0, 1.414, 1.0, 1.414]

    best_slope = None
    for i in range(8):
        neighbor = padded[1 + dy[i]:h + 1 + dy[i], 1 + dx[i]:w + 1 + dx[i]]
        slope = (dem_s - neighbor) / dist[i]
        if i == 0:
            best_slope = slope.copy(); flow_dir[:] = 0
        else:
            update = slope > best_slope
            best_slope[update] = slope[update]
            flow_dir[update] = i

    flat_idx = np.argsort(-dem_s.ravel())
    flat_acc = acc.ravel()
    for idx in flat_idx:
        y, x = divmod(idx, w)
        d = flow_dir[y, x]
        ny, nx = y + dy[d], x + dx[d]
        if 0 <= ny < h and 0 <= nx < w:
            flat_acc[ny * w + nx] += flat_acc[idx]
    return flat_acc.reshape(h, w)


def _fwdet_depth(flood_mask, dem, max_depth=MAX_WATER_DEPTH_M,
                 surface_smooth_px=5):
    """Core FwDET depth field.

    For each connected flooded region, the water-surface elevation is
    taken from the DRY neighbour ring (the pixels just outside the
    flood) and propagated inwards via nearest-neighbour; the result is
    smoothed with a moving average to damp noise from DEM outliers.
    """
    mask = flood_mask.astype(bool)
    depth = np.zeros_like(dem, dtype=np.float32)
    if mask.sum() == 0:
        return depth

    # 1-pixel ring of DRY pixels touching the flood — the water *had* to
    # rise to their elevation before spilling outside.
    dilated  = binary_dilation(mask)
    ring_dry = dilated & (~mask)
    if ring_dry.sum() < 5:
        # degenerate (flood touches DEM border): use the flood edge itself
        ring_dry = mask & (~binary_erosion(mask))

    # Component-aware surface construction.
    lbl, n = label(mask)
    if n == 0:
        return depth

    # For each component, build its own water surface from its own ring,
    # so two disjoint floods at different elevations don't contaminate
    # each other.
    for c in range(1, n + 1):
        comp = (lbl == c)
        # ring of this component = dry pixels adjacent to THIS component
        comp_ring = binary_dilation(comp) & (~mask)
        if comp_ring.sum() < 3:
            comp_ring = comp & (~binary_erosion(comp))
        if comp_ring.sum() == 0:
            continue

        # Nearest-dry-ring DEM via Euclidean distance transform with return_indices.
        # distance_transform_edt on the NON-ring pixels, asking for the
        # index of the nearest ring pixel.
        src = np.where(comp_ring)
        if len(src[0]) == 0:
            continue
        # Build a label array where ring-pixels carry their DEM value,
        # others are NaN.  We use distance_transform_edt on ~ring with
        # return_indices=True to find the nearest ring pixel per cell.
        not_ring = ~comp_ring
        _, (iy, ix) = distance_transform_edt(not_ring, return_indices=True)
        surface = dem[iy, ix]  # each pixel inherits its nearest ring DEM
        # Smooth to kill DEM noise
        if surface_smooth_px > 1:
            surface = uniform_filter(surface.astype(np.float32),
                                     size=surface_smooth_px)
        # Local component depth
        d_comp = np.clip(surface - dem, 0.0, max_depth)
        depth[comp] = d_comp[comp].astype(np.float32)

    # Kill tiny fringe depths (< 2 cm noise)
    depth[depth < 0.02] = 0.0
    return depth


def rainfall_runoff_depth(flood_mask, dem, precip_total_mm,
                          backscatter_diff=None,
                          runoff_coeff=RUNOFF_COEFF,
                          surface_smooth_px=None):
    """FwDET depth with rainfall sanity-check and volume conservation gate.

    Returns (depth, stats).  `backscatter_diff` is kept in the signature
    for back-compat but not used — the depth is set purely by DEM/mask
    geometry, which is more defensible than SAR-brightness-to-depth
    regression.

    Volume conservation gate (Cohen 2019 §3): if the FwDET-integrated
    depth volume exceeds 1.05 × the catchment runoff volume, the depth
    field is rescaled so V_flood ≤ V_runoff × 1.05.  Gate is controlled
    by env-knob FLOOD_FWDET_VOLUME_CHECK (default "1"; set "0" to disable).
    The 1.05 tolerance accounts for DEM edge effects at the boundary ring.

    Smoothing kernel (request #8 / Cohen 2019 §2.3): resolved in order:
      1. FLOOD_FWDET_SMOOTH_PX env-knob (integer; rollback to legacy 9).
      2. surface_smooth_px kwarg (explicit caller override).
      3. Resolution-aware default: 3 px at ≤ 20 m, 2 px at ≤ 50 m, 1 above.
    """
    # ── Resolve surface smoothing ────────────────────────────────────────
    _env_spx = os.environ.get("FLOOD_FWDET_SMOOTH_PX")
    if _env_spx is not None:
        surface_smooth_px = max(1, int(_env_spx))
    elif surface_smooth_px is None:
        # Resolution-aware default: 3 px at ≤ 20 m, 2 px at ≤ 50 m, 1 above.
        if RESOLUTION_M <= 20:
            surface_smooth_px = 3
        elif RESOLUTION_M <= 50:
            surface_smooth_px = 2
        else:
            surface_smooth_px = 1

    mask = flood_mask.astype(bool)
    if mask.sum() == 0:
        return np.zeros_like(dem, dtype=np.float32), {
            "max_depth_m": 0, "mean_depth_m": 0, "median_depth_m": 0,
            "p90_depth_m": 0, "volume_m3": 0, "flooded_km2": 0,
            "depth_volume_m3": 0.0,
            "runoff_volume_m3": 0.0,
            "volume_conservation_factor": 1.0,
            "volume_overshoot_ratio": None,
            "simulation": "FwDET (no flood pixels)"}

    dem_s = gaussian_filter(dem.astype(np.float32),
                            sigma=max(DEM_SMOOTHING_PX, 1))
    depth = _fwdet_depth(mask, dem_s, max_depth=MAX_WATER_DEPTH_M,
                         surface_smooth_px=surface_smooth_px)

    h, w = dem.shape
    pixel_area = RESOLUTION_M * RESOLUTION_M
    catchment_area = h * w * pixel_area
    flood_area     = mask.sum() * pixel_area

    # Sanity-check: runoff volume that *would* reach the mask if 100 % of
    # the ROI drained into it.  Actual flood volume will usually be a
    # fraction of this (most runoff flows out of the ROI).
    V_runoff = (precip_total_mm * 1e-3) * runoff_coeff * catchment_area
    V_flood  = float(depth.sum()) * pixel_area

    # ── Volume conservation gate (Cohen 2019 §3 / NEH-630 §10.3) ────────
    # When FLOOD_FWDET_VOLUME_CHECK != "0", enforce V_flood ≤ 1.05·V_runoff.
    _vol_check = os.environ.get("FLOOD_FWDET_VOLUME_CHECK", "1")
    scale = 1.0
    if _vol_check != "0" and V_flood > V_runoff * 1.05 and V_flood > 0 and V_runoff > 0:
        scale = (V_runoff * 1.05) / V_flood
        L.warning(
            f"[FwDET volume check] V_flood={V_flood:.0f} m³ > 1.05·V_runoff="
            f"{V_runoff*1.05:.0f} m³ (×{1/scale:.2f} overshoot) — "
            f"rescaling depth by {scale:.4f} (Cohen 2019 §3 conservation)"
        )
        depth = (depth * scale).astype(np.float32)
        V_flood = float(depth.sum()) * pixel_area   # recompute after rescale

    vals = depth[mask & (depth > 0)]
    stats = {
        "max_depth_m":    float(vals.max())    if vals.size else 0.0,
        "mean_depth_m":   float(vals.mean())   if vals.size else 0.0,
        "median_depth_m": float(np.median(vals)) if vals.size else 0.0,
        "p90_depth_m":    float(np.percentile(vals, 90)) if vals.size else 0.0,
        "volume_m3":      V_flood,
        "runoff_volume_m3": round(V_runoff, 1),
        "flooded_km2":    round(flood_area / 1e6, 4),
        "catchment_km2":  round(catchment_area / 1e6, 4),
        "total_precip_mm": float(precip_total_mm),
        "runoff_coeff":   float(runoff_coeff),
        "depth_volume_m3":            round(V_flood, 1),
        "volume_conservation_factor": round(scale, 4),
        "volume_overshoot_ratio":     round(V_flood / V_runoff, 3) if V_runoff > 0 else None,
        "simulation":     "FwDET (Cohen et al. 2019) — DEM-boundary water surface",
    }
    L.info(f"Depth (FwDET): max={stats['max_depth_m']:.2f}m, "
           f"mean={stats['mean_depth_m']:.2f}m, "
           f"p90={stats['p90_depth_m']:.2f}m, "
           f"V_flood={V_flood:.0f}m³, V_runoff={V_runoff:.0f}m³, "
           f"scale={scale:.4f}, smooth_px={surface_smooth_px}, "
           f"flooded={stats['flooded_km2']:.2f} km²")
    return depth, stats
