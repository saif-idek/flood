#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║       UAE FloodMap – Abu Dhabi 25 km × 25 km End-to-End Test              ║
║   Tests the full pipeline: Precip → SAR → DEM → Detection → Depth →      ║
║   Streets, using the April 2024 UAE flood event                           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
import sys, os, time, json, logging, traceback
import numpy as np

# ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s")
L = logging.getLogger("test.abudhabi")

from config import *

# ── Abu Dhabi 25 km × 25 km bbox ─────────────────────────────────────
# Centered on 24.45°N, 54.40°E — covers downtown, Corniche, Yas, Saadiyat
BBOX_COORDS = [54.2792, 24.3351, 54.5210, 24.5649]  # [W, S, E, N]

# April 2024 UAE mega-flood event dates
# S1 revisit is 12 days; narrow windows to catch actual acquisitions
PARAMS = {
    "before_start": "2024-04-01",
    "before_end":   "2024-04-14",
    "after_start":  "2024-04-16",
    "after_end":    "2024-04-30",
}

def check(label, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    sym = "✓" if condition else "✗"
    msg = f"  [{status}] {sym} {label}"
    if detail:
        msg += f"  →  {detail}"
    print(msg)
    if not condition:
        L.warning(f"CHECK FAILED: {label} {detail}")
    return condition


def main():
    from sentinelhub import BBox, CRS, bbox_to_dimensions

    bbox = BBox(bbox=BBOX_COORDS, crs=CRS.WGS84)
    size = bbox_to_dimensions(bbox, resolution=RESOLUTION_M)
    passed = 0
    total = 0

    print("=" * 70)
    print("  UAE FloodMap – Abu Dhabi 25×25 km Test")
    print(f"  BBox: {BBOX_COORDS}")
    print(f"  Grid: {size[0]} × {size[1]} px  @ {RESOLUTION_M}m resolution")
    print(f"  Before: {PARAMS['before_start']} → {PARAMS['before_end']}")
    print(f"  After:  {PARAMS['after_start']} → {PARAMS['after_end']}")
    print("=" * 70)

    # ── ROI Area ──────────────────────────────────────────────────────
    from pyproj import Transformer
    t = Transformer.from_crs("EPSG:4326", "EPSG:32640", always_xy=True)
    x1, y1 = t.transform(bbox.min_x, bbox.min_y)
    x2, y2 = t.transform(bbox.max_x, bbox.max_y)
    roi_km2 = abs(x2 - x1) * abs(y2 - y1) / 1e6
    total += 1; passed += check("ROI area ~625 km²", 580 < roi_km2 < 680, f"{roi_km2:.1f} km²")

    # ══════════════════════════════════════════════════════════════════
    # 1. PRECIPITATION
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 1: Precipitation (Open-Meteo ERA5) ──")
    t0 = time.time()
    from downloader import download_precipitation_era5
    from precipitation import analyse_precipitation, precipitation_risk_score

    precip_data = download_precipitation_era5(bbox, PARAMS["after_end"], lookback_days=21)
    analysis = analyse_precipitation(precip_data)
    analysis["risk_score"] = precipitation_risk_score(analysis)
    dt_precip = time.time() - t0

    total += 1; passed += check("Precip data returned", len(precip_data["dates"]) > 0, f"{len(precip_data['dates'])} days")
    total += 1; passed += check("Total precip > 0 mm", analysis["total_mm"] > 0, f"{analysis['total_mm']:.1f} mm")
    total += 1; passed += check("Peak day identified", analysis["peak_day_mm"] > 0, f"{analysis['peak_day_mm']:.1f} mm on {analysis.get('peak_day_date','?')}")
    total += 1; passed += check("Risk score computed", 0 <= analysis["risk_score"] <= 100, f"score = {analysis['risk_score']}")
    print(f"  ⏱  Precipitation: {dt_precip:.1f}s")

    # ══════════════════════════════════════════════════════════════════
    # 2. SAR DOWNLOAD
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 2: Sentinel-1 SAR Download ──")
    from downloader import download_s1

    t0 = time.time()
    before = download_s1(bbox, PARAMS["before_start"], PARAMS["before_end"])
    dt_before = time.time() - t0
    total += 1; passed += check("Before SAR shape", before.ndim == 3 and before.shape[2] == 2, f"{before.shape}")
    total += 1; passed += check("Before SAR has data", before.max() > 0, f"range [{before.min():.4f}, {before.max():.4f}]")
    print(f"  ⏱  Before SAR: {dt_before:.1f}s")

    t0 = time.time()
    after = download_s1(bbox, PARAMS["after_start"], PARAMS["after_end"])
    dt_after = time.time() - t0
    total += 1; passed += check("After SAR shape", after.shape == before.shape, f"{after.shape}")
    total += 1; passed += check("After SAR has data", after.max() > 0, f"range [{after.min():.4f}, {after.max():.4f}]")
    print(f"  ⏱  After SAR: {dt_after:.1f}s")

    # ══════════════════════════════════════════════════════════════════
    # 3. AUXILIARY: DEM + WATER MASK
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 3: Auxiliary Data (DEM + Water Mask) ──")
    from downloader import download_dem, download_water_mask
    target = before.shape[:2]

    t0 = time.time()
    dem = download_dem(bbox, target)
    dt_dem = time.time() - t0
    total += 1; passed += check("DEM shape matches SAR", dem.shape == target, f"{dem.shape}")
    total += 1; passed += check("DEM has valid elevations", dem.max() > dem.min(), f"range [{dem.min():.1f}, {dem.max():.1f}] m")
    print(f"  ⏱  DEM: {dt_dem:.1f}s")

    water_mask = None
    try:
        t0 = time.time()
        water_mask, ndwi = download_water_mask(bbox, PARAMS["before_start"], PARAMS["before_end"], target)
        dt_wm = time.time() - t0
        total += 1; passed += check("Water mask shape", water_mask.shape == target, f"{water_mask.shape}")
        print(f"  ⏱  Water mask: {dt_wm:.1f}s, {water_mask.sum()} permanent water px")
    except Exception as e:
        print(f"  [SKIP] Water mask: {e}")

    # ══════════════════════════════════════════════════════════════════
    # 4. FLOOD DETECTION
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 4: Flood Detection (5 methods) ──")
    from detection import run_all_detections

    t0 = time.time()
    detections = run_all_detections(before, after,
        threshold_db=THRESHOLD_DB, zscore_cutoff=ZSCORE_CUTOFF,
        ensemble_votes=ENSEMBLE_MIN_VOTES)
    dt_det = time.time() - t0

    total += 1; passed += check("5 detection methods", len(detections) == 5, f"got {len(detections)}: {list(detections.keys())}")
    for name, det in detections.items():
        m = det["mask"]
        pct = 100 * m.mean()
        km2 = roi_km2 * m.mean()
        total += 1; passed += check(f"{name}: valid mask", m.shape == target and m.dtype == np.uint8, f"{pct:.2f}% = {km2:.2f} km²")
    total += 1; passed += check("Ensemble has confidence", "confidence" in detections["ensemble"], "")
    print(f"  ⏱  Detection: {dt_det:.1f}s")

    # ══════════════════════════════════════════════════════════════════
    # 5. POST-PROCESSING
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 5: Post-Processing ──")
    from postprocessing import clean_mask
    from exporter import save_mask, save_flood_shapefile

    t0 = time.time()
    cleaned_masks = {}
    for name, det in detections.items():
        cm, info = clean_mask(det["mask"], water_mask,
            dem=dem if name == "ensemble" else None,
            max_slope=30 if name == "ensemble" else None)
        cleaned_masks[name] = cm
        save_mask(cm, bbox, os.path.join(OUTPUT_DIR, f"flood_{name}.tif"))
    dt_post = time.time() - t0

    ens_clean = cleaned_masks["ensemble"]
    ens_pct = 100 * ens_clean.mean()
    ens_km2 = roi_km2 * ens_clean.mean()
    total += 1; passed += check("Ensemble cleaned mask", ens_clean.sum() > 0, f"{ens_pct:.2f}% = {ens_km2:.2f} km²")

    # save shapefile for ensemble
    save_flood_shapefile(ens_clean, bbox, os.path.join(OUTPUT_DIR, "flood_ensemble.shp"), "ensemble")
    print(f"  ⏱  Post-process: {dt_post:.1f}s")

    # ══════════════════════════════════════════════════════════════════
    # 6. WATER DEPTH
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 6: Water Depth Estimation ──")
    from water_depth import simulate_water_depth

    t0 = time.time()
    bs_diff = detections.get("threshold", {}).get("change")
    depth, depth_stats = simulate_water_depth(ens_clean, dem, bs_diff,
                                               analysis.get("total_mm", 0))
    dt_depth = time.time() - t0

    total += 1; passed += check("Depth array shape", depth.shape == target, f"{depth.shape}")
    total += 1; passed += check("Depth max > 0", depth_stats["max_depth_m"] > 0, f"max={depth_stats['max_depth_m']:.2f}m")
    total += 1; passed += check("Depth mean reasonable", 0 < depth_stats["mean_depth_m"] < MAX_WATER_DEPTH_M, f"mean={depth_stats['mean_depth_m']:.2f}m")
    total += 1; passed += check("Volume computed", depth_stats["volume_m3"] > 0, f"vol={depth_stats['volume_m3']:.0f} m³")
    print(f"  ⏱  Depth: {dt_depth:.1f}s")

    # save depth raster
    from exporter import save_float
    save_float(depth, bbox, os.path.join(OUTPUT_DIR, "water_depth.tif"))

    # ══════════════════════════════════════════════════════════════════
    # 7. STREETS
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 7: Street Impact Analysis ──")
    from streets import download_osm_streets, compute_street_water_depth, flooded_streets_summary

    t0 = time.time()
    try:
        streets = download_osm_streets(bbox)
        if streets is not None and len(streets) > 0:
            total += 1; passed += check("OSM streets downloaded", len(streets) > 10, f"{len(streets)} segments")
            gdf = compute_street_water_depth(streets, depth, bbox)
            if gdf is not None:
                summary = flooded_streets_summary(gdf)
                total += 1; passed += check("Street depth computed", summary["total_km"] > 0, f"{summary['total_km']:.1f} km total, {summary['flooded_km']:.1f} km flooded")
            else:
                total += 1; passed += check("Street depth", False, "No GeoDataFrame returned")
        else:
            print("  [SKIP] No streets returned by OSM")
    except Exception as e:
        print(f"  [SKIP] Streets failed: {e}")
    dt_streets = time.time() - t0
    print(f"  ⏱  Streets: {dt_streets:.1f}s")

    # ══════════════════════════════════════════════════════════════════
    # 8. STATISTICS & EXPORT
    # ══════════════════════════════════════════════════════════════════
    print("\n── Stage 8: Statistics & Export ──")
    from exporter import build_stats, save_csv
    stats = build_stats(detections, roi_km2, analysis, depth_stats,
                        summary if 'summary' in dir() else None)
    save_csv(stats, os.path.join(OUTPUT_DIR, "flood_stats.csv"))

    total += 1; passed += check("Stats built", "methods" in stats and len(stats["methods"]) == 5, "")
    total += 1; passed += check("CSV exported", os.path.exists(os.path.join(OUTPUT_DIR, "flood_stats.csv")), "")

    # figures
    from visualizer import (fig_sar_comparison, fig_flood_maps, fig_confidence,
                            fig_water_depth, fig_precipitation, fig_statistics)
    fig_precipitation(analysis)
    fig_sar_comparison(before[:,:,0], after[:,:,0])
    fig_flood_maps(detections)
    fig_confidence(detections["ensemble"]["confidence"])
    fig_water_depth(depth)
    fig_statistics(stats)
    total += 1; passed += check("Figures generated", os.path.exists(os.path.join(OUTPUT_DIR, "sar_comparison.png")), "")

    # list outputs
    outputs = [f for f in os.listdir(OUTPUT_DIR) if os.path.isfile(os.path.join(OUTPUT_DIR, f))]
    print(f"\n  Output files ({len(outputs)}):")
    for f in sorted(outputs):
        sz = os.path.getsize(os.path.join(OUTPUT_DIR, f)) / 1024
        print(f"    {f:40s} {sz:8.1f} KB")

    # ══════════════════════════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════════════════════════
    print("\n" + "=" * 70)
    print(f"  RESULTS: {passed}/{total} checks passed")
    if passed == total:
        print("  STATUS: ALL TESTS PASSED")
    else:
        print(f"  STATUS: {total - passed} FAILURES")
    print("=" * 70)

    # Print key findings
    print("\n── Key Findings ──")
    print(f"  ROI:            {roi_km2:.1f} km²")
    print(f"  Precipitation:  {analysis['total_mm']:.1f} mm total, peak {analysis['peak_day_mm']:.1f} mm")
    print(f"  Risk score:     {analysis['risk_score']}/100")
    print(f"  Flood extent:   {ens_km2:.2f} km² ({ens_pct:.2f}%)")
    print(f"  Water depth:    max {depth_stats['max_depth_m']:.2f}m, mean {depth_stats['mean_depth_m']:.2f}m")
    print(f"  Water volume:   {depth_stats['volume_m3']:.0f} m³")
    if 'summary' in dir() and summary:
        print(f"  Roads flooded:  {summary['flooded_km']:.1f} km / {summary['total_km']:.1f} km")

    return 0 if passed == total else 1


if __name__ == "__main__":
    try:
        code = main()
    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        traceback.print_exc()
        code = 2
    sys.exit(code)
