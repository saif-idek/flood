"""
╔══════════════════════════════════════════════════════════════════════╗
║         UAE FloodMap – Publication-Quality Figure Generator         ║
║  Professional hydrology-style charts with deep blue palette        ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, os, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, to_rgba
from matplotlib.patches import FancyBboxPatch
import matplotlib.patheffects as pe
import matplotlib.ticker as mticker
from config import OUTPUT_DIR, FIGURE_DPI, MAX_WATER_DEPTH_M, RESOLUTION_M

L = logging.getLogger("flood.viz")

# ═══════════════════════════════════════════════════════════════════════
#  PROFESSIONAL COLOR PALETTE — deep ocean / hydrology theme
# ═══════════════════════════════════════════════════════════════════════
PAL = {
    "bg":        "#0B1120",
    "card":      "#111827",
    "grid":      "#1E293B",
    "border":    "#334155",
    "text":      "#E2E8F0",
    "text2":     "#94A3B8",
    "text3":     "#64748B",
    "accent":    "#38BDF8",   # sky-400
    "accent2":   "#0EA5E9",   # sky-500
    "deep":      "#0369A1",   # sky-700
    "deep2":     "#075985",   # sky-800
    "deep3":     "#0C4A6E",   # sky-900
    "navy":      "#0F172A",
    "cyan":      "#22D3EE",
    "teal":      "#2DD4BF",
    "emerald":   "#34D399",
    "amber":     "#FBBF24",
    "slate":     "#475569",
    # precipitation intensity scale — professional blue gradient
    "precip_dry":      "#1E293B",
    "precip_light":    "#38BDF8",
    "precip_moderate": "#0284C7",
    "precip_heavy":    "#0369A1",
    "precip_extreme":  "#082F49",
}

# custom colormaps
FLOOD_CMAP = LinearSegmentedColormap.from_list("flood_pro",
    ["#0B1120", "#164E63", "#0E7490", "#0EA5E9", "#38BDF8", "#BAE6FD"])
DEPTH_CMAP = LinearSegmentedColormap.from_list("depth_pro",
    ["#0B1120", "#0C4A6E", "#0369A1", "#0284C7", "#0EA5E9", "#7DD3FC"])
CHANGE_CMAP = LinearSegmentedColormap.from_list("change_pro",
    ["#0C4A6E", "#0369A1", "#38BDF8", "#F8FAFC", "#FBBF24", "#D97706", "#92400E"])
CONF_CMAP = LinearSegmentedColormap.from_list("conf_pro",
    ["#0B1120", "#0C4A6E", "#0369A1", "#0EA5E9", "#38BDF8", "#BAE6FD", "#F0F9FF"])
SAR_CMAP = LinearSegmentedColormap.from_list("sar_pro",
    ["#000000", "#1E293B", "#475569", "#94A3B8", "#CBD5E1", "#F1F5F9"])
TERRAIN_CMAP = LinearSegmentedColormap.from_list("terrain_pro",
    ["#0C4A6E", "#164E63", "#115E59", "#065F46", "#047857", "#34D399",
     "#A7F3D0", "#FDE68A", "#D97706", "#92400E", "#F1F5F9"])

# ═══════════════════════════════════════════════════════════════════════
#  STYLE HELPERS
# ═══════════════════════════════════════════════════════════════════════
def _fig(rows=1, cols=1, w=14, h=6, hspace=0.3):
    fig, axes = plt.subplots(rows, cols, figsize=(w, h), facecolor=PAL["bg"],
                             gridspec_kw={"hspace": hspace} if rows > 1 else {})
    if rows == 1 and cols == 1:
        axes = np.array([axes])
    for ax in np.array(axes).flat:
        ax.set_facecolor(PAL["card"])
        for spine in ax.spines.values():
            spine.set_color(PAL["border"])
            spine.set_linewidth(0.6)
    return fig, axes

def _title(ax, text, size=11):
    ax.set_title(text, color=PAL["text"], fontsize=size, fontweight="700",
                 pad=10, loc="left", fontfamily="sans-serif")

def _ticks(ax, x=True, y=True):
    ax.tick_params(axis="both", colors=PAL["text2"], labelsize=8, length=3, width=0.5)
    ax.grid(True, alpha=0.15, color=PAL["grid"], linewidth=0.5)
    if not x: ax.set_xticklabels([])
    if not y: ax.set_yticklabels([])

def _suptitle(fig, text, sub=None):
    fig.suptitle(text, color=PAL["text"], fontsize=15, fontweight="800",
                 x=0.02, ha="left", y=0.98, fontfamily="sans-serif")
    if sub:
        fig.text(0.02, 0.94, sub, color=PAL["text3"], fontsize=9,
                 ha="left", fontfamily="sans-serif")

def _colorbar(fig, im, ax, label="", fmt=None):
    cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02, aspect=30)
    cb.set_label(label, color=PAL["text2"], fontsize=9, labelpad=8)
    cb.ax.tick_params(colors=PAL["text2"], labelsize=8, length=2)
    cb.outline.set_edgecolor(PAL["border"])
    cb.outline.set_linewidth(0.5)
    if fmt:
        cb.ax.yaxis.set_major_formatter(fmt)
    return cb

def _watermark(fig):
    fig.text(0.99, 0.01, "UAE FloodMap v3", color=PAL["text3"],
             fontsize=7, ha="right", va="bottom", alpha=0.4,
             fontfamily="monospace")

def _savefig(fig, name):
    path = os.path.join(OUTPUT_DIR, name)
    fig.savefig(path, dpi=FIGURE_DPI, bbox_inches="tight",
                facecolor=PAL["bg"], edgecolor="none", pad_inches=0.15)
    plt.close(fig)
    L.info(f"Figure saved: {name}")
    return path

# ═══════════════════════════════════════════════════════════════════════
#  PRECIPITATION — 4-panel professional chart
# ═══════════════════════════════════════════════════════════════════════
def fig_precipitation(precip_analysis):
    dates = precip_analysis.get("dates", [])
    daily = precip_analysis.get("daily_mm", [])
    cumul = precip_analysis.get("cumulative_mm", [])
    intensity = precip_analysis.get("intensity", [])
    api = precip_analysis.get("api", [])
    wb = precip_analysis.get("water_balance", [])
    cwb = precip_analysis.get("cum_water_balance", [])
    risk = precip_analysis.get("risk_score", 0)
    n = len(dates)
    if n == 0:
        return None

    fig, axes = _fig(rows=3, cols=1, w=16, h=12, hspace=0.35)
    x = np.arange(n)
    labels = [d[5:] for d in dates]

    # ── Panel 1: Daily Precipitation Bars ──────────────────────────
    ax = axes[0]
    bar_colors = {
        "dry":      PAL["precip_dry"],
        "light":    PAL["precip_light"],
        "moderate": PAL["precip_moderate"],
        "heavy":    PAL["precip_heavy"],
        "extreme":  PAL["precip_extreme"],
    }
    colors = [bar_colors.get(i, PAL["precip_dry"]) for i in intensity]

    bars = ax.bar(x, daily, color=colors, edgecolor="none", width=0.72,
                  zorder=3)
    # threshold lines
    ax.axhline(y=20, color=PAL["deep"], linestyle="--", alpha=0.5,
               linewidth=0.8, zorder=2)
    ax.axhline(y=50, color=PAL["deep3"], linestyle="--", alpha=0.5,
               linewidth=0.8, zorder=2)
    ax.text(n - 0.5, 21, "Heavy (20 mm)", color=PAL["deep"], fontsize=7,
            ha="right", va="bottom", alpha=0.7)
    ax.text(n - 0.5, 51, "Extreme (50 mm)", color=PAL["deep3"], fontsize=7,
            ha="right", va="bottom", alpha=0.7)

    # annotate peak
    peak_idx = np.argmax(daily)
    ax.annotate(f"{daily[peak_idx]:.1f} mm",
                xy=(peak_idx, daily[peak_idx]), xytext=(peak_idx, daily[peak_idx] + max(daily) * 0.08),
                fontsize=8, fontweight="700", color=PAL["accent"],
                ha="center", va="bottom",
                arrowprops=dict(arrowstyle="-", color=PAL["accent"], lw=0.8))

    _title(ax, "DAILY PRECIPITATION")
    ax.set_ylabel("mm/day", color=PAL["text2"], fontsize=9)
    ax.set_xticks(x[::max(1, n // 12)])
    ax.set_xticklabels([labels[i] for i in range(0, n, max(1, n // 12))],
                       rotation=45, ha="right", fontsize=8)
    _ticks(ax)

    # legend
    from matplotlib.patches import Patch
    leg_items = [
        Patch(facecolor=PAL["precip_light"], label="Light"),
        Patch(facecolor=PAL["precip_moderate"], label="Moderate"),
        Patch(facecolor=PAL["precip_heavy"], label="Heavy"),
        Patch(facecolor=PAL["precip_extreme"], label="Extreme"),
    ]
    leg = ax.legend(handles=leg_items, loc="upper left", fontsize=8,
                    framealpha=0.3, facecolor=PAL["card"], edgecolor=PAL["border"],
                    labelcolor=PAL["text2"], ncol=4)

    # ── Panel 2: Cumulative + API ──────────────────────────────────
    ax = axes[1]
    ax.fill_between(x, cumul, alpha=0.2, color=PAL["accent"], zorder=2)
    ax.plot(x, cumul, color=PAL["accent"], linewidth=2.2, zorder=3,
            label="Cumulative")
    ax.scatter([len(cumul) - 1], [cumul[-1]], color=PAL["cyan"], s=40,
               zorder=4, edgecolor="white", linewidth=0.8)
    ax.text(len(cumul) - 1, cumul[-1] * 1.04,
            f"{cumul[-1]:.0f} mm", color=PAL["cyan"], fontsize=8,
            fontweight="700", ha="center")

    ax2 = ax.twinx()
    ax2.plot(x, api, color=PAL["amber"], linewidth=1.5, linestyle="-",
             alpha=0.8, zorder=3, label="API (k=0.85)")
    ax2.tick_params(axis="y", colors=PAL["amber"], labelsize=8, length=3)
    ax2.set_ylabel("Antecedent Precip Index", color=PAL["amber"], fontsize=9)
    ax2.spines["right"].set_color(PAL["amber"])
    ax2.spines["right"].set_linewidth(0.6)
    for sp in ["top", "left", "bottom"]:
        ax2.spines[sp].set_visible(False)

    _title(ax, "CUMULATIVE PRECIPITATION  &  ANTECEDENT INDEX")
    ax.set_ylabel("Cumulative (mm)", color=PAL["text2"], fontsize=9)
    ax.set_xticks(x[::max(1, n // 12)])
    ax.set_xticklabels([labels[i] for i in range(0, n, max(1, n // 12))],
                       rotation=45, ha="right", fontsize=8)
    _ticks(ax)

    # ── Panel 3: Water Balance ─────────────────────────────────────
    ax = axes[2]
    if wb:
        pos = [max(0, v) for v in wb]
        neg = [min(0, v) for v in wb]
        ax.bar(x, pos, color=PAL["teal"], width=0.72, edgecolor="none",
               label="Surplus", zorder=3, alpha=0.85)
        ax.bar(x, neg, color=PAL["deep2"], width=0.72, edgecolor="none",
               label="Deficit", zorder=3, alpha=0.85)
        ax.axhline(y=0, color=PAL["border"], linewidth=0.8, zorder=2)

        ax3 = ax.twinx()
        ax3.plot(x, cwb, color=PAL["cyan"], linewidth=1.8, zorder=4)
        ax3.tick_params(axis="y", colors=PAL["cyan"], labelsize=8, length=3)
        ax3.set_ylabel("Cum. Balance (mm)", color=PAL["cyan"], fontsize=9)
        ax3.spines["right"].set_color(PAL["cyan"])
        ax3.spines["right"].set_linewidth(0.6)
        for sp in ["top", "left", "bottom"]:
            ax3.spines[sp].set_visible(False)

        leg = ax.legend(loc="upper left", fontsize=8, framealpha=0.3,
                        facecolor=PAL["card"], edgecolor=PAL["border"],
                        labelcolor=PAL["text2"])

    _title(ax, "WATER BALANCE  (Precip \u2212 ET\u2080)")
    ax.set_ylabel("mm/day", color=PAL["text2"], fontsize=9)
    ax.set_xticks(x[::max(1, n // 12)])
    ax.set_xticklabels([labels[i] for i in range(0, n, max(1, n // 12))],
                       rotation=45, ha="right", fontsize=8)
    _ticks(ax)

    total = precip_analysis.get("total_mm", 0)
    peak = precip_analysis.get("peak_day_mm", 0)
    rp = precip_analysis.get("return_period_est", "—")
    _suptitle(fig,
              "PRECIPITATION ANALYSIS",
              f"Total: {total:.0f} mm  |  Peak: {peak:.0f} mm/day  |  "
              f"Risk Score: {risk}/100  |  Return Period: {rp}")
    _watermark(fig)
    return _savefig(fig, "precipitation.png")

# ═══════════════════════════════════════════════════════════════════════
#  SAR COMPARISON — 3-panel
# ═══════════════════════════════════════════════════════════════════════
def fig_sar_comparison(before_vv, after_vv):
    from detection import to_db, lee_filter
    b = to_db(lee_filter(before_vv))
    a = to_db(lee_filter(after_vv))
    d = a - b

    fig, axes = _fig(rows=1, cols=3, w=20, h=7)
    finite = b[np.isfinite(b)]
    p2, p98 = np.percentile(finite, [2, 98]) if len(finite) > 0 else (-20, 0)

    im0 = axes[0].imshow(b, cmap=SAR_CMAP, vmin=p2, vmax=p98, aspect="equal")
    _title(axes[0], "BEFORE EVENT  (VV dB)")
    axes[0].axis("off")

    im1 = axes[1].imshow(a, cmap=SAR_CMAP, vmin=p2, vmax=p98, aspect="equal")
    _title(axes[1], "AFTER EVENT  (VV dB)")
    axes[1].axis("off")

    im2 = axes[2].imshow(d, cmap=CHANGE_CMAP, vmin=-8, vmax=8, aspect="equal")
    _title(axes[2], "BACKSCATTER CHANGE  (dB)")
    axes[2].axis("off")
    _colorbar(fig, im2, axes[2], "dB change")

    _suptitle(fig, "SENTINEL-1 SAR BACKSCATTER ANALYSIS",
              f"Grid: {b.shape[1]} \u00d7 {b.shape[0]} px  |  "
              f"dB range: [{p2:.1f}, {p98:.1f}]")
    _watermark(fig)
    return _savefig(fig, "sar_comparison.png")

# ═══════════════════════════════════════════════════════════════════════
#  FLOOD DETECTION METHODS — multi-panel
# ═══════════════════════════════════════════════════════════════════════
def fig_flood_maps(detections):
    methods = [k for k in detections if k != "ensemble"]
    n = len(methods) + 1
    fig, axes = _fig(rows=1, cols=n, w=5 * n, h=6)

    for i, name in enumerate(methods):
        m = detections[name]["mask"]
        # overlay: dark background with flood highlighted
        display = np.where(m, 1.0, 0.05)
        axes[i].imshow(display, cmap=DEPTH_CMAP, vmin=0, vmax=1,
                       interpolation="nearest", aspect="equal")
        pct = 100 * m.mean()
        _title(axes[i], f"{name.replace('_', ' ').upper()}  ({pct:.2f}%)")
        axes[i].axis("off")

    # ensemble
    em = detections["ensemble"]["mask"]
    display = np.where(em, 1.0, 0.05)
    axes[-1].imshow(display, cmap=DEPTH_CMAP, vmin=0, vmax=1,
                    interpolation="nearest", aspect="equal")
    _title(axes[-1], f"ENSEMBLE  ({100 * em.mean():.2f}%)")
    axes[-1].axis("off")
    # highlight ensemble border
    for spine in axes[-1].spines.values():
        spine.set_color(PAL["accent"])
        spine.set_linewidth(2)
        spine.set_visible(True)

    _suptitle(fig, "FLOOD DETECTION METHODS COMPARISON")
    _watermark(fig)
    return _savefig(fig, "flood_methods.png")

# ═══════════════════════════════════════════════════════════════════════
#  CONFIDENCE HEATMAP
# ═══════════════════════════════════════════════════════════════════════
def fig_confidence(confidence):
    fig, ax = _fig(rows=1, cols=1, w=10, h=8)
    ax = ax[0]
    im = ax.imshow(confidence, cmap=CONF_CMAP, vmin=0, vmax=1, aspect="equal")
    _title(ax, "ENSEMBLE FLOOD CONFIDENCE")
    ax.axis("off")
    _colorbar(fig, im, ax, "Confidence (0–1)")

    mean_c = confidence[confidence > 0].mean() if (confidence > 0).any() else 0
    high_pct = 100 * (confidence >= 0.75).mean()
    _suptitle(fig, "ENSEMBLE CONFIDENCE MAP",
              f"Mean confidence: {mean_c:.2f}  |  "
              f"High confidence (\u22650.75): {high_pct:.1f}% of area")
    _watermark(fig)
    return _savefig(fig, "confidence.png")

# ═══════════════════════════════════════════════════════════════════════
#  WATER DEPTH MAP
# ═══════════════════════════════════════════════════════════════════════
def fig_water_depth(depth):
    fig, ax = _fig(rows=1, cols=1, w=10, h=8)
    ax = ax[0]
    masked = np.ma.masked_where(depth < 0.01, depth)
    im = ax.imshow(masked, cmap=DEPTH_CMAP, vmin=0, vmax=MAX_WATER_DEPTH_M,
                   aspect="equal")
    _title(ax, "ESTIMATED WATER DEPTH")
    ax.axis("off")
    _colorbar(fig, im, ax, "Depth (m)")

    flooded = depth[depth > 0.01]
    if len(flooded) > 0:
        _suptitle(fig, "WATER DEPTH ESTIMATION",
                  f"Max: {flooded.max():.2f} m  |  Mean: {flooded.mean():.2f} m  |  "
                  f"Median: {np.median(flooded):.2f} m")
    else:
        _suptitle(fig, "WATER DEPTH ESTIMATION", "No flooding detected")
    _watermark(fig)
    return _savefig(fig, "water_depth.png")

# ═══════════════════════════════════════════════════════════════════════
#  STREET FLOOD MAP
# ═══════════════════════════════════════════════════════════════════════
def fig_street_flood(streets_gdf, water_depth):
    fig, ax = _fig(rows=1, cols=1, w=12, h=9)
    ax = ax[0]

    # depth background
    masked = np.ma.masked_where(water_depth < 0.01, water_depth)
    ax.imshow(masked, cmap=DEPTH_CMAP, vmin=0, vmax=MAX_WATER_DEPTH_M,
              alpha=0.45, extent=[0, water_depth.shape[1], water_depth.shape[0], 0],
              aspect="equal")

    # road severity colors — professional blue-to-navy scale
    road_colors = {
        "dry":      PAL["text3"],
        "low":      PAL["accent"],
        "medium":   PAL["deep"],
        "high":     PAL["deep2"],
        "critical": PAL["deep3"],
    }

    if streets_gdf is not None:
        for _, row in streets_gdf.iterrows():
            geom = row.geometry
            c = road_colors.get(row.get("flood_class", "dry"), PAL["text3"])
            lw = 1.0 if row.get("flood_class") == "dry" else 2.0
            if geom.geom_type == "LineString":
                xs, ys = geom.xy
                ax.plot(xs, ys, color=c, linewidth=lw, alpha=0.85, solid_capstyle="round")
            elif geom.geom_type == "MultiLineString":
                for line in geom.geoms:
                    xs, ys = line.xy
                    ax.plot(xs, ys, color=c, linewidth=lw, alpha=0.85, solid_capstyle="round")

    _title(ax, "ROAD NETWORK FLOOD IMPACT")
    ax.axis("off")

    # legend
    from matplotlib.lines import Line2D
    leg_items = [
        Line2D([0], [0], color=road_colors["low"], linewidth=2.5, label="Low"),
        Line2D([0], [0], color=road_colors["medium"], linewidth=2.5, label="Medium"),
        Line2D([0], [0], color=road_colors["high"], linewidth=2.5, label="High"),
        Line2D([0], [0], color=road_colors["critical"], linewidth=2.5, label="Critical"),
    ]
    ax.legend(handles=leg_items, loc="lower right", fontsize=9,
              framealpha=0.5, facecolor=PAL["card"], edgecolor=PAL["border"],
              labelcolor=PAL["text2"], title="Road Severity",
              title_fontproperties={"weight": "bold", "size": 9})

    _suptitle(fig, "ROAD NETWORK FLOOD IMPACT")
    _watermark(fig)
    return _savefig(fig, "street_flood.png")

# ═══════════════════════════════════════════════════════════════════════
#  STATISTICS DASHBOARD
# ═══════════════════════════════════════════════════════════════════════
def fig_statistics(stats):
    methods = stats.get("methods", {})
    if not methods:
        return None

    fig, axes = _fig(rows=1, cols=2, w=16, h=7)
    names = list(methods.keys())
    km2 = [methods[n].get("flooded_km2", 0) for n in names]
    pct = [methods[n].get("pct_flooded", 0) for n in names]

    # gradient colors for each method
    method_colors = [PAL["accent"], PAL["accent2"], PAL["deep"],
                     PAL["teal"], PAL["cyan"]]
    mc = method_colors[:len(names)]

    # ── Left: km² ──
    ax = axes[0]
    bh = ax.barh(names, km2, color=mc, edgecolor="none", height=0.6, zorder=3)
    _title(ax, "FLOODED AREA  (km\u00b2)")
    _ticks(ax)
    ax.invert_yaxis()
    for i, (bar, v) in enumerate(zip(bh, km2)):
        ax.text(v + max(km2) * 0.02, bar.get_y() + bar.get_height() / 2,
                f"{v:.3f}", color=PAL["text"], va="center", fontsize=10,
                fontweight="700", fontfamily="monospace")
    ax.set_xlabel("km\u00b2", color=PAL["text2"], fontsize=9)
    ax.tick_params(axis="y", labelsize=10)
    # highlight ensemble
    for label in ax.get_yticklabels():
        if "ensemble" in label.get_text().lower():
            label.set_color(PAL["cyan"])
            label.set_fontweight("bold")

    # ── Right: % ──
    ax = axes[1]
    bh = ax.barh(names, pct, color=mc, edgecolor="none", height=0.6, zorder=3)
    _title(ax, "FLOODED AREA  (%)")
    _ticks(ax)
    ax.invert_yaxis()
    for i, (bar, v) in enumerate(zip(bh, pct)):
        ax.text(v + max(pct) * 0.02, bar.get_y() + bar.get_height() / 2,
                f"{v:.2f}%", color=PAL["text"], va="center", fontsize=10,
                fontweight="700", fontfamily="monospace")
    ax.set_xlabel("%", color=PAL["text2"], fontsize=9)
    ax.tick_params(axis="y", labelsize=10)
    for label in ax.get_yticklabels():
        if "ensemble" in label.get_text().lower():
            label.set_color(PAL["cyan"])
            label.set_fontweight("bold")

    roi = stats.get("roi_km2", 0)
    ens = methods.get("ensemble", methods.get("modis", {}))
    label = "Ensemble" if "ensemble" in methods else "MODIS"
    _suptitle(fig, "DETECTION METHODS COMPARISON",
              f"ROI: {roi:.1f} km\u00b2  |  "
              f"{label}: {ens.get('flooded_km2', 0):.3f} km\u00b2 "
              f"({ens.get('pct_flooded', 0):.2f}%)")
    _watermark(fig)
    return _savefig(fig, "statistics.png")


# ═══════════════════════════════════════════════════════════════════════
#  Z-SCORE OVERLAY — SAR anomaly map superimposed on terrain
# ═══════════════════════════════════════════════════════════════════════
def fig_zscore_overlay(zscore, flood_mask, dem, bbox, roi_km2):
    """Z-score anomaly map overlaid on DEM terrain with flood contour."""
    fig, axes = _fig(rows=1, cols=2, w=22, h=9)
    extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]

    # ── Left: Z-score heatmap on terrain ──
    ax = axes[0]
    _terrain_bg(ax, dem, extent)

    # Z-score overlay: strong negatives = flood (cyan-blue), positives = dry (transparent)
    ZSCORE_CMAP = LinearSegmentedColormap.from_list("zscore_flood",
        [(0.0, "#0C4A6E"), (0.15, "#0369A1"), (0.3, "#0EA5E9"),
         (0.45, "#38BDF8"), (0.5, "#E2E8F0"),
         (0.55, "#FDE68A"), (0.7, "#F59E0B"), (0.85, "#DC2626"), (1.0, "#7F1D1D")])

    z_clipped = np.clip(zscore, -5, 5)
    # make alpha: strong signal = opaque, near-zero = transparent
    alpha = np.clip(np.abs(z_clipped) / 3.0, 0, 0.85)
    alpha[~np.isfinite(zscore)] = 0

    im = ax.imshow(z_clipped, cmap=ZSCORE_CMAP, vmin=-5, vmax=5,
                   extent=extent, aspect="equal", alpha=0.75)
    # flood contour
    if flood_mask.sum() > 0:
        ax.contour(flood_mask, levels=[0.5], colors=[PAL["cyan"]],
                   linewidths=0.8, extent=extent, alpha=0.6)

    _colorbar(fig, im, ax, "Z-score (\u03c3)")
    _title(ax, "SAR Z-SCORE ANOMALY MAP")
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    ax.set_ylabel("Latitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    flood_km2 = roi_km2 * flood_mask.mean()
    _add_stats_box(ax, [
        f"Z-SCORE FLOOD DETECTION",
        f"Flooded: {flood_km2:.2f} km\u00b2 ({100*flood_mask.mean():.2f}%)",
        f"Z < -1.5\u03c3 = flood anomaly",
        f"Blue = SAR backscatter drop",
    ], fontsize=9)

    # ── Right: flood mask on terrain (binary result) ──
    ax = axes[1]
    _terrain_bg(ax, dem, extent)
    flood_rgba = np.zeros((*flood_mask.shape, 4))
    flood_rgba[flood_mask > 0] = [0, 0.85, 0.93, 0.75]
    ax.imshow(flood_rgba, extent=extent, aspect="equal", interpolation="nearest")
    _title(ax, f"DETECTED FLOOD  ({flood_km2:.2f} km\u00b2)")
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    from matplotlib.patches import Patch
    ax.legend(handles=[
        Patch(facecolor=(0, 0.85, 0.93, 0.75), edgecolor="white", lw=0.5,
              label=f"Flood extent ({flood_km2:.2f} km\u00b2)")],
        loc="lower right", fontsize=10, framealpha=0.7,
        facecolor=PAL["navy"], edgecolor=PAL["border"], labelcolor=PAL["text"])

    _suptitle(fig, "Z-SCORE SAR ANOMALY DETECTION",
              f"Flood: {flood_km2:.2f} km\u00b2  |  ROI: {roi_km2:.1f} km\u00b2  |  "
              f"Z-score range: [{np.nanmin(zscore):.1f}, {np.nanmax(zscore):.1f}]\u03c3")
    _watermark(fig)
    return _savefig(fig, "zscore_overlay.png")


# ═══════════════════════════════════════════════════════════════════════
#  MODIS PRO FIGURES — terrain background + cyan flood overlay
# ═══════════════════════════════════════════════════════════════════════

def _hillshade(dem, azimuth=315, altitude=35):
    """Compute hillshade from DEM for terrain background."""
    az = np.radians(azimuth)
    alt = np.radians(altitude)
    dy, dx = np.gradient(dem)
    slope = np.sqrt(dx**2 + dy**2)
    aspect = np.arctan2(-dy, dx)
    shade = (np.sin(alt) * np.cos(slope) +
             np.cos(alt) * np.sin(slope) * np.cos(az - aspect))
    return np.clip(shade, 0, 1)


def _terrain_bg(ax, dem, extent=None):
    """Render dark terrain hillshade as background."""
    hs = _hillshade(dem)
    # dark terrain: blend hillshade with navy background
    rgb = np.zeros((*hs.shape, 3))
    rgb[:,:,0] = 0.04 + hs * 0.15   # slight blue tint
    rgb[:,:,1] = 0.06 + hs * 0.18
    rgb[:,:,2] = 0.10 + hs * 0.25
    ax.imshow(rgb, extent=extent, aspect="equal", interpolation="bilinear")


def _add_stats_box(ax, lines, x=0.02, y=0.98, fontsize=10):
    """Add a semi-transparent stats box on the figure."""
    text = "\n".join(lines)
    ax.text(x, y, text, transform=ax.transAxes, fontsize=fontsize,
            fontfamily="monospace", fontweight="600",
            color=PAL["text"], va="top", ha="left",
            bbox=dict(boxstyle="round,pad=0.5", facecolor=PAL["navy"],
                      edgecolor=PAL["border"], alpha=0.85))


# ═══════════════════════════════════════════════════════════════════════
#  URBAN WATER HEIGHT MAP — depth contours in residential areas
# ═══════════════════════════════════════════════════════════════════════
URBAN_DEPTH_CMAP = LinearSegmentedColormap.from_list("urban_depth", [
    (0.00, "#0B1120"),   # dry — invisible
    (0.04, "#164E63"),   # trace
    (0.12, "#22D3EE"),   # 5 cm — cyan
    (0.25, "#38BDF8"),   # 12 cm — sky
    (0.40, "#0EA5E9"),   # 20 cm — blue
    (0.60, "#FBBF24"),   # 30 cm — amber
    (0.80, "#F97316"),   # 40 cm — orange
    (1.00, "#EF4444"),   # 50 cm — red
])


def fig_urban_water_height(depth, dem, bbox, depth_stats, roi_km2):
    """Professional water height map for urban/residential areas.
    Shows depth gradient with contour labels over terrain."""
    fig, axes = _fig(rows=1, cols=2, w=22, h=10)
    extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]
    max_d = 0.50  # 50 cm cap

    # ── Left: Full depth map with contours ──
    ax = axes[0]
    _terrain_bg(ax, dem, extent)

    masked = np.ma.masked_where(depth < 0.01, depth)
    im = ax.imshow(masked, cmap=URBAN_DEPTH_CMAP, vmin=0, vmax=max_d,
                   extent=extent, aspect="equal", alpha=0.85, interpolation="bilinear")

    # contour lines at key depths
    levels = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50]
    level_labels = ["5cm", "10cm", "20cm", "30cm", "40cm", "50cm"]
    try:
        cs = ax.contour(depth, levels=levels, colors="white", linewidths=0.5,
                        extent=extent, alpha=0.4)
        ax.clabel(cs, levels, fmt={l: lb for l, lb in zip(levels, level_labels)},
                  fontsize=7, colors="white")
    except Exception:
        pass

    cb = _colorbar(fig, im, ax, "Water Height (m)")
    # custom tick labels on colorbar
    cb.set_ticks([0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50])
    cb.set_ticklabels(["0", "5cm", "10cm", "20cm", "30cm", "40cm", "50cm"])

    _title(ax, "URBAN WATER HEIGHT MODEL")
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    ax.set_ylabel("Latitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    _add_stats_box(ax, [
        f"WATER HEIGHT SIMULATION",
        f"Model:  DEM + Rainfall-Runoff",
        f"Max:    {depth_stats['max_depth_m']:.2f} m",
        f"Mean:   {depth_stats['mean_depth_m']:.2f} m",
        f"Volume: {depth_stats['volume_m3']:,.0f} m\u00b3",
    ], fontsize=9)

    # ── Right: Depth classification zones ──
    ax = axes[1]
    _terrain_bg(ax, dem, extent)

    # classified depth zones with distinct colors
    zones = [
        (0.01, 0.05, "#22D3EE", "< 5 cm  (safe)"),
        (0.05, 0.10, "#38BDF8", "5–10 cm  (caution)"),
        (0.10, 0.20, "#FBBF24", "10–20 cm  (warning)"),
        (0.20, 0.35, "#F97316", "20–35 cm  (danger)"),
        (0.35, 9.99, "#EF4444", "> 35 cm  (critical)"),
    ]
    from matplotlib.patches import Patch
    legend_handles = []
    for lo, hi, color, label in zones:
        zone_mask = (depth >= lo) & (depth < hi)
        if zone_mask.sum() == 0:
            continue
        rgba = np.zeros((*depth.shape, 4))
        r, g, b = int(color[1:3], 16)/255, int(color[3:5], 16)/255, int(color[5:7], 16)/255
        rgba[zone_mask] = [r, g, b, 0.75]
        ax.imshow(rgba, extent=extent, aspect="equal", interpolation="nearest")
        zone_km2 = zone_mask.sum() * (RESOLUTION_M**2) / 1e6
        legend_handles.append(Patch(facecolor=color, edgecolor="none",
                                    label=f"{label}  ({zone_km2:.2f} km\u00b2)"))

    ax.legend(handles=legend_handles, loc="lower right", fontsize=9,
              framealpha=0.85, facecolor=PAL["navy"], edgecolor=PAL["border"],
              labelcolor=PAL["text"], title="Depth Classification",
              title_fontproperties={"weight": "bold", "size": 9})

    _title(ax, "FLOOD SEVERITY ZONES")
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    flood_km2 = round(roi_km2 * (depth > 0.01).mean(), 2)
    _suptitle(fig, "URBAN WATER HEIGHT MODEL",
              f"Flooded: {flood_km2:.2f} km\u00b2  |  Max: {depth_stats['max_depth_m']:.2f} m  |  "
              f"Volume: {depth_stats['volume_m3']:,.0f} m\u00b3  |  "
              f"Method: DEM + Rainfall-Runoff + Flow Accumulation")
    _watermark(fig)
    return _savefig(fig, "urban_water_height.png")


# ═══════════════════════════════════════════════════════════════════════
#  STREET SEVERITY MAP — yellow / orange / red gradient per road
# ═══════════════════════════════════════════════════════════════════════
def fig_street_severity(streets_gdf, flood_mask, dem, bbox, street_summary, depth):
    """Road network severity: green→yellow→orange→red per road segment."""
    fig, axes = _fig(rows=1, cols=2, w=22, h=10)
    extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]

    # severity colors
    SEV = {
        "dry":      {"color": "#4ADE80", "lw": 0.5, "alpha": 0.3, "label": "Dry",      "order": 1},
        "low":      {"color": "#FACC15", "lw": 1.8, "alpha": 0.9, "label": "Low risk",  "order": 2},
        "medium":   {"color": "#FB923C", "lw": 2.2, "alpha": 0.9, "label": "Medium",    "order": 3},
        "high":     {"color": "#EF4444", "lw": 2.8, "alpha": 0.95,"label": "High risk", "order": 4},
        "critical": {"color": "#991B1B", "lw": 3.5, "alpha": 1.0, "label": "Critical",  "order": 5},
    }

    for panel_idx, ax in enumerate(axes):
        _terrain_bg(ax, dem, extent)

        # light flood background
        if panel_idx == 0:
            flood_rgba = np.zeros((*flood_mask.shape, 4))
            flood_rgba[flood_mask > 0] = [0.13, 0.59, 0.95, 0.15]
            ax.imshow(flood_rgba, extent=extent, aspect="equal", interpolation="nearest")
        else:
            # depth background for right panel
            masked_d = np.ma.masked_where(depth < 0.01, depth)
            ax.imshow(masked_d, cmap=URBAN_DEPTH_CMAP, vmin=0, vmax=0.5,
                      extent=extent, aspect="equal", alpha=0.4)

        if streets_gdf is not None:
            # sort: draw dry first, critical last (on top)
            sorted_rows = sorted(streets_gdf.iterrows(),
                                 key=lambda r: SEV.get(r[1].get("flood_class", "dry"), {}).get("order", 0))
            for _, row in sorted_rows:
                geom = row.geometry
                if geom is None:
                    continue
                cls = row.get("flood_class", "dry")
                s = SEV.get(cls, SEV["dry"])

                lines = [geom] if geom.geom_type == "LineString" else (
                    geom.geoms if geom.geom_type == "MultiLineString" else [])
                for line in lines:
                    xs, ys = line.xy
                    ax.plot(xs, ys, color=s["color"], linewidth=s["lw"],
                            alpha=s["alpha"], solid_capstyle="round",
                            zorder=s["order"] + 2)

        ax.set_xlim(extent[0], extent[1])
        ax.set_ylim(extent[2], extent[3])
        ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
        _ticks(ax)

    axes[0].set_ylabel("Latitude", color=PAL["text2"], fontsize=9)

    # legend on left panel
    from matplotlib.lines import Line2D
    legend_items = []
    for cls_name in ["dry", "low", "medium", "high", "critical"]:
        s = SEV[cls_name]
        if streets_gdf is not None:
            n = len(streets_gdf[streets_gdf["flood_class"] == cls_name])
            km = streets_gdf[streets_gdf["flood_class"] == cls_name]["length_m"].sum() / 1000
        else:
            n, km = 0, 0
        if n > 0 or cls_name in ("dry", "low"):
            legend_items.append(Line2D([0], [0], color=s["color"], linewidth=s["lw"],
                                       label=f"{s['label']}  ({km:.1f} km)"))

    axes[0].legend(handles=legend_items, loc="lower left", fontsize=9,
                   framealpha=0.85, facecolor=PAL["navy"], edgecolor=PAL["border"],
                   labelcolor=PAL["text"], title="Road Flood Severity",
                   title_fontproperties={"weight": "bold", "size": 9})

    _title(axes[0], "ROAD NETWORK — FLOOD SEVERITY")
    _title(axes[1], "ROAD NETWORK — OVER WATER DEPTH")

    total_km = street_summary.get("total_km", 0)
    flooded_km = street_summary.get("flooded_km", 0)
    pct = street_summary.get("pct_flooded", 0)

    _add_stats_box(axes[1], [
        f"ROAD IMPACT ASSESSMENT",
        f"Total roads:   {total_km:,.1f} km",
        f"Affected:      {flooded_km:,.1f} km ({pct:.1f}%)",
        f"Unaffected:    {total_km - flooded_km:,.1f} km",
    ], fontsize=9)

    _suptitle(fig, "STREET-LEVEL FLOOD SEVERITY ASSESSMENT",
              f"{flooded_km:.1f} km affected ({pct:.1f}%)  |  {total_km:.1f} km total  |  "
              f"Green=safe  Yellow=low  Orange=medium  Red=high/critical")
    _watermark(fig)
    return _savefig(fig, "street_severity.png")


def fig_modis_flood_map(flood_mask, dem, bbox, flood_km2, roi_km2, modis_date):
    """MODIS flood extent over terrain — cyan overlay with km² stats."""
    fig, ax = _fig(rows=1, cols=1, w=14, h=11)
    ax = ax[0]

    extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]
    _terrain_bg(ax, dem, extent)

    # flood overlay in cyan
    flood_rgba = np.zeros((*flood_mask.shape, 4))
    flood_rgba[flood_mask > 0] = [0, 0.85, 0.93, 0.7]  # cyan with alpha
    ax.imshow(flood_rgba, extent=extent, aspect="equal", interpolation="nearest")

    # stats box
    pct = 100 * flood_km2 / roi_km2 if roi_km2 > 0 else 0
    _add_stats_box(ax, [
        f"MODIS NRT FLOOD DETECTION",
        f"Date:     {modis_date}",
        f"Flooded:  {flood_km2:.2f} km\u00b2  ({pct:.2f}%)",
        f"ROI:      {roi_km2:.1f} km\u00b2",
        f"Source:   MCDWD_L3_F3_NRT (250m)",
    ])

    # axis labels
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    ax.set_ylabel("Latitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)
    ax.tick_params(labelsize=8)
    _title(ax, "")

    # legend
    from matplotlib.patches import Patch
    leg = ax.legend(
        handles=[Patch(facecolor=(0, 0.85, 0.93, 0.7), edgecolor="white",
                       linewidth=0.5, label=f"Surface Flood ({flood_km2:.2f} km\u00b2)")],
        loc="lower right", fontsize=10, framealpha=0.7,
        facecolor=PAL["navy"], edgecolor=PAL["border"],
        labelcolor=PAL["text"])

    _suptitle(fig, "MODIS SURFACE FLOOD MAP",
              f"{modis_date}  |  {flood_km2:.2f} km\u00b2 flooded  |  "
              f"{pct:.2f}% of {roi_km2:.1f} km\u00b2 ROI")
    _watermark(fig)
    return _savefig(fig, "modis_flood_map.png")


def fig_modis_depth_map(depth, flood_mask, dem, bbox, depth_stats):
    """MODIS water depth over terrain — blue gradient."""
    fig, axes = _fig(rows=1, cols=2, w=20, h=9)

    extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]

    # ── Left: flood mask (binary) ──
    ax = axes[0]
    _terrain_bg(ax, dem, extent)
    flood_rgba = np.zeros((*flood_mask.shape, 4))
    flood_rgba[flood_mask > 0] = [0, 0.85, 0.93, 0.75]
    ax.imshow(flood_rgba, extent=extent, aspect="equal", interpolation="nearest")
    _title(ax, "FLOOD EXTENT")
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    ax.set_ylabel("Latitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    # ── Right: water depth ──
    ax = axes[1]
    _terrain_bg(ax, dem, extent)
    if depth.max() > 0.01:
        masked = np.ma.masked_where(depth < 0.01, depth)
        im = ax.imshow(masked, cmap=DEPTH_CMAP, vmin=0, vmax=MAX_WATER_DEPTH_M,
                       extent=extent, aspect="equal", alpha=0.85)
        _colorbar(fig, im, ax, "Water Depth (m)")
    _title(ax, "ESTIMATED WATER DEPTH")
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    _add_stats_box(axes[1], [
        f"Max:    {depth_stats['max_depth_m']:.2f} m",
        f"Mean:   {depth_stats['mean_depth_m']:.2f} m",
        f"Median: {depth_stats['median_depth_m']:.2f} m",
        f"Volume: {depth_stats['volume_m3']:,.0f} m\u00b3",
    ], x=0.02, y=0.98, fontsize=9)

    _suptitle(fig, "MODIS FLOOD EXTENT & WATER DEPTH",
              f"Max depth: {depth_stats['max_depth_m']:.2f} m  |  "
              f"Mean: {depth_stats['mean_depth_m']:.2f} m  |  "
              f"Volume: {depth_stats['volume_m3']:,.0f} m\u00b3")
    _watermark(fig)
    return _savefig(fig, "modis_depth.png")


def fig_modis_road_impact(streets_gdf, flood_mask, dem, bbox, street_summary):
    """Road network: RED = affected, gray = dry, over terrain."""
    fig, ax = _fig(rows=1, cols=1, w=14, h=11)
    ax = ax[0]

    extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]
    _terrain_bg(ax, dem, extent)

    # light cyan flood background
    flood_rgba = np.zeros((*flood_mask.shape, 4))
    flood_rgba[flood_mask > 0] = [0, 0.85, 0.93, 0.3]
    ax.imshow(flood_rgba, extent=extent, aspect="equal", interpolation="nearest")

    # draw roads
    if streets_gdf is not None:
        for _, row in streets_gdf.iterrows():
            geom = row.geometry
            if geom is None:
                continue
            is_flooded = row.get("flood_class", "dry") != "dry"
            color = "#FF2D2D" if is_flooded else "#4A5568"
            lw = 2.2 if is_flooded else 0.6
            alpha = 0.95 if is_flooded else 0.4
            zorder = 5 if is_flooded else 3

            lines = [geom] if geom.geom_type == "LineString" else (
                geom.geoms if geom.geom_type == "MultiLineString" else [])
            for line in lines:
                xs, ys = line.xy
                ax.plot(xs, ys, color=color, linewidth=lw, alpha=alpha,
                        zorder=zorder, solid_capstyle="round")

    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    ax.set_xlabel("Longitude", color=PAL["text2"], fontsize=9)
    ax.set_ylabel("Latitude", color=PAL["text2"], fontsize=9)
    _ticks(ax)

    total_km = street_summary.get("total_km", 0)
    flooded_km = street_summary.get("flooded_km", 0)
    pct = street_summary.get("pct_flooded", 0)

    _add_stats_box(ax, [
        f"ROAD NETWORK IMPACT",
        f"Total:    {total_km:.1f} km",
        f"Affected: {flooded_km:.1f} km  ({pct:.1f}%)",
        f"Safe:     {total_km - flooded_km:.1f} km",
    ])

    from matplotlib.lines import Line2D
    ax.legend(handles=[
        Line2D([0], [0], color="#FF2D2D", linewidth=3, label=f"Affected ({flooded_km:.1f} km)"),
        Line2D([0], [0], color="#4A5568", linewidth=1.2, alpha=0.5, label=f"Unaffected ({total_km - flooded_km:.1f} km)"),
    ], loc="lower right", fontsize=10, framealpha=0.7,
       facecolor=PAL["navy"], edgecolor=PAL["border"], labelcolor=PAL["text"])

    _suptitle(fig, "ROAD NETWORK FLOOD IMPACT",
              f"{flooded_km:.1f} km affected  |  {total_km:.1f} km total  |  {pct:.1f}% impacted")
    _watermark(fig)
    return _savefig(fig, "modis_roads.png")


def fig_modis_summary(stats, modis_stats, precip, depth_stats, street_summary):
    """MODIS summary dashboard — single professional figure."""
    fig = plt.figure(figsize=(18, 10), facecolor=PAL["bg"])
    gs = fig.add_gridspec(2, 3, hspace=0.35, wspace=0.3,
                          left=0.06, right=0.96, top=0.88, bottom=0.06)

    roi = stats.get("roi_km2", 0)
    flood_km2 = stats.get("methods", {}).get("modis", {}).get("flooded_km2", 0)
    flood_pct = stats.get("methods", {}).get("modis", {}).get("pct_flooded", 0)

    # ── 1. Flood extent gauge ──
    ax = fig.add_subplot(gs[0, 0])
    ax.set_facecolor(PAL["card"])
    for sp in ax.spines.values(): sp.set_color(PAL["border"]); sp.set_linewidth(0.6)
    theta = np.linspace(0, np.pi, 100)
    ax.plot(np.cos(theta), np.sin(theta), color=PAL["border"], linewidth=8,
            solid_capstyle="round")
    fill_angle = np.pi * min(flood_pct / 100, 1.0)
    theta_fill = np.linspace(0, fill_angle, 50)
    ax.plot(np.cos(theta_fill), np.sin(theta_fill), color=PAL["cyan"],
            linewidth=8, solid_capstyle="round")
    ax.text(0, 0.15, f"{flood_km2:.2f}", fontsize=28, fontweight="900",
            color=PAL["cyan"], ha="center", va="center", fontfamily="monospace")
    ax.text(0, -0.15, "km\u00b2 flooded", fontsize=10, color=PAL["text2"],
            ha="center", va="center")
    ax.set_xlim(-1.3, 1.3); ax.set_ylim(-0.4, 1.3)
    ax.set_aspect("equal"); ax.axis("off")
    _title(ax, "FLOOD EXTENT")

    # ── 2. Precipitation bar ──
    ax = fig.add_subplot(gs[0, 1])
    ax.set_facecolor(PAL["card"])
    for sp in ax.spines.values(): sp.set_color(PAL["border"]); sp.set_linewidth(0.6)
    daily = precip.get("daily_mm", [])
    dates = precip.get("dates", [])
    intensity = precip.get("intensity", [])
    bc = {"dry": PAL["precip_dry"], "light": PAL["precip_light"],
          "moderate": PAL["precip_moderate"], "heavy": PAL["precip_heavy"],
          "extreme": PAL["precip_extreme"]}
    colors = [bc.get(i, PAL["precip_dry"]) for i in intensity]
    x = np.arange(len(daily))
    ax.bar(x, daily, color=colors, edgecolor="none", width=0.75)
    ax.set_xticks(x[::max(1, len(x)//6)])
    ax.set_xticklabels([d[5:] for d in dates][::max(1, len(x)//6)],
                       rotation=45, ha="right", fontsize=7)
    _title(ax, f"PRECIPITATION  ({precip.get('total_mm',0):.0f} mm total)")
    _ticks(ax)

    # ── 3. Depth histogram ──
    ax = fig.add_subplot(gs[0, 2])
    ax.set_facecolor(PAL["card"])
    for sp in ax.spines.values(): sp.set_color(PAL["border"]); sp.set_linewidth(0.6)
    if depth_stats.get("max_depth_m", 0) > 0:
        ax.text(0.5, 0.6, f"{depth_stats['max_depth_m']:.2f} m",
                fontsize=32, fontweight="900", color=PAL["accent"],
                ha="center", va="center", transform=ax.transAxes, fontfamily="monospace")
        ax.text(0.5, 0.35, "max depth", fontsize=10, color=PAL["text2"],
                ha="center", va="center", transform=ax.transAxes)
        ax.text(0.25, 0.12, f"Mean: {depth_stats['mean_depth_m']:.2f} m",
                fontsize=9, color=PAL["text3"], ha="center", transform=ax.transAxes)
        ax.text(0.75, 0.12, f"Vol: {depth_stats['volume_m3']:,.0f} m\u00b3",
                fontsize=9, color=PAL["text3"], ha="center", transform=ax.transAxes)
    else:
        ax.text(0.5, 0.5, "No depth data", fontsize=12, color=PAL["text3"],
                ha="center", va="center", transform=ax.transAxes)
    ax.axis("off")
    _title(ax, "WATER DEPTH")

    # ── 4. MODIS info ──
    ax = fig.add_subplot(gs[1, 0])
    ax.set_facecolor(PAL["card"])
    for sp in ax.spines.values(): sp.set_color(PAL["border"]); sp.set_linewidth(0.6)
    info_lines = [
        ("Source", "MCDWD_L3_F3_NRT"),
        ("Date", modis_stats.get("date", "—")),
        ("Resolution", "250 m"),
        ("ROI", f"{roi:.1f} km\u00b2"),
        ("Flood pixels", f"{modis_stats.get('flood_pixels', 0):,}"),
        ("Risk score", f"{precip.get('risk_score', 0)}/100"),
    ]
    for i, (k, v) in enumerate(info_lines):
        y = 0.88 - i * 0.14
        ax.text(0.05, y, k, fontsize=9, color=PAL["text3"],
                transform=ax.transAxes, fontweight="600")
        ax.text(0.95, y, v, fontsize=10, color=PAL["text"],
                transform=ax.transAxes, ha="right", fontfamily="monospace", fontweight="700")
    ax.axis("off")
    _title(ax, "ANALYSIS INFO")

    # ── 5. Road impact ──
    ax = fig.add_subplot(gs[1, 1])
    ax.set_facecolor(PAL["card"])
    for sp in ax.spines.values(): sp.set_color(PAL["border"]); sp.set_linewidth(0.6)
    if street_summary and street_summary.get("total_km", 0) > 0:
        total = street_summary["total_km"]
        flooded = street_summary.get("flooded_km", 0)
        safe = total - flooded
        ax.barh(["Affected", "Safe"], [flooded, safe],
                color=["#FF2D2D", PAL["deep2"]], edgecolor="none", height=0.5)
        ax.text(flooded + 0.5, 0, f"{flooded:.1f} km", fontsize=10, fontweight="700",
                color="#FF2D2D", va="center")
        ax.text(safe + 0.5, 1, f"{safe:.1f} km", fontsize=10, fontweight="700",
                color=PAL["text2"], va="center")
        _ticks(ax)
    else:
        ax.text(0.5, 0.5, "No road data", fontsize=12, color=PAL["text3"],
                ha="center", va="center", transform=ax.transAxes)
        ax.axis("off")
    _title(ax, "ROAD IMPACT")

    # ── 6. Risk gauge ──
    ax = fig.add_subplot(gs[1, 2])
    ax.set_facecolor(PAL["card"])
    for sp in ax.spines.values(): sp.set_color(PAL["border"]); sp.set_linewidth(0.6)
    risk = precip.get("risk_score", 0)
    rp = precip.get("return_period_est", "—")
    theta = np.linspace(0, np.pi, 100)
    ax.plot(np.cos(theta), np.sin(theta), color=PAL["border"], linewidth=8,
            solid_capstyle="round")
    fill_angle = np.pi * risk / 100
    theta_fill = np.linspace(0, fill_angle, 50)
    rc = PAL["deep3"] if risk > 70 else PAL["deep"] if risk > 40 else PAL["accent"]
    ax.plot(np.cos(theta_fill), np.sin(theta_fill), color=rc, linewidth=8,
            solid_capstyle="round")
    ax.text(0, 0.15, f"{risk}", fontsize=32, fontweight="900",
            color=rc, ha="center", va="center", fontfamily="monospace")
    ax.text(0, -0.15, f"risk score  |  {rp}", fontsize=9, color=PAL["text2"],
            ha="center", va="center")
    ax.set_xlim(-1.3, 1.3); ax.set_ylim(-0.4, 1.3)
    ax.set_aspect("equal"); ax.axis("off")
    _title(ax, "FLOOD RISK")

    _suptitle(fig, "MODIS NRT FLOOD ANALYSIS — SUMMARY DASHBOARD",
              f"ROI: {roi:.1f} km\u00b2  |  Flooded: {flood_km2:.2f} km\u00b2  |  "
              f"Risk: {precip.get('risk_score',0)}/100  |  {modis_stats.get('date','')}")
    _watermark(fig)
    return _savefig(fig, "modis_summary.png")
