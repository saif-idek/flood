"""
╔══════════════════════════════════════════════════════════════════════╗
║              UAE FloodMap – Configuration & Constants               ║
║  SAR-based Flood Detection Platform for the United Arab Emirates   ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import os
from dotenv import load_dotenv
load_dotenv()

# ── Sentinel Hub (CDSE) ──────────────────────────────────────────────
CLIENT_ID      = os.environ.get("SH_CLIENT_ID", "")
CLIENT_SECRET  = os.environ.get("SH_CLIENT_SECRET", "")
SH_BASE_URL    = "https://sh.dataspace.copernicus.eu"
SH_TOKEN_URL   = ("https://identity.dataspace.copernicus.eu"
                  "/auth/realms/CDSE/protocol/openid-connect/token")

# ── Mapbox ───────────────────────────────────────────────────────────
MAPBOX_TOKEN = os.environ.get("MAPBOX_TOKEN", "")

# ── NASA EarthData ───────────────────────────────────────────────────
EARTHDATA_USER = os.environ.get("EARTHDATA_USER", "")
EARTHDATA_PASS = os.environ.get("EARTHDATA_PASS", "")

# ── SAR Processing (ΔSAR change-only detector) ───────────────────────
RESOLUTION_M        = 20
# Detection threshold on the *most-darkened* polarisation:
#     min(ΔVV, ΔVH)  < THRESHOLD_DB  → flood candidate.
# −2.5 dB is below the typical 1-σ SAR speckle (≈ ±0.7 dB after Refined
# Lee) and above the natural ag-cycle / wind-roughness band — it isolates
# the deterministic darkening that comes from new standing water.
THRESHOLD_DB        = -2.5
# Per-dB depth scale for the SAR-change → water-depth proxy. With
# DEPTH_SCALE_M_PER_DB = 0.04 m/dB and THRESHOLD_DB = −2.5 dB:
#     ΔSAR  −10 dB → 0.30 m       −15 dB → 0.50 m       −25 dB → 0.90 m
# Calibrated against the canonical observation that fully-inundated open
# floodplains drop ~10–20 dB and rarely exceed ~1 m of standing water.
DEPTH_SCALE_M_PER_DB = 0.04
# Auto-thresholding: when True, Otsu is run on the ΔSAR distribution and
# its threshold is used (provided the histogram is sufficiently bimodal).
# When False — or when Otsu rejects the histogram — THRESHOLD_DB is used.
AUTO_THRESHOLD       = True
# Bhattacharyya overlap ceiling for accepting Otsu. Otsu's threshold is
# only honoured when the two sub-distributions are well-separated;
# unimodal histograms (no flood signal in the scene) fall back to manual T.
BHATTACHARYYA_MIN    = 0.75
# Region-growing seed offset. Pixels with ΔSAR < (T_otsu + SEED_OFFSET_DB)
# form the high-confidence core; the broader (ΔSAR < T_otsu) set is
# accepted only where 4-connected to the core, killing isolated speckle.
SEED_OFFSET_DB       = -2.0
# Valid backscatter range — masks radar shadow / corner-reflector spikes.
VV_VALID_MIN_DB     = -30.0
VV_VALID_MAX_DB     =  -5.0
SPECKLE_WINDOW      = 7
# Slope filter — water cannot pool on steep terrain and slopes facing
# away from the sensor produce radar-shadow false positives that mimic
# the very dB drop we are detecting. 8° is the working ceiling for the
# UAE (mostly < 5°), loose enough to keep wadi-edge floods.
MAX_FLOOD_SLOPE_DEG = 8.0
# Minimum connected-component flood area — drops single-pixel speckle
# noise without erasing fragmented urban flood patches (Dubai 2024 has
# many half-block-sized inundations).
MIN_FLOOD_AREA_M2   = 1500.0

# ── Precipitation ────────────────────────────────────────────────────
PRECIP_LOOKBACK_DAYS = 14          # days before flood to analyse
PRECIP_HEAVY_THRESH  = 20.0        # mm/day = heavy rain
PRECIP_EXTREME_THRESH = 50.0       # mm/day = extreme rain

# ── DEM & Water Depth ────────────────────────────────────────────────
DEM_SMOOTHING_PX    = 3
# Physical cap on water depth (metres).  0.5 m was a legacy display-only
# cap that silently truncated every depth.  Urban flash floods (Abu Dhabi
# Apr 2024, Dubai 2024) peaked at 1.5–2.5 m; 3 m leaves head-room without
# breaking the colormap.
MAX_WATER_DEPTH_M   = 3.0
# Rainfall-runoff coefficient — fraction of precipitation that becomes
# surface runoff.  Mixed urban / paved UAE surface ≈ 0.5 (0.7+ for dense
# city centre, 0.1–0.2 for sand/open desert).
RUNOFF_COEFF        = 0.5
# ── Hydrology (HEC-HMS-style depth model) ────────────────────────────
# SCS Curve Number — drives the rainfall→runoff transformation.
# UAE defaults: 78 = mixed urban/desert, 92 = dense urban, 70 = bare soil.
CURVE_NUMBER        = 82
# Manning's roughness coefficient for sheet-flow kinematic-wave depth.
# 0.030 = paved · 0.035 = mixed urban · 0.05 = grass / shrub.
MANNING_N           = 0.035
# Storm duration over which the SCS-CN runoff is delivered (hours).
# For UAE flash floods Apr 2024 / Mar 2026: heavy phase ≈ 6 h.
STORM_DURATION_H    = 6.0
NDWI_WATER_THRESH   = 0.30
# Legacy alias — derived from MIN_FLOOD_AREA_M2 at the configured
# resolution. Kept so postprocessing.clean_mask still imports it cleanly.
MIN_FLOOD_PIXELS    = max(1, int(round(MIN_FLOOD_AREA_M2 / (RESOLUTION_M ** 2))))

# ── Street / OSM ─────────────────────────────────────────────────────
OSM_ROAD_TAGS  = ["motorway", "trunk", "primary", "secondary",
                  "tertiary", "residential", "unclassified"]
STREET_BUFFER_M = 15

# ── MODIS NRT ────────────────────────────────────────────────────────
MODIS_FLOOD_BASE = ("https://nrt3.modaps.eosdis.nasa.gov"
                    "/archive/allData/61/MCDWD_L3_F3_NRT")
MODIS_TILE_H = 22
MODIS_TILE_V = 6

# ── GPM IMERG ────────────────────────────────────────────────────────
GPM_BASE = ("https://gpm1.gesdisc.eosdis.nasa.gov/opendap/GPM_L3"
            "/GPM_3IMERGDF.07")

# ── Output ───────────────────────────────────────────────────────────
OUTPUT_DIR  = "outputs"
FIGURE_DPI  = 180
os.makedirs(OUTPUT_DIR, exist_ok=True)
