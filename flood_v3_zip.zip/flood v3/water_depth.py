"""
╔══════════════════════════════════════════════════════════════════════╗
║         UAE FloodMap – Water Depth Estimation Engine                ║
║  DEM-based simulation · Backscatter weighting · Altimetry bias     ║
║  Precipitation correction · Depth classification                   ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, numpy as np
from scipy.ndimage import (gaussian_filter, distance_transform_edt,
                           binary_erosion)
from config import DEM_SMOOTHING_PX, MAX_WATER_DEPTH_M, RESOLUTION_M

L = logging.getLogger("flood.depth")

def simulate_water_depth(flood_mask, dem, backscatter_diff=None,
                         precip_total_mm=0.0):
    """
    Estimate water depth within flooded areas using:
      1. DEM-based water surface elevation from flood boundary
      2. Backscatter-weighted depth (stronger dB drop = deeper)
      3. Precipitation volume correction
    """
    mask = flood_mask.astype(bool)
    depth = np.zeros_like(dem, dtype=np.float32)

    if mask.sum() == 0:
        stats = {
            "max_depth_m": 0.0, "mean_depth_m": 0.0,
            "median_depth_m": 0.0, "volume_m3": 0.0,
        }
        return depth, stats

    # smooth DEM
    dem_s = gaussian_filter(dem, sigma=DEM_SMOOTHING_PX)

    # flood boundary pixels
    eroded = binary_erosion(mask, iterations=1)
    boundary = mask & ~eroded
    if boundary.sum() == 0:
        boundary = mask

    # water surface elevation from boundary
    boundary_elev = dem_s.copy()
    boundary_elev[~boundary] = np.nan
    mean_boundary_elev = np.nanmean(boundary_elev)

    # distance from flood boundary (pixels) — deeper toward center
    dist = distance_transform_edt(~boundary)
    max_dist = max(float(dist[mask].max()), 1.0)

    # --- Component 1: DEM-based depth (boundary elev - local elev) ---
    base_depth = mean_boundary_elev - dem_s
    base_depth = np.clip(base_depth, 0, MAX_WATER_DEPTH_M)

    # detect flat terrain: if DEM range within flood is < 2m, the DEM-only
    # approach gives near-zero depths — supplement with distance model
    dem_flood_range = float(np.ptp(dem_s[mask]))
    is_flat = dem_flood_range < 2.0
    L.info(f"DEM flood range: {dem_flood_range:.2f}m ({'flat' if is_flat else 'varied'} terrain)")

    # --- Component 2: Distance-from-edge depth model ---
    # deeper toward the interior of the flood; max at center
    dist_depth = (dist / max_dist) * MAX_WATER_DEPTH_M * 0.6
    dist_depth = np.clip(dist_depth, 0, MAX_WATER_DEPTH_M)

    # --- Component 3: Backscatter weighting ---
    if backscatter_diff is not None:
        bs = backscatter_diff.copy()
        bs_masked = bs[mask]
        bs_min = float(np.nanpercentile(bs_masked, 2)) if len(bs_masked) > 0 else -10
        bs_max = float(np.nanpercentile(bs_masked, 98)) if len(bs_masked) > 0 else 0
        bs_range = max(abs(bs_max - bs_min), 0.1)
        bs_weight = (bs - bs_min) / bs_range
        bs_weight = np.clip(1 - bs_weight, 0.2, 1.0)  # invert: lower dB = deeper
    else:
        bs_weight = np.ones_like(dem)

    # --- Component 4: Precipitation-driven base water level ---
    # runoff coefficient ~0.3 for urban, ~0.1 for desert; use 0.15 avg
    precip_depth_m = precip_total_mm * 0.001 * 0.15  # effective ponding depth
    precip_depth_m = min(precip_depth_m, MAX_WATER_DEPTH_M * 0.3)

    # --- Blend components based on terrain type ---
    if is_flat:
        # flat terrain: DEM contributes little, rely more on distance + backscatter
        depth[mask] = (0.2 * base_depth[mask]
                       + 0.45 * dist_depth[mask]
                       + 0.35 * (bs_weight[mask] * MAX_WATER_DEPTH_M * 0.5)
                       + precip_depth_m)
    else:
        # varied terrain: DEM is reliable
        depth[mask] = (0.55 * base_depth[mask]
                       + 0.15 * dist_depth[mask]
                       + 0.30 * (bs_weight[mask] * base_depth[mask])
                       + precip_depth_m)

    depth = np.clip(depth, 0, MAX_WATER_DEPTH_M)
    depth[~mask] = 0

    stats = {
        "max_depth_m": float(np.max(depth)),
        "mean_depth_m": float(np.mean(depth[mask])) if mask.sum() > 0 else 0,
        "median_depth_m": float(np.median(depth[mask])) if mask.sum() > 0 else 0,
        "volume_m3": float(depth.sum() * RESOLUTION_M * RESOLUTION_M),
    }
    L.info(f"Water depth: max={stats['max_depth_m']:.2f}m, "
           f"mean={stats['mean_depth_m']:.2f}m, vol≈{stats['volume_m3']:.0f}m³")
    return depth, stats

def incorporate_altimetry(water_depth, dem, flood_mask, altimetry_stations, bbox):
    """Bias-correct water depth with altimetry observations."""
    if not altimetry_stations:
        return water_depth, {"bias_correction": 0, "n_stations": 0}
    mask = flood_mask.astype(bool)
    dem_s = gaussian_filter(dem, sigma=DEM_SMOOTHING_PX)
    biases = []
    for s in altimetry_stations:
        ts = s.get("timeseries", [])
        if not ts: continue
        levels = [t["water_level"] for t in ts if "water_level" in t]
        if not levels: continue
        obs_level = np.mean(levels)
        # map station to pixel
        lat, lon = s.get("lat"), s.get("lon")
        if lat is None or lon is None: continue
        py = int((bbox.max_y - lat) / (bbox.max_y - bbox.min_y) * dem.shape[0])
        px = int((lon - bbox.min_x) / (bbox.max_x - bbox.min_x) * dem.shape[1])
        py = np.clip(py, 0, dem.shape[0]-1)
        px = np.clip(px, 0, dem.shape[1]-1)
        sim_wse = dem_s[py, px] + water_depth[py, px]
        biases.append(obs_level - sim_wse)

    if not biases:
        return water_depth, {"bias_correction": 0, "n_stations": 0}

    mean_bias = np.mean(biases)
    corrected = water_depth.copy()
    corrected[mask] += mean_bias
    corrected = np.clip(corrected, 0, MAX_WATER_DEPTH_M)
    corrected[~mask] = 0

    info = {"bias_correction": float(mean_bias),
            "n_stations": len(biases)}
    L.info(f"Altimetry correction: bias={mean_bias:.3f}m from {len(biases)} stations")
    return corrected, info

def classify_depth(depth_m):
    """Classify water depth into severity bands."""
    if depth_m < 0.05: return "dry", "#808080"
    if depth_m < 0.15: return "shallow", "#AED8F0"
    if depth_m < 0.35: return "low", "#5BAEE6"
    if depth_m < 0.65: return "moderate", "#2E7BBF"
    if depth_m < 1.00: return "deep", "#1A4D8F"
    if depth_m < 1.50: return "very_deep", "#0D2B5E"
    return "critical", "#4A0020"

DEPTH_BANDS = [
    (0.02,  "dry",       "#808080"),
    (0.05,  "shallow",   "#BAE6FD"),
    (0.10,  "low",       "#7DD3FC"),
    (0.20,  "moderate",  "#38BDF8"),
    (0.35,  "deep",      "#0EA5E9"),
    (0.50,  "very_deep", "#0369A1"),
    (999,   "critical",  "#0C4A6E"),
]
