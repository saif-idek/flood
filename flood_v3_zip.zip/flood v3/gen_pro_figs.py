#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║   Abu Dhabi — Professional Flood Maps with Real OSM Shapefiles         ║
║   Ocean in cyan · Roads as vector shapefile overlay on raster DEM      ║
║   Output: New_Figs/                                                    ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
import sys, os, time, logging, pickle, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s")
L = logging.getLogger("figs.pro")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import matplotlib.patheffects as pe
import geopandas as gpd
from shapely.geometry import box

from config import *
import config
config.RESOLUTION_M = 40
config.MAX_WATER_DEPTH_M = 0.50

from sentinelhub import BBox, CRS, bbox_to_dimensions

BBOX = [54.1607, 24.1658, 54.8407, 24.6735]
bbox = BBox(bbox=BBOX, crs=CRS.WGS84)
extent = [bbox.min_x, bbox.max_x, bbox.min_y, bbox.max_y]
OUT = "New_Figs"
DPI = 220

# ═══════════════════════════════════════════════════════════════════
#  PALETTE
# ═══════════════════════════════════════════════════════════════════
BG      = "#060D1A"
CARD    = "#0C1425"
GRID    = "#162033"
BORDER  = "#253045"
TEXT    = "#E8EDF5"
TEXT2   = "#8899B0"
TEXT3   = "#556680"
NAVY    = "#0A1020"
OCEAN   = "#0E4D6E"
OCEAN_L = "#12708F"
LAND    = "#1A2235"
CYAN    = "#00E5FF"

DEPTH_CMAP = LinearSegmentedColormap.from_list("pro_depth", [
    (0.00, "#060D1A"),
    (0.02, "#0A2E4A"),
    (0.08, "#0C5C7A"),
    (0.18, "#00BCD4"),
    (0.30, "#00E5FF"),
    (0.45, "#FFEB3B"),
    (0.62, "#FF9800"),
    (0.80, "#F44336"),
    (1.00, "#B71C1C"),
])

STREET_SEV = {
    "dry":      {"color": "#344560", "lw": 0.25, "z": 1, "label": "Dry"},
    "low":      {"color": "#FDD835", "lw": 1.2,  "z": 3, "label": "Low"},
    "medium":   {"color": "#FF9800", "lw": 1.8,  "z": 4, "label": "Medium"},
    "high":     {"color": "#F44336", "lw": 2.5,  "z": 5, "label": "High"},
    "critical": {"color": "#B71C1C", "lw": 3.2,  "z": 6, "label": "Critical"},
}

# ═══════════════════════════════════════════════════════════════════
#  LOAD OR COMPUTE DATA
# ═══════════════════════════════════════════════════════════════════
L.info("Loading DEM…")
from downloader import download_dem
dem = download_dem(bbox, resolution=40)

L.info("Computing flood simulation…")
from scipy.ndimage import gaussian_filter
from flood_sim import flow_accumulation

dem_s = gaussian_filter(dem, sigma=3)
flow_acc = flow_accumulation(dem_s, smooth_sigma=3)

dem_norm = (dem_s - dem_s.min()) / max(dem_s.max() - dem_s.min(), 1)
fa_norm = np.log1p(flow_acc)
fa_norm = (fa_norm - fa_norm.min()) / max(fa_norm.max() - fa_norm.min(), 1)
susceptibility = 0.6 * fa_norm + 0.4 * (1.0 - dem_norm)

thresh = np.percentile(susceptibility, 60)
flood_mask = (susceptibility >= thresh).astype(np.uint8)
flood_mask[dem < -2] = 0
flooded = flood_mask.astype(bool)

depth = np.zeros_like(dem, dtype=np.float32)
if flooded.sum() > 0:
    s_f = susceptibility[flooded]
    s_min, s_max = s_f.min(), s_f.max()
    s_range = max(s_max - s_min, 0.01)
    depth[flooded] = ((susceptibility[flooded] - s_min) / s_range) * 0.45 + 0.02
    depth[flooded] += 158.0 * 0.001 * 0.30 * 0.3
    depth = np.clip(depth, 0, 0.50)
    depth[~flooded] = 0

pixel_area = 40 * 40
flood_km2 = flooded.sum() * pixel_area / 1e6
volume = depth.sum() * pixel_area

# Ocean mask (DEM < -1m near coast)
ocean_mask = dem < -1.0

L.info("Loading streets from OSM…")
from streets import download_osm_streets, compute_street_water_depth, flooded_streets_summary
streets = download_osm_streets(bbox)
L.info(f"Got {len(streets)} road segments")

gdf = compute_street_water_depth(streets, depth, bbox)
summary = flooded_streets_summary(gdf)
L.info(f"Roads: {summary['flooded_km']:.1f}/{summary['total_km']:.1f} km")

# ═══════════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════
def hillshade(d, az=315, alt=35):
    dy, dx = np.gradient(d)
    slope = np.sqrt(dx**2 + dy**2)
    aspect = np.arctan2(-dy, dx)
    a, b = np.radians(az), np.radians(alt)
    return np.clip(np.sin(b)*np.cos(slope) + np.cos(b)*np.sin(slope)*np.cos(a-aspect), 0, 1)

def render_basemap(ax):
    """Professional basemap: terrain + ocean in cyan."""
    hs = hillshade(dem_s)
    # land
    rgb = np.zeros((*hs.shape, 4))
    rgb[:,:,0] = 0.07 + hs * 0.13
    rgb[:,:,1] = 0.09 + hs * 0.16
    rgb[:,:,2] = 0.14 + hs * 0.22
    rgb[:,:,3] = 1.0
    # ocean overlay — deep blue-cyan
    for c in range(3):
        oc = [0.055, 0.30, 0.43][c]  # RGB for OCEAN
        rgb[ocean_mask, c] = oc
    # shallow water fringe (dem -1 to 0)
    shore = (dem >= -1) & (dem < 0.5)
    for c in range(3):
        oc = [0.07, 0.44, 0.56][c]  # lighter cyan fringe
        rgb[shore, c] = oc * 0.7 + rgb[shore, c] * 0.3

    ax.imshow(rgb, extent=extent, aspect="equal", interpolation="bilinear")

def style_ax(ax):
    ax.set_facecolor(CARD)
    for sp in ax.spines.values():
        sp.set_color(BORDER); sp.set_linewidth(0.5)
    ax.tick_params(colors=TEXT2, labelsize=7, length=2, width=0.4)
    ax.grid(True, alpha=0.08, color=GRID, linewidth=0.3)

def stats_box(ax, lines, x=0.015, y=0.985, fs=8.5):
    ax.text(x, y, "\n".join(lines), transform=ax.transAxes, fontsize=fs,
            fontfamily="monospace", fontweight="600", color=TEXT, va="top", ha="left",
            bbox=dict(boxstyle="round,pad=0.6", facecolor=NAVY, edgecolor=BORDER,
                      alpha=0.92, linewidth=0.5))

def title_bar(fig, main, sub):
    fig.suptitle(main, color=TEXT, fontsize=14, fontweight="800",
                 x=0.015, ha="left", y=0.985, fontfamily="sans-serif")
    fig.text(0.015, 0.96, sub, color=TEXT3, fontsize=8.5, ha="left", fontfamily="sans-serif")

def watermark(fig):
    fig.text(0.995, 0.003, "UAE FloodMap v3  ·  DEM + Rainfall-Runoff Model",
             color=TEXT3, fontsize=6, ha="right", va="bottom", alpha=0.35, fontfamily="monospace")

def pro_colorbar(fig, mappable, ax, label, ticks, tick_labels):
    cb = fig.colorbar(mappable, ax=ax, fraction=0.022, pad=0.012, aspect=40)
    cb.set_label(label, color=TEXT2, fontsize=9, labelpad=8)
    cb.ax.tick_params(colors=TEXT2, labelsize=7.5, length=2, width=0.4)
    cb.outline.set_edgecolor(BORDER); cb.outline.set_linewidth(0.4)
    cb.set_ticks(ticks)
    cb.set_ticklabels(tick_labels)
    return cb


# ═══════════════════════════════════════════════════════════════════
#  FIGURE 1 — Water Depth Raster + Ocean
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 1: Water depth raster with ocean…")
fig, ax = plt.subplots(figsize=(20, 16), facecolor=BG)
style_ax(ax)
render_basemap(ax)

masked = np.ma.masked_where(depth < 0.005, depth)
im = ax.imshow(masked, cmap=DEPTH_CMAP, vmin=0, vmax=0.50,
               extent=extent, aspect="equal", alpha=0.88, interpolation="bilinear")

ticks = [0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]
tlabels = ["0", "5", "10", "15", "20", "25", "30", "40", "50 cm"]
pro_colorbar(fig, im, ax, "Simulated Water Height", ticks, tlabels)

ax.set_xlabel("Longitude", color=TEXT2, fontsize=9)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=9)

stats_box(ax, [
    "ABU DHABI FLOOD SIMULATION",
    "━━━━━━━━━━━━━━━━━━━━━━━━━━",
    f"Model      DEM + Rainfall-Runoff",
    f"Precip     158 mm  (30% runoff)",
    f"Flooded    {flood_km2:,.1f} km²",
    f"Max depth  {depth.max():.2f} m",
    f"Mean       {depth[flooded].mean():.2f} m",
    f"Volume     {volume:,.0f} m³",
])

title_bar(fig, "ABU DHABI — SIMULATED WATER HEIGHT",
          f"DEM + 158 mm rainfall  |  {flood_km2:,.1f} km² flooded  |  "
          f"Max {depth.max()*100:.0f} cm  |  Vol {volume/1e6:.1f} M m³")
watermark(fig)
fig.savefig(f"{OUT}/01_water_height.png", dpi=DPI, bbox_inches="tight", facecolor=BG, pad_inches=0.12)
plt.close(fig)
L.info("  ✓ 01_water_height.png")


# ═══════════════════════════════════════════════════════════════════
#  FIGURE 2 — Flood Severity Zones
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 2: Severity zones…")
fig, ax = plt.subplots(figsize=(20, 16), facecolor=BG)
style_ax(ax)
render_basemap(ax)

zones = [
    (0.005, 0.05, "#00BCD4", 0.55, "< 5 cm   (safe)"),
    (0.05,  0.10, "#00E5FF", 0.65, "5–10 cm  (caution)"),
    (0.10,  0.20, "#FFEB3B", 0.70, "10–20 cm (warning)"),
    (0.20,  0.35, "#FF9800", 0.75, "20–35 cm (danger)"),
    (0.35,  9.99, "#F44336", 0.80, "> 35 cm  (critical)"),
]
handles = []
for lo, hi, color, alpha, label in zones:
    zmask = (depth >= lo) & (depth < hi)
    if zmask.sum() == 0: continue
    rgba = np.zeros((*depth.shape, 4))
    r, g, b = int(color[1:3],16)/255, int(color[3:5],16)/255, int(color[5:7],16)/255
    rgba[zmask] = [r, g, b, alpha]
    ax.imshow(rgba, extent=extent, aspect="equal", interpolation="nearest")
    zkm2 = zmask.sum() * pixel_area / 1e6
    handles.append(Patch(facecolor=color, alpha=alpha, edgecolor="none",
                         label=f"{label}   {zkm2:,.1f} km²"))

ax.legend(handles=handles, loc="lower left", fontsize=9.5, framealpha=0.92,
          facecolor=NAVY, edgecolor=BORDER, labelcolor=TEXT,
          title="Flood Severity Classification",
          title_fontproperties={"weight": "bold", "size": 10})
ax.set_xlabel("Longitude", color=TEXT2, fontsize=9)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=9)

title_bar(fig, "ABU DHABI — FLOOD SEVERITY ZONES",
          f"Classified by simulated water height  |  {flood_km2:,.1f} km² total flooded")
watermark(fig)
fig.savefig(f"{OUT}/02_severity_zones.png", dpi=DPI, bbox_inches="tight", facecolor=BG, pad_inches=0.12)
plt.close(fig)
L.info("  ✓ 02_severity_zones.png")


# ═══════════════════════════════════════════════════════════════════
#  FIGURE 3 — Street Severity (shapefile overlay)
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 3: Street severity shapefile overlay…")
fig, ax = plt.subplots(figsize=(20, 16), facecolor=BG)
style_ax(ax)
render_basemap(ax)

# faint depth raster behind roads
masked2 = np.ma.masked_where(depth < 0.005, depth)
ax.imshow(masked2, cmap=DEPTH_CMAP, vmin=0, vmax=0.5, extent=extent,
          aspect="equal", alpha=0.18, interpolation="bilinear")

# roads as LineCollection (fast for 111k segments)
order = ["dry", "low", "medium", "high", "critical"]
for cls in order:
    s = STREET_SEV[cls]
    sub = gdf[gdf["flood_class"] == cls]
    if len(sub) == 0: continue
    segs = []
    for geom in sub.geometry:
        if geom is None: continue
        lines = [geom] if geom.geom_type == "LineString" else (
            geom.geoms if geom.geom_type == "MultiLineString" else [])
        for line in lines:
            coords = list(line.coords)
            if len(coords) >= 2:
                segs.append(coords)
    if segs:
        lc = LineCollection(segs, colors=s["color"], linewidths=s["lw"],
                            alpha=0.9, capstyle="round", zorder=s["z"])
        ax.add_collection(lc)

ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.set_xlabel("Longitude", color=TEXT2, fontsize=9)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=9)

# legend with km per class
leg_items = []
for cls in order:
    s = STREET_SEV[cls]
    sub = gdf[gdf["flood_class"] == cls]
    km = sub["length_m"].sum() / 1000
    if len(sub) > 0:
        leg_items.append(Line2D([0], [0], color=s["color"], linewidth=max(s["lw"]*1.5, 2),
                                label=f"{s['label']:10s} {km:>8,.1f} km  ({len(sub):>6,} roads)"))

ax.legend(handles=leg_items, loc="lower left", fontsize=9, framealpha=0.92,
          facecolor=NAVY, edgecolor=BORDER, labelcolor=TEXT,
          title="Road Flood Severity", prop={"family": "monospace"},
          title_fontproperties={"weight": "bold", "size": 10, "family": "sans-serif"})

stats_box(ax, [
    "ROAD NETWORK ASSESSMENT",
    "━━━━━━━━━━━━━━━━━━━━━━━━━━",
    f"Total       {summary['total_km']:>10,.1f} km",
    f"Affected    {summary['flooded_km']:>10,.1f} km  ({summary['pct_flooded']:.1f}%)",
    f"Safe        {summary['total_km']-summary['flooded_km']:>10,.1f} km",
    f"Segments    {len(gdf):>10,}",
])

title_bar(fig, "ABU DHABI — STREET-LEVEL FLOOD SEVERITY",
          f"{summary['flooded_km']:,.1f} km affected  |  {summary['total_km']:,.1f} km total  |  "
          f"{len(gdf):,} road segments  |  Shapefile over DEM raster")
watermark(fig)
fig.savefig(f"{OUT}/03_street_severity.png", dpi=DPI, bbox_inches="tight", facecolor=BG, pad_inches=0.12)
plt.close(fig)
L.info("  ✓ 03_street_severity.png")


# ═══════════════════════════════════════════════════════════════════
#  FIGURE 4 — Street Continuous Depth (every road = its water height)
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 4: Continuous street depth…")
fig, ax = plt.subplots(figsize=(20, 16), facecolor=BG)
style_ax(ax)
render_basemap(ax)

# collect all segments with their depth values
all_segs = []
all_depths = []
for _, row in gdf.iterrows():
    geom = row.geometry
    if geom is None: continue
    d_val = row["max_depth_m"]
    lines = [geom] if geom.geom_type == "LineString" else (
        geom.geoms if geom.geom_type == "MultiLineString" else [])
    for line in lines:
        coords = list(line.coords)
        if len(coords) >= 2:
            all_segs.append(coords)
            all_depths.append(d_val)

all_depths = np.array(all_depths)
# sort by depth so deepest draw on top
sort_idx = np.argsort(all_depths)
sorted_segs = [all_segs[i] for i in sort_idx]
sorted_depths = all_depths[sort_idx]

# normalize depths
norm = Normalize(vmin=0, vmax=0.50)
colors = DEPTH_CMAP(norm(sorted_depths))
# line widths: thin for dry, thick for deep
lws = 0.2 + sorted_depths / 0.50 * 3.5

lc = LineCollection(sorted_segs, colors=colors, linewidths=lws,
                    capstyle="round", zorder=3)
ax.add_collection(lc)

# colorbar
sm = plt.cm.ScalarMappable(cmap=DEPTH_CMAP, norm=norm)
sm.set_array([])
ticks = [0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]
tlabels = ["0", "5", "10", "15", "20", "25", "30", "40", "50 cm"]
pro_colorbar(fig, sm, ax, "Water Height at Road Surface", ticks, tlabels)

ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.set_xlabel("Longitude", color=TEXT2, fontsize=9)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=9)

# top affected roads table
top = gdf[gdf["max_depth_m"] > 0.01].nlargest(12, "max_depth_m")
if len(top) > 0:
    lines = ["TOP AFFECTED ROADS", "━" * 38]
    for _, r in top.iterrows():
        name = str(r.get("name", "Unnamed"))[:25]
        d_cm = r["max_depth_m"] * 100
        hw = str(r.get("highway", ""))[:10]
        lines.append(f"{name:25s} {d_cm:5.1f} cm  {hw}")
    stats_box(ax, lines, fs=7.5)

title_bar(fig, "ABU DHABI — STREET WATER HEIGHT (CONTINUOUS)",
          f"Every road colored by modeled water depth  |  {len(gdf):,} segments  |  "
          f"Max: {all_depths.max()*100:.0f} cm  |  DEM + 158 mm rainfall")
watermark(fig)
fig.savefig(f"{OUT}/04_street_depth.png", dpi=DPI, bbox_inches="tight", facecolor=BG, pad_inches=0.12)
plt.close(fig)
L.info("  ✓ 04_street_depth.png")


# ═══════════════════════════════════════════════════════════════════
#  FIGURE 5 — Combined: depth raster + street severity overlay
# ═══════════════════════════════════════════════════════════════════
L.info("Figure 5: Combined raster + vector overlay…")
fig, ax = plt.subplots(figsize=(20, 16), facecolor=BG)
style_ax(ax)
render_basemap(ax)

# depth raster
masked3 = np.ma.masked_where(depth < 0.005, depth)
im = ax.imshow(masked3, cmap=DEPTH_CMAP, vmin=0, vmax=0.50,
               extent=extent, aspect="equal", alpha=0.55, interpolation="bilinear")

# affected roads only (skip dry for clarity)
for cls in ["low", "medium", "high", "critical"]:
    s = STREET_SEV[cls]
    sub = gdf[gdf["flood_class"] == cls]
    if len(sub) == 0: continue
    segs = []
    for geom in sub.geometry:
        if geom is None: continue
        lines = [geom] if geom.geom_type == "LineString" else (
            geom.geoms if geom.geom_type == "MultiLineString" else [])
        for line in lines:
            coords = list(line.coords)
            if len(coords) >= 2:
                segs.append(coords)
    if segs:
        lc = LineCollection(segs, colors=s["color"], linewidths=s["lw"]*1.2,
                            alpha=0.95, capstyle="round", zorder=s["z"])
        ax.add_collection(lc)

ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.set_xlabel("Longitude", color=TEXT2, fontsize=9)
ax.set_ylabel("Latitude", color=TEXT2, fontsize=9)

pro_colorbar(fig, im, ax, "Simulated Water Height", ticks, tlabels)

# legend: affected roads only
leg_items = [Patch(facecolor=OCEAN, edgecolor="none", alpha=0.8, label="Ocean")]
for cls in ["low", "medium", "high", "critical"]:
    s = STREET_SEV[cls]
    sub = gdf[gdf["flood_class"] == cls]
    km = sub["length_m"].sum() / 1000
    if len(sub) > 0:
        leg_items.append(Line2D([0], [0], color=s["color"], linewidth=s["lw"]*2,
                                label=f"{s['label']}  ({km:,.1f} km)"))

ax.legend(handles=leg_items, loc="lower left", fontsize=9.5, framealpha=0.92,
          facecolor=NAVY, edgecolor=BORDER, labelcolor=TEXT,
          title="Affected Roads over Flood Depth",
          title_fontproperties={"weight": "bold", "size": 10})

stats_box(ax, [
    "FLOOD + ROAD OVERLAY",
    "━━━━━━━━━━━━━━━━━━━━━━━━━━",
    f"Flood area   {flood_km2:>9,.1f} km²",
    f"Roads hit    {summary['flooded_km']:>9,.1f} km",
    f"Max depth    {depth.max()*100:>9.1f} cm",
    f"Volume       {volume/1e6:>9.1f} M m³",
])

title_bar(fig, "ABU DHABI — FLOOD DEPTH + ROAD SEVERITY OVERLAY",
          f"Raster water height + vector road network  |  {summary['flooded_km']:,.1f} km affected  |  "
          f"Yellow → Orange → Red = increasing severity")
watermark(fig)
fig.savefig(f"{OUT}/05_combined_overlay.png", dpi=DPI, bbox_inches="tight", facecolor=BG, pad_inches=0.12)
plt.close(fig)
L.info("  ✓ 05_combined_overlay.png")


# ═══════════════════════════════════════════════════════════════════
L.info("═" * 60)
L.info("ALL DONE — 5 professional figures in New_Figs/")
L.info(f"  01_water_height.png       — DEM flood depth with ocean")
L.info(f"  02_severity_zones.png     — classified flood zones")
L.info(f"  03_street_severity.png    — roads yellow/orange/red")
L.info(f"  04_street_depth.png       — continuous depth per road")
L.info(f"  05_combined_overlay.png   — raster + vector overlay")
L.info(f"Coverage: {flood_km2:.1f} km², {len(gdf):,} roads, {summary['total_km']:,.1f} km")
L.info("═" * 60)
