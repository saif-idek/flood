"""
╔══════════════════════════════════════════════════════════════════════╗
║         UAE FloodMap – Multi-Source Data Acquisition Engine         ║
║  Sentinel-1 SAR · Sentinel-2 NDWI · Copernicus DEM · ERA5 Precip  ║
║  GPM IMERG · MODIS NRT Flood · DAHITI Altimetry                   ║
║  Auto-tiling for large areas (>2500 px per side)                   ║
║  GEE fallback for S2 when CDSE credentials are expired             ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import logging, os, io, math, datetime as dt, requests, numpy as np
from config import *

# ── GEE fallback toggle ──────────────────────────────────────────────
# Set S2_GEE_FALLBACK=1 (or "true") to enable automatic GEE fallback
# when Sentinel Hub CDSE returns a 401 / any exception.
# Default "1" here so this round's LIVE test works out of the box.
_S2_GEE_FALLBACK = os.environ.get("S2_GEE_FALLBACK", "1").strip().lower() in (
    "1", "true", "yes", "on"
)

L = logging.getLogger("flood.download")

# SH max pixels per dimension
SH_MAX_PX = 2500

# ── Sentinel Hub CDSE Setup ──────────────────────────────────────────
try:
    from sentinelhub import (SHConfig, SentinelHubRequest, DataCollection,
                             MimeType, BBox, CRS, bbox_to_dimensions,
                             SentinelHubCatalog)
    SH_OK = True
except ImportError:
    SH_OK = False; L.warning("sentinelhub not installed")

def _sh_cfg():
    c = SHConfig()
    c.sh_client_id     = CLIENT_ID
    c.sh_client_secret = CLIENT_SECRET
    c.sh_base_url      = SH_BASE_URL
    c.sh_token_url     = SH_TOKEN_URL
    return c

def _col_s1():
    return DataCollection.SENTINEL1_IW.define_from(
        "S1_CDSE", api_id="sentinel-1-grd", service_url=SH_BASE_URL)

def _col_s2():
    return DataCollection.SENTINEL2_L2A.define_from(
        "S2_CDSE", api_id="sentinel-2-l2a", service_url=SH_BASE_URL)

def _col_dem():
    return DataCollection.DEM_COPERNICUS_30.define_from(
        "DEM_CDSE", api_id="dem", service_url=SH_BASE_URL)

# ═════════════════════════════════════════════════════════════════════
#  TILING ENGINE — split large requests into ≤2500 px tiles
# ═════════════════════════════════════════════════════════════════════
def _split_bbox(bbox, resolution):
    """Split a bbox into tiles that each fit within SH_MAX_PX.
    Returns list of (tile_bbox, (row, col), (y_start, x_start), (th, tw))
    and (full_h, full_w)."""
    full_w, full_h = bbox_to_dimensions(bbox, resolution=resolution)
    n_cols = math.ceil(full_w / SH_MAX_PX)
    n_rows = math.ceil(full_h / SH_MAX_PX)

    if n_cols == 1 and n_rows == 1:
        return [(bbox, (0, 0), (0, 0), (full_h, full_w))], (full_h, full_w)

    L.info(f"Tiling: {full_w}x{full_h} px → {n_cols}x{n_rows} tiles")
    lon_range = bbox.max_x - bbox.min_x
    lat_range = bbox.max_y - bbox.min_y

    # compute tile pixel sizes so they sum exactly to full size
    col_widths = []
    for c in range(n_cols):
        cw = full_w // n_cols + (1 if c < full_w % n_cols else 0)
        col_widths.append(cw)
    row_heights = []
    for r in range(n_rows):
        rh = full_h // n_rows + (1 if r < full_h % n_rows else 0)
        row_heights.append(rh)

    # compute geo-extent per tile proportionally
    tiles = []
    y_px = 0
    for r in range(n_rows):
        # geographic rows: r=0 is bottom (min_lat), but image row 0 is top (max_lat)
        frac_y0 = sum(row_heights[:r]) / full_h
        frac_y1 = sum(row_heights[:r + 1]) / full_h
        min_y = bbox.min_y + frac_y0 * lat_range
        max_y = bbox.min_y + frac_y1 * lat_range

        x_px = 0
        for c in range(n_cols):
            frac_x0 = sum(col_widths[:c]) / full_w
            frac_x1 = sum(col_widths[:c + 1]) / full_w
            min_x = bbox.min_x + frac_x0 * lon_range
            max_x = bbox.min_x + frac_x1 * lon_range

            tb = BBox(bbox=[min_x, min_y, max_x, max_y], crs=CRS.WGS84)
            th, tw = row_heights[r], col_widths[c]
            # image y: top of image = max_lat = last geo-row
            img_y = full_h - sum(row_heights[:r + 1])
            tiles.append((tb, (r, c), (img_y, x_px), (th, tw)))
            x_px += tw
        y_px += row_heights[r]

    return tiles, (full_h, full_w)


def _download_tiled(bbox, resolution, make_request_fn):
    """Download data using tiling if needed.
    make_request_fn(tile_bbox, tile_size) -> numpy array for that tile.
    Returns full mosaic array."""
    tiles, (full_h, full_w) = _split_bbox(bbox, resolution)

    if len(tiles) == 1:
        tb, _, _, (th, tw) = tiles[0]
        return make_request_fn(tb, (tw, th))

    # determine output shape from first tile
    first = make_request_fn(tiles[0][0],
                            (tiles[0][3][1], tiles[0][3][0]))
    ndim = first.ndim
    if ndim == 3:
        mosaic = np.zeros((full_h, full_w, first.shape[2]), dtype=first.dtype)
    else:
        mosaic = np.zeros((full_h, full_w), dtype=first.dtype)

    for i, (tb, (r, c), (y0, x0), (th, tw)) in enumerate(tiles):
        if i == 0:
            tile = first
        else:
            tile = make_request_fn(tb, (tw, th))
        # place tile
        ty, tx = tile.shape[0], tile.shape[1]
        y_end = min(y0 + ty, full_h)
        x_end = min(x0 + tx, full_w)
        actual_ty = y_end - y0
        actual_tx = x_end - x0
        if ndim == 3:
            mosaic[y0:y_end, x0:x_end, :] = tile[:actual_ty, :actual_tx, :]
        else:
            mosaic[y0:y_end, x0:x_end] = tile[:actual_ty, :actual_tx]
        L.info(f"  Tile ({r},{c}): {tw}x{th} → placed at ({y0},{x0})")

    return mosaic


# ─────────────────────────────────────────────────────────────────────
#  Sentinel-1 SAR Download (VV + VH, GAMMA0_TERRAIN) — auto-tiled
# ─────────────────────────────────────────────────────────────────────
EVALSCRIPT_S1 = """
//VERSION=3
function setup(){
  return {input:[{bands:["VV","VH"],units:"LINEAR_POWER"}],
          output:{bands:2,sampleType:"FLOAT32"}}
}
function evaluatePixel(s){return [s.VV, s.VH]}
"""

def download_s1(bbox, date_from, date_to, resolution=RESOLUTION_M):
    """Download Sentinel-1 IW GRD backscatter (VV,VH) — auto-tiles for large areas."""
    if not SH_OK: raise RuntimeError("sentinelhub required")

    def _req(tile_bbox, tile_size):
        req = SentinelHubRequest(
            evalscript=EVALSCRIPT_S1,
            input_data=[SentinelHubRequest.input_data(
                data_collection=_col_s1(),
                time_interval=(date_from, date_to),
                other_args={"dataFilter":{"mosaickingOrder":"mostRecent"},
                            "processing":{"orthorectify":True,
                                          "demInstance":"COPERNICUS_30",
                                          "backCoeff":"GAMMA0_TERRAIN",
                                          "speckleFilter":{"type":"NONE"}}})],
            responses=[SentinelHubRequest.output_response("default", MimeType.TIFF)],
            bbox=tile_bbox, size=tile_size, config=_sh_cfg())
        data = req.get_data()
        if not data: raise RuntimeError("No Sentinel-1 data returned")
        return data[0].astype(np.float32)

    arr = _download_tiled(bbox, resolution, _req)
    n_nan = np.isnan(arr).sum()
    if n_nan > 0:
        L.warning(f"S1: {n_nan} NaN pixels ({100*n_nan/arr.size:.1f}%) — filling with 0")
        arr = np.nan_to_num(arr, nan=0.0)
    L.info(f"S1 downloaded: shape={arr.shape}, range=[{arr.min():.4f},{arr.max():.4f}]")
    return arr

# ─────────────────────────────────────────────────────────────────────
#  Sentinel-1 Catalog Search (find available dates)
# ─────────────────────────────────────────────────────────────────────
def search_s1_dates(bbox, date_from, date_to):
    if not SH_OK: return []
    try:
        cat = SentinelHubCatalog(config=_sh_cfg())
        results = list(cat.search(_col_s1(), bbox=bbox,
                                  time=(date_from, date_to),
                                  fields={"include":["id","properties.datetime"]}))
        dates = sorted(set(r["properties"]["datetime"][:10] for r in results))
        L.info(f"Found {len(dates)} S1 acquisitions")
        return dates
    except Exception as e:
        L.warning(f"Catalog search failed: {e}")
        return []

# ─────────────────────────────────────────────────────────────────────
#  Sentinel-2 NDWI Permanent Water Mask — auto-tiled
# ─────────────────────────────────────────────────────────────────────
EVALSCRIPT_NDWI = """
//VERSION=3
function setup(){
  return {input:[{bands:["B03","B08","SCL"]}],
          output:{bands:2,sampleType:"FLOAT32"}}
}
function evaluatePixel(s){
  let ndwi = (s.B03-s.B08)/(s.B03+s.B08+1e-10);
  return [ndwi, s.SCL];
}
"""

def download_water_mask(bbox, date_from, date_to, target_shape=None,
                        resolution=RESOLUTION_M):
    if not SH_OK: raise RuntimeError("sentinelhub required")

    def _req(tile_bbox, tile_size):
        req = SentinelHubRequest(
            evalscript=EVALSCRIPT_NDWI,
            input_data=[SentinelHubRequest.input_data(
                data_collection=_col_s2(),
                time_interval=(date_from, date_to),
                other_args={"dataFilter":{"maxCloudCoverage":30,
                                          "mosaickingOrder":"leastCC"}})],
            responses=[SentinelHubRequest.output_response("default", MimeType.TIFF)],
            bbox=tile_bbox, size=tile_size, config=_sh_cfg())
        data = req.get_data()
        if not data: raise RuntimeError("No Sentinel-2 data returned")
        return data[0].astype(np.float32)

    raw = _download_tiled(bbox, resolution, _req)
    ndwi = raw[:,:,0] if raw.ndim == 3 else raw
    mask = (ndwi > NDWI_WATER_THRESH).astype(np.uint8)
    if target_shape and mask.shape != target_shape:
        from scipy.ndimage import zoom
        zy = target_shape[0]/mask.shape[0]
        zx = target_shape[1]/mask.shape[1]
        mask = zoom(mask.astype(float), (zy, zx), order=0).astype(np.uint8)
    L.info(f"Water mask: {mask.sum()} water pixels ({100*mask.mean():.1f}%)")
    return mask, ndwi

# ─────────────────────────────────────────────────────────────────────
#  Sentinel-2 L2A Multi-Band Download for Flood Detection
#  Returns (H,W,7): B02,B03,B04,B08,B11,B12,SCL at requested resolution.
#  Resolution defaults to 10 m (S2 native for VNIR bands); B11/B12 are
#  upsampled by SH to match the output resolution when resolution=10.
# ─────────────────────────────────────────────────────────────────────
EVALSCRIPT_S2_FLOOD = """
//VERSION=3
function setup(){
  return {
    input:[{bands:["B02","B03","B04","B08","B11","B12","SCL"],
            units:"DN"}],
    output:{bands:7, sampleType:"FLOAT32"}
  }
}
function evaluatePixel(s){
  return [s.B02, s.B03, s.B04, s.B08, s.B11, s.B12, s.SCL]
}
"""


def download_s2_flood(bbox, date_from, date_to, resolution=10.0):
    """Download Sentinel-2 L2A for flood detection.

    Returns (H, W, 7) float32 array: B02, B03, B04, B08, B11, B12, SCL.
    All bands are delivered at ``resolution`` metres (default 10 m).
    Sentinel Hub bilinearly resamples B11/B12 to match the output grid
    when resolution < 20 m — this gives smooth 10 m SWIR bands without
    the 20 m step-pattern aliasing that order=0 resampling produces.

    Uses leastCC mosaicking so the least-cloudy acquisition in the date
    window is chosen.  Cloud filtering is intentionally liberal here
    (maxCloudCoverage=80) because the authoritative cloud rejection
    happens inside ``detect_flood_s2`` via the SCL band.

    Auto-tiled for large ROIs (>2500 px per side) via ``_download_tiled``.

    Parameters
    ----------
    bbox : sentinelhub.BBox
    date_from, date_to : str, YYYY-MM-DD (inclusive window)
    resolution : float, output pixel size in metres (default 10.0)

    Returns
    -------
    np.ndarray (H, W, 7) float32
        Bands 0-5 are DN values (divide by 10000 for reflectance).
        Band 6 is the SCL class value (integer semantics, cast to uint8
        after splitting in the caller).
    """
    if not SH_OK:
        raise RuntimeError("sentinelhub required for download_s2_flood")

    def _req(tile_bbox, tile_size):
        req = SentinelHubRequest(
            evalscript=EVALSCRIPT_S2_FLOOD,
            input_data=[SentinelHubRequest.input_data(
                data_collection=_col_s2(),
                time_interval=(date_from, date_to),
                other_args={
                    "dataFilter": {
                        "maxCloudCoverage": 80,
                        "mosaickingOrder": "leastCC",
                    }
                },
            )],
            responses=[SentinelHubRequest.output_response("default", MimeType.TIFF)],
            bbox=tile_bbox, size=tile_size, config=_sh_cfg(),
        )
        data = req.get_data()
        if not data:
            raise RuntimeError("No Sentinel-2 data returned for S2 flood download")
        return data[0].astype(np.float32)

    arr = _download_tiled(bbox, resolution, _req)
    n_nan = np.isnan(arr).sum()
    if n_nan > 0:
        L.warning(f"S2 flood: {n_nan} NaN pixels ({100*n_nan/arr.size:.1f}%) — filling with 0")
        arr = np.nan_to_num(arr, nan=0.0)
    L.info(
        f"S2 flood downloaded: shape={arr.shape}, "
        f"B03 range=[{arr[:,:,1].min():.0f},{arr[:,:,1].max():.0f}] DN, "
        f"SCL unique={np.unique(arr[:,:,6].astype(np.uint8)).tolist()}"
    )
    return arr


# ═════════════════════════════════════════════════════════════════════
#  GEE fallback — COPERNICUS/S2_SR_HARMONIZED
#  Mirrors the bathy project's fetch_s2_gee but selects the 7 bands
#  needed by detect_flood_s2: B2,B3,B4,B8,B11,B12,SCL.
#  B11/B12 are 20 m native in GEE; getDownloadURL at scale=10 bilinearly
#  resamples them — identical behaviour to the SH evalscript path.
#  Returns (H,W,7) float32 in SAME contract as download_s2_flood:
#    bands 0-5 in DN units (0-10000), band 6 = SCL class value.
# ═════════════════════════════════════════════════════════════════════

_GEE_READY = False   # module-level flag; set once per process


def _init_gee_flood() -> bool:
    """Initialise Earth Engine for the flood downloader.
    Tries service-account env-vars first, then falls back to
    gcloud-CLI developer credentials in ~/.config/earthengine/."""
    global _GEE_READY
    if _GEE_READY:
        return True
    try:
        import ee
        import json as _json
        import base64 as _b64
        import tempfile

        project = os.environ.get("EE_PROJECT", "ee-wassimehtp")

        # --- resolve service-account JSON from env-vars (production path) ---
        sa_text = None
        for env_key in ("GEE_SERVICE_ACCOUNT_JSON", "GEE_CREDENTIALS_JSON"):
            cand = os.environ.get(env_key, "").strip()
            if not cand:
                continue
            if cand.startswith("{"):
                sa_text = cand
                break
            # base64?
            try:
                decoded = _b64.b64decode(cand, validate=False).decode("utf-8", "ignore")
                if decoded.strip().startswith("{"):
                    sa_text = decoded
                    break
            except Exception:
                pass
        for fp_key in ("GEE_SERVICE_ACCOUNT_FILE", "GOOGLE_APPLICATION_CREDENTIALS"):
            fp = os.environ.get(fp_key, "").strip()
            if fp and os.path.exists(fp):
                try:
                    with open(fp) as f:
                        content = f.read().strip()
                    if content.startswith("{"):
                        sa_text = content
                        break
                except Exception:
                    pass

        if sa_text:
            try:
                info = _json.loads(sa_text)
                tf = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
                tf.write(sa_text); tf.close()
                email = info.get("client_email", "")
                creds = ee.ServiceAccountCredentials(email, tf.name)
                ee.Initialize(credentials=creds, project=project)
                _GEE_READY = True
                L.info(f"GEE (flood) initialised via service account ({email})")
                return True
            except Exception as ex:
                L.warning(f"GEE service-account init failed: {ex}")

        # developer path — uses ~/.config/earthengine/credentials
        ee.Initialize(project=project)
        _GEE_READY = True
        L.info(f"GEE (flood) initialised (project={project})")
        return True
    except Exception as ex:
        L.warning(f"GEE (flood) init failed: {ex}")
        return False


def _gee_download_geotiff_flood(image, bbox_lonlat, scale: int,
                                 band_order: list, tag: str = "s2_flood"):
    """Download a GeoTIFF from GEE via getDownloadURL.
    Returns (H,W,C) float32 with bands in band_order order."""
    import ee
    w, s, e, n = bbox_lonlat
    region = ee.Geometry.Rectangle([w, s, e, n], "EPSG:4326", False)
    url = image.getDownloadURL({
        "region": region.getInfo()["coordinates"],
        "scale": scale,
        "crs": "EPSG:4326",
        "format": "GEO_TIFF",
    })
    L.info(f"GEE download URL obtained ({tag}), fetching GeoTIFF …")
    resp = requests.get(url, timeout=300)
    resp.raise_for_status()
    import rasterio
    from rasterio.io import MemoryFile
    with MemoryFile(resp.content) as mf:
        with mf.open() as src:
            arr = src.read()         # (B, H, W)
            descs = list(src.descriptions) if src.descriptions else []
    # Map descriptions back to band_order index
    if len(descs) == arr.shape[0] and all(descs):
        name_to_idx = {d: i for i, d in enumerate(descs)}
    else:
        name_to_idx = {b: i for i, b in enumerate(band_order[:arr.shape[0]])}
    # Build output (H,W,C) in band_order sequence
    H, W = arr.shape[1], arr.shape[2]
    out = np.zeros((H, W, len(band_order)), dtype=np.float32)
    for c, bname in enumerate(band_order):
        if bname in name_to_idx:
            out[:, :, c] = arr[name_to_idx[bname]]
        else:
            L.warning(f"GEE: band '{bname}' not in GeoTIFF (available: {list(name_to_idx.keys())})")
    L.info(f"GEE GeoTIFF: shape={out.shape}")
    return out


def download_s2_flood_gee(bbox, date_from: str, date_to: str,
                           cloud: int = 40, resolution: float = 10.0):
    """GEE-backed S2 SR Harmonized download for flood detection.

    Selects B2,B3,B4,B8,B11,B12,SCL from COPERNICUS/S2_SR_HARMONIZED.
    Takes the median composite over [date_from, date_to].
    Downloads at scale=10 m (GEE bilinearly resamples B11/B12 from 20 m).

    Parameters
    ----------
    bbox : sentinelhub.BBox  OR  [west, south, east, north] list
    date_from, date_to : str "YYYY-MM-DD"
    cloud : max CLOUDY_PIXEL_PERCENTAGE filter (default 40)
    resolution : output pixel size — passed to scale= (default 10.0)

    Returns
    -------
    np.ndarray (H, W, 7) float32
        Band order: B02, B03, B04, B08, B11, B12, SCL
        Bands 0-5: DN (0-10000); band 6: SCL class (float32 but integer vals)
        — IDENTICAL contract to download_s2_flood().
    """
    if not _init_gee_flood():
        raise RuntimeError("GEE not available and S2_GEE_FALLBACK requested")

    import ee

    # Accept both sentinelhub.BBox and [w,s,e,n] list
    try:
        w, s, e, n = bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y
    except AttributeError:
        w, s, e, n = bbox

    region = ee.Geometry.Rectangle([w, s, e, n], "EPSG:4326", False)

    # GEE band names for S2_SR_HARMONIZED: B2, B3, B4, B8, B11, B12, SCL
    GEE_BANDS = ["B2", "B3", "B4", "B8", "B11", "B12", "SCL"]
    OUT_NAMES = ["B2", "B3", "B4", "B8", "B11", "B12", "SCL"]

    coll = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterBounds(region)
        .filterDate(date_from, date_to)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", cloud))
    )

    n_imgs = coll.size().getInfo()
    L.info(f"GEE S2 flood: {n_imgs} images in [{date_from}, {date_to}] "
           f"cloud<{cloud}% over [{w:.3f},{s:.3f},{e:.3f},{n:.3f}]")

    if n_imgs == 0:
        raise RuntimeError(
            f"GEE: no S2 images found for [{date_from},{date_to}] "
            f"with cloud<{cloud}% — try widening date window or raising cloud threshold"
        )

    img = (
        coll.select(GEE_BANDS)
            .median()
            .rename(OUT_NAMES)
            .clip(region)
    )

    arr = _gee_download_geotiff_flood(
        img, [w, s, e, n], scale=int(resolution),
        band_order=OUT_NAMES, tag="s2_flood"
    )

    # The first 6 bands are already in DN (0–10000) from S2_SR_HARMONIZED.
    # SCL (band index 6) holds integer class values as float32 — leave as-is.
    n_nan = np.isnan(arr).sum()
    if n_nan > 0:
        L.warning(f"GEE S2 flood: {n_nan} NaN pixels — filling with 0")
        arr = np.nan_to_num(arr, nan=0.0)

    L.info(
        f"GEE S2 flood: shape={arr.shape}, "
        f"B03 range=[{arr[:,:,1].min():.0f},{arr[:,:,1].max():.0f}] DN, "
        f"SCL unique={np.unique(arr[:,:,6].astype(np.uint8)).tolist()}, "
        f"n_imgs={n_imgs}"
    )
    return arr


# ── Patched download_s2_flood — try SH first, fall back to GEE ───────
# Keep the original implementation under a private name so we can call it
# from the wrapper without recursion.
_download_s2_flood_sh = download_s2_flood   # reference captured above


def download_s2_flood(bbox, date_from, date_to, resolution=10.0):  # noqa: F811
    """Sentinel-2 L2A multi-band download for flood detection.

    Tries Sentinel Hub CDSE first.  If SH raises any exception AND
    S2_GEE_FALLBACK is enabled (env var S2_GEE_FALLBACK=1, default),
    transparently retries via Google Earth Engine
    (COPERNICUS/S2_SR_HARMONIZED median composite).

    Returns (H, W, 7) float32: B02, B03, B04, B08, B11, B12, SCL.
    DN units (0–10000) for bands 0-5; SCL class value for band 6.
    Contract is identical whether SH or GEE supplies the data.
    """
    try:
        return _download_s2_flood_sh(bbox, date_from, date_to, resolution)
    except Exception as sh_err:
        if not _S2_GEE_FALLBACK:
            raise
        L.warning(
            f"SH S2 flood failed ({sh_err!r}); "
            f"S2_GEE_FALLBACK=1 — retrying via GEE …"
        )
        return download_s2_flood_gee(bbox, date_from, date_to,
                                     cloud=40, resolution=resolution)


# ─────────────────────────────────────────────────────────────────────
#  OSM water / coastline mask — rasterised polygons of sea, rivers,
#  lakes, reservoirs etc., from OpenStreetMap.  Catches the ocean even
#  when the Sentinel-2 NDWI tile fails or the sea appears rough in SAR.
# ─────────────────────────────────────────────────────────────────────
def download_osm_water_mask(bbox, target_shape):
    """Return a uint8 mask (shape = target_shape) that is 1 over any
    OSM-tagged permanent water body inside `bbox`, 0 elsewhere.
    Requires osmnx + rasterio.features."""
    try:
        import osmnx as ox
        from rasterio.features import rasterize
        from rasterio.transform import from_bounds
        from shapely.geometry import box
    except Exception as e:
        L.warning(f"OSM water mask deps missing: {e}")
        return np.zeros(target_shape, dtype=np.uint8)

    h, w = target_shape
    tags = {
        "natural": ["water", "coastline", "bay", "strait"],
        "water":   True,          # any water=*
        "waterway": ["riverbank", "canal", "river"],
        "landuse": ["reservoir", "basin"],
    }
    polys = []
    try:
        gdf = ox.features_from_bbox(bbox=(bbox.min_x, bbox.min_y,
                                          bbox.max_x, bbox.max_y), tags=tags)
    except TypeError:
        # older osmnx signature: north,south,east,west
        gdf = ox.features_from_bbox(bbox.max_y, bbox.min_y,
                                    bbox.max_x, bbox.min_x, tags=tags)
    except Exception as e:
        L.warning(f"OSM water download failed: {e}")
        return np.zeros(target_shape, dtype=np.uint8)

    for geom in gdf.geometry.values:
        if geom is None: continue
        if geom.geom_type in ("Polygon", "MultiPolygon"):
            polys.append(geom)
        elif geom.geom_type in ("LineString", "MultiLineString"):
            # coastlines & rivers come as lines — buffer to catch the
            # seaward side of coastlines too
            polys.append(geom.buffer(0.0015))   # ~150 m at the equator

    if not polys:
        L.info("OSM water mask: no polygons found in ROI")
        return np.zeros(target_shape, dtype=np.uint8)

    transform = from_bounds(bbox.min_x, bbox.min_y,
                            bbox.max_x, bbox.max_y, w, h)
    mask = rasterize([(p, 1) for p in polys], out_shape=(h, w),
                     transform=transform, fill=0, dtype=np.uint8,
                     all_touched=True)
    L.info(f"OSM water mask: {int(mask.sum())} px ({100*mask.mean():.1f}%) "
           f"from {len(polys)} polygons")
    return mask

# ─────────────────────────────────────────────────────────────────────
#  Copernicus DEM 30m — auto-tiled (SH primary path)
# ─────────────────────────────────────────────────────────────────────
EVALSCRIPT_DEM = """
//VERSION=3
function setup(){
  return {input:[{bands:["DEM"]}],
          output:{bands:1,sampleType:"FLOAT32"}}
}
function evaluatePixel(s){return [s.DEM]}
"""

def _download_dem_sh(bbox, target_shape=None, resolution=RESOLUTION_M):
    """Sentinel Hub path for DEM (original implementation)."""
    if not SH_OK: raise RuntimeError("sentinelhub required")

    def _req(tile_bbox, tile_size):
        req = SentinelHubRequest(
            evalscript=EVALSCRIPT_DEM,
            input_data=[SentinelHubRequest.input_data(
                data_collection=_col_dem())],
            responses=[SentinelHubRequest.output_response("default", MimeType.TIFF)],
            bbox=tile_bbox, size=tile_size, config=_sh_cfg())
        data = req.get_data()
        if not data: raise RuntimeError("No DEM data returned")
        return data[0].astype(np.float32)

    raw = _download_tiled(bbox, resolution, _req)
    dem = raw[:,:,0] if raw.ndim == 3 else raw
    if target_shape and dem.shape != target_shape:
        from scipy.ndimage import zoom
        zy = target_shape[0]/dem.shape[0]
        zx = target_shape[1]/dem.shape[1]
        dem = zoom(dem, (zy, zx), order=1)
    L.info(f"DEM (SH): elev range [{dem.min():.1f}, {dem.max():.1f}] m")
    return dem


# ═════════════════════════════════════════════════════════════════════
#  GEE fallback — DEM from COPERNICUS/DEM/GLO30 (primary)
#                          USGS/SRTMGL1_003   (backup if GLO30 empty)
#  Returns a 2-D float32 elevation array in metres — SAME contract as
#  download_dem(): shape = target_shape when provided, otherwise the
#  native GEE raster at `resolution` metres/pixel.
# ═════════════════════════════════════════════════════════════════════

def download_dem_gee(bbox, target_shape=None, resolution=RESOLUTION_M):
    """GEE-backed DEM download.

    Tries COPERNICUS/DEM/GLO30 (band ``DEM``) first.  If the image
    mosaic is all-zero over the ROI (e.g., a gap tile), falls back to
    USGS/SRTMGL1_003 (band ``elevation``).

    Parameters
    ----------
    bbox : sentinelhub.BBox  OR  [west, south, east, north]
    target_shape : (H, W) tuple | None
        If given, the output is zoom-resampled to exactly this shape.
    resolution : float
        Output pixel size in metres (default = config.RESOLUTION_M = 10).
        GEE GLO30 native resolution is 30 m; bilinear resampling is used
        when resolution < 30.

    Returns
    -------
    dem : ndarray (H, W) float32, elevation in metres, non-negative
    """
    if not _init_gee_flood():
        raise RuntimeError("GEE not available for DEM download")

    import ee

    # Accept both sentinelhub.BBox and plain [w,s,e,n] list
    try:
        w, s, e, n = bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y
    except AttributeError:
        w, s, e, n = bbox

    region = ee.Geometry.Rectangle([w, s, e, n], "EPSG:4326", False)
    scale  = max(int(resolution), 10)   # GEE minimum practical scale

    # ── Primary: Copernicus GLO-30 ────────────────────────────────────
    glo30 = (
        ee.ImageCollection("COPERNICUS/DEM/GLO30")
        .filterBounds(region)
        .select("DEM")
        .mosaic()
        .clip(region)
    )

    # Quick sanity check: does GLO30 have non-zero data over this ROI?
    try:
        stats = glo30.reduceRegion(
            reducer=ee.Reducer.minMax(),
            geometry=region,
            scale=1000,          # coarse check — fast
            maxPixels=1e6,
        ).getInfo()
        glo30_max = stats.get("DEM_max", 0) or 0
    except Exception as ex:
        L.warning(f"GEE GLO30 stats check failed ({ex}); will try download anyway")
        glo30_max = 1   # assume data present; let the download fail/fallback

    if glo30_max > 0:
        L.info(f"GEE DEM: GLO30 max={glo30_max:.1f}m — using GLO30")
        dem_image  = glo30
        band_name  = "DEM"
        source_tag = "GLO30"
    else:
        L.warning("GEE DEM: GLO30 appears empty over ROI — falling back to SRTM")
        dem_image  = (
            ee.Image("USGS/SRTMGL1_003")
            .select("elevation")
            .clip(region)
        )
        band_name  = "elevation"
        source_tag = "SRTM"

    # ── Download GeoTIFF via getDownloadURL ───────────────────────────
    arr = _gee_download_geotiff_flood(
        dem_image, [w, s, e, n],
        scale=scale,
        band_order=[band_name],
        tag=f"dem_{source_tag.lower()}",
    )

    # arr is (H, W, 1) — squeeze to 2-D
    dem = arr[:, :, 0] if arr.ndim == 3 else arr
    dem = dem.astype(np.float32)

    # Fill NoData / negative values (ocean below MSL reported as small
    # negatives in GLO30; clip to 0 for depth modelling purposes)
    n_nodata = int((dem == 0).sum())
    if n_nodata / dem.size > 0.80:
        # >80% zeros likely means no real DEM coverage — raise so caller
        # can trigger a second fallback (e.g. constant elevation)
        raise RuntimeError(
            f"GEE DEM ({source_tag}): {n_nodata}/{dem.size} zero pixels "
            f"({100*n_nodata/dem.size:.0f}%) — likely no coverage"
        )

    # Resample to target_shape if requested
    if target_shape and dem.shape != target_shape:
        from scipy.ndimage import zoom as _zoom
        zy = target_shape[0] / dem.shape[0]
        zx = target_shape[1] / dem.shape[1]
        dem = _zoom(dem, (zy, zx), order=1).astype(np.float32)

    n_nan = int(np.isnan(dem).sum())
    if n_nan > 0:
        L.warning(f"GEE DEM: {n_nan} NaN pixels — filling with 0")
        dem = np.nan_to_num(dem, nan=0.0)

    L.info(
        f"GEE DEM ({source_tag}): shape={dem.shape}, "
        f"elev range [{dem.min():.1f}, {dem.max():.1f}] m, scale={scale}m"
    )
    return dem


# ── Patched download_dem — try SH first, fall back to GEE ────────────
def download_dem(bbox, target_shape=None, resolution=RESOLUTION_M):
    """Copernicus DEM 30m download.

    Tries Sentinel Hub CDSE first.  If SH raises any exception AND
    S2_GEE_FALLBACK is enabled (env var S2_GEE_FALLBACK=1, default),
    transparently retries via Google Earth Engine
    (COPERNICUS/DEM/GLO30, with USGS/SRTMGL1_003 as a secondary
    fallback inside download_dem_gee).

    Returns a 2-D float32 elevation array (H, W) in metres.
    Same contract as the original SH-only implementation.
    """
    try:
        return _download_dem_sh(bbox, target_shape, resolution)
    except Exception as sh_err:
        if not _S2_GEE_FALLBACK:
            raise
        L.warning(
            f"SH DEM failed ({sh_err!r}); "
            f"S2_GEE_FALLBACK=1 — retrying via GEE (GLO30/SRTM) …"
        )
        return download_dem_gee(bbox, target_shape, resolution)

# ─────────────────────────────────────────────────────────────────────
#  Precipitation – Open-Meteo ERA5 Archive
# ─────────────────────────────────────────────────────────────────────
def download_precipitation_era5(bbox, date_end, lookback_days=PRECIP_LOOKBACK_DAYS):
    """ERA5 (+ ERA5-Land) daily precipitation sampled on a 3×3 grid across
    the ROI.  ERA5 is a 0.25°/~30 km reanalysis that smooths convective
    extremes — a single point can miss a 200 mm convective cell by a lot.
    Sampling a grid and taking the daily *maximum* gives a realistic
    picture of what the worst cell in the ROI experienced; the daily
    *mean* is also returned for context.

    The endpoint is queried twice:
      1. ERA5-Land (9 km, higher-res land surface model)
      2. ERA5 (30 km, fallback / comparison)
    We keep the higher of the two per day per point — ERA5-Land usually
    wins but occasionally returns None over coastal pixels."""
    d1 = (dt.datetime.strptime(date_end, "%Y-%m-%d")
          - dt.timedelta(days=lookback_days)).strftime("%Y-%m-%d")
    w, s, e, n = bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y

    # 3×3 sampling grid — corners, mid-edges, centre
    pts = [(s + (n - s) * j / 2, w + (e - w) * i / 2)
           for j in range(3) for i in range(3)]

    # Source priority (best → worst for UAE convective events):
    #   1. ECMWF IFS025 via historical-forecast-api (≈11 km, from 2022-07)
    #   2. ERA5 via archive-api (≈30 km, 1940→present, gold-standard reanalysis)
    #   3. ERA5-Land via archive-api (≈9 km, often null over coastal UAE)
    # Per grid point, we try in order and accept the first that returns
    # at least one non-null day.  Per day, we then take the maximum value
    # across all grid points — representing the worst cell in the ROI.
    SOURCES = [
        ("ecmwf_ifs025", "https://historical-forecast-api.open-meteo.com/v1/forecast"),
        ("era5",         "https://archive-api.open-meteo.com/v1/archive"),
        ("era5_land",    "https://archive-api.open-meteo.com/v1/archive"),
    ]

    def _fetch(model, base, lat, lon):
        url = (f"{base}?latitude={lat:.4f}&longitude={lon:.4f}"
               f"&start_date={d1}&end_date={date_end}"
               f"&models={model}"
               "&daily=precipitation_sum,rain_sum,snowfall_sum,"
               "et0_fao_evapotranspiration"
               "&timezone=auto")
        try:
            r = requests.get(url, timeout=30); r.raise_for_status()
            return r.json().get("daily", {})
        except Exception as ex:
            L.warning(f"Precip fetch {model} ({lat:.2f},{lon:.2f}) failed: {ex}")
            return {}

    all_days = {}            # date → list of (precip, rain, snow, et0)
    sources_used = set()
    for lat, lon in pts:
        for model, base in SOURCES:
            j = _fetch(model, base, lat, lon)
            p_arr = j.get("precipitation_sum", [])
            if j.get("time") and any(v is not None for v in p_arr):
                sources_used.add(model)
                for i, d in enumerate(j["time"]):
                    row = (p_arr[i] or 0.0,
                           (j.get("rain_sum",          []) or [None]*len(p_arr))[i] or 0.0,
                           (j.get("snowfall_sum",      []) or [None]*len(p_arr))[i] or 0.0,
                           (j.get("et0_fao_evapotranspiration", []) or [None]*len(p_arr))[i] or 0.0)
                    all_days.setdefault(d, []).append(row)
                break

    if not all_days:
        L.error("Precip: no ERA5 data returned from any grid point")
        return {"dates": [], "precip_mm": [], "rain_mm": [], "snow_mm": [],
                "et0_mm": [], "total_mm": 0, "peak_mm": 0,
                "heavy_days": 0, "extreme_days": 0,
                "lookback_days": lookback_days,
                "source": "ERA5 (no data)",
                "bbox": (float(w), float(s), float(e), float(n))}

    dates = sorted(all_days.keys())
    precip_max, precip_mean, rain, snow, et0 = [], [], [], [], []
    for d in dates:
        rows = all_days[d]
        p = [r[0] for r in rows]
        precip_max.append(float(max(p)))
        precip_mean.append(float(sum(p) / len(p)))
        rain.append(float(max(r[1] for r in rows)))
        snow.append(float(max(r[2] for r in rows)))
        # ET0: mean is more meaningful than max
        et0.append(float(sum(r[3] for r in rows) / len(rows)))

    total_max  = sum(precip_max)
    total_mean = sum(precip_mean)
    peak       = max(precip_max) if precip_max else 0
    heavy_days   = sum(1 for p in precip_max if p >= PRECIP_HEAVY_THRESH)
    extreme_days = sum(1 for p in precip_max if p >= PRECIP_EXTREME_THRESH)

    L.info(f"Precip ({len(pts)} pts, sources={'+'.join(sources_used) or 'none'}): "
           f"max-cell total={total_max:.1f}mm, mean total={total_mean:.1f}mm, "
           f"peak day={peak:.1f}mm")
    return {
        "dates": dates,
        "precip_mm": precip_max,
        "precip_mean_mm": precip_mean,
        "rain_mm": rain, "snow_mm": snow, "et0_mm": et0,
        "total_mm": total_max,
        "total_mean_mm": total_mean,
        "peak_mm": peak,
        "heavy_days": heavy_days, "extreme_days": extreme_days,
        "lookback_days": lookback_days,
        "n_sample_points": len(pts),
        "source": "+".join(sorted(sources_used)) or "ERA5",
        # NF-04 — propagate bbox so analyse_precipitation can pick the
        # Köppen-Geiger regime without having to plumb it through every
        # call site.
        "bbox": (float(w), float(s), float(e), float(n)),
    }

# ─────────────────────────────────────────────────────────────────────
#  GPM IMERG
# ─────────────────────────────────────────────────────────────────────
def download_precipitation_gpm(bbox, date_str):
    try:
        d = dt.datetime.strptime(date_str, "%Y-%m-%d")
        url = (f"https://gpm1.gesdisc.eosdis.nasa.gov/opendap/GPM_L3/"
               f"GPM_3IMERGDF.07/{d.year}/{d.strftime('%j')}/"
               f"3B-DAY.MS.MRG.3IMERG.{d.strftime('%Y%m%d')}-S000000"
               f"-E235959.V07B.nc4.nc4?"
               f"precipitation[0:0][{_gpm_lat_idx(bbox.min_y)}:"
               f"{_gpm_lat_idx(bbox.max_y)}]"
               f"[{_gpm_lon_idx(bbox.min_x)}:{_gpm_lon_idx(bbox.max_x)}]")
        import netCDF4
        ds = netCDF4.Dataset(url)
        precip = ds.variables["precipitation"][0,:,:].data
        ds.close()
        return precip
    except Exception as e:
        L.warning(f"GPM IMERG failed: {e}"); return None

def _gpm_lat_idx(lat): return int((lat + 90) / 0.1)
def _gpm_lon_idx(lon): return int((lon + 180) / 0.1)

# ─────────────────────────────────────────────────────────────────────
#  DAHITI Altimetry
# ─────────────────────────────────────────────────────────────────────
def download_dahiti_altimetry(bbox, date_from, date_to):
    try:
        url = ("https://dahiti.dgfi.tum.de/api/v1/water-level/list?"
               f"min_lon={bbox.min_x}&max_lon={bbox.max_x}"
               f"&min_lat={bbox.min_y}&max_lat={bbox.max_y}")
        r = requests.get(url, timeout=15)
        if r.status_code != 200: return []
        stations = r.json()[:5]; result = []
        for s in stations:
            sid = s.get("id", s.get("station_id"))
            ts_url = (f"https://dahiti.dgfi.tum.de/api/v1/water-level/"
                      f"timeseries?id={sid}&min_date={date_from}&max_date={date_to}")
            try:
                tr = requests.get(ts_url, timeout=15)
                ts = tr.json() if tr.status_code == 200 else []
            except: ts = []
            result.append({"id": sid, "name": s.get("name", f"Station {sid}"),
                          "lat": s.get("latitude"), "lon": s.get("longitude"),
                          "timeseries": ts})
        L.info(f"DAHITI: {len(result)} stations found"); return result
    except Exception as e:
        L.warning(f"DAHITI failed: {e}"); return []

# ═════════════════════════════════════════════════════════════════════
#  MODIS NRT Flood (MCDWD_L3_F3_NRT) — download, clip, vectorize
# ═════════════════════════════════════════════════════════════════════
def _modis_tiles_for_bbox(bbox):
    """Get MODIS NRT flood tile h,v indices covering the bbox.
    MCDWD tiles use 10-degree geographic grid (not sinusoidal)."""
    tiles = set()
    for lat in [bbox.min_y, bbox.max_y]:
        for lon in [bbox.min_x, bbox.max_x]:
            h = int((lon + 180) / 10)
            v = int((90 - lat) / 10)
            h = max(0, min(35, h))
            v = max(0, min(17, v))
            tiles.add((h, v))
    return list(tiles)


def download_modis_flood_map(bbox, center_date, days_window=10):
    """
    Download MODIS NRT flood product, clip to bbox, return mask + stats.
    MCDWD values: 0=no data, 1=unflooded water, 2=flooded, 3=possible flood.
    Returns (flood_mask, stats_dict) or (None, error_dict).
    """
    import rasterio
    from rasterio.transform import from_bounds
    from rasterio.warp import reproject, Resampling, calculate_default_transform
    from rasterio.mask import mask as rio_mask
    from shapely.geometry import box

    d0 = dt.datetime.strptime(center_date, "%Y-%m-%d")
    hv_tiles = _modis_tiles_for_bbox(bbox)
    L.info(f"MODIS tiles needed: {hv_tiles}")

    best_file = None
    best_date = None

    # try to find a good file within the window
    for offset in range(0, days_window + 1):
        for sign in [0, -1, 1]:
            d = d0 + dt.timedelta(days=offset * (sign if sign else 1))
            for h, v in hv_tiles:
                fname = f"MCDWD_L3_F3_NRT.A{d.strftime('%Y%j')}.h{h:02d}v{v:02d}.061.tif"
                out = os.path.join(OUTPUT_DIR, fname)

                if os.path.exists(out) and os.path.getsize(out) > 1000:
                    best_file = out; best_date = d.strftime("%Y-%m-%d")
                    break

                url = f"{MODIS_FLOOD_BASE}/{d.year}/{fname}"
                L.info(f"MODIS trying: {fname}")
                try:
                    sess = requests.Session()
                    if EARTHDATA_USER:
                        sess.auth = (EARTHDATA_USER, EARTHDATA_PASS)
                    resp = sess.get(url, timeout=60, allow_redirects=True)
                    if resp.status_code == 200 and len(resp.content) > 1000:
                        with open(out, "wb") as f:
                            f.write(resp.content)
                        best_file = out; best_date = d.strftime("%Y-%m-%d")
                        L.info(f"MODIS downloaded: {fname} ({len(resp.content)/1024:.0f} KB)")
                        break
                    else:
                        L.info(f"MODIS {fname}: status={resp.status_code}, size={len(resp.content)}")
                except Exception as e:
                    L.warning(f"MODIS download error: {e}")

            if best_file:
                break
        if best_file:
            break

    if not best_file:
        return None, {"error": "No MODIS NRT flood data available for this area/date"}

    # read and clip to bbox
    try:
        with rasterio.open(best_file) as src:
            from rasterio.windows import from_bounds as win_from_bounds
            # MCDWD tiles are in geographic CRS — clip directly
            try:
                window = win_from_bounds(
                    bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y,
                    transform=src.transform)
                # clamp to valid range
                full_win = rasterio.windows.Window(0, 0, src.width, src.height)
                window = window.intersection(full_win)
            except Exception as e:
                L.warning(f"MODIS window error: {e}")
                return None, {"error": f"MODIS tile does not overlap with ROI: {e}"}

            if window.width < 1 or window.height < 1:
                return None, {"error": "MODIS tile does not overlap with ROI"}

            data = src.read(1, window=window)
            L.info(f"MODIS clip: {data.shape}, values: {np.unique(data)}")

        # MODIS flood classes: 0=nodata/land, 1=water, 2=flood, 3=possible flood, 255=fill/land
        flood_mask = ((data == 2) | (data == 3)).astype(np.uint8)
        water_mask = (data == 1).astype(np.uint8)
        # land coverage: 0 or 255 = no water/flood detected
        land_px = int(((data == 0) | (data == 255)).sum())
        total_valid = int((data < 255).sum())

        # reproject to WGS84 grid matching SAR resolution
        from scipy.ndimage import zoom
        # estimate target size from bbox
        target_w, target_h = bbox_to_dimensions(bbox, resolution=RESOLUTION_M)
        if flood_mask.shape != (target_h, target_w):
            zy = target_h / flood_mask.shape[0]
            zx = target_w / flood_mask.shape[1]
            flood_mask = zoom(flood_mask.astype(float), (zy, zx), order=0).astype(np.uint8)
            water_mask = zoom(water_mask.astype(float), (zy, zx), order=0).astype(np.uint8)

        flood_px = int(flood_mask.sum())
        water_px = int(water_mask.sum())
        total_px = flood_mask.size

        stats = {
            "source": "MODIS NRT (MCDWD_L3_F3_NRT)",
            "date": best_date,
            "file": os.path.basename(best_file),
            "resolution_m": 250,
            "flood_pixels": flood_px,
            "water_pixels": water_px,
            "total_pixels": total_px,
            "flood_pct": round(100 * flood_px / max(total_px, 1), 3),
            "shape": list(flood_mask.shape),
            "note": ("MODIS NRT detected flooding in this area."
                     if flood_px > 0 else
                     "No flooding detected by MODIS NRT (250m resolution). "
                     "Urban/small-scale flooding may not be visible at this resolution. "
                     "Consider using Sentinel-1 SAR mode for higher-resolution detection."),
        }
        L.info(f"MODIS flood: {flood_px} flood px ({stats['flood_pct']:.2f}%), "
               f"{water_px} water px, date={best_date}")
        return flood_mask, stats

    except Exception as e:
        L.error(f"MODIS processing error: {e}")
        return None, {"error": str(e)}
